// `npm run desktop`: launches Electron with a clean environment.
// Editors like VS Code export ELECTRON_RUN_AS_NODE=1 to their terminals, which
// would make Electron start as plain Node and crash on `app.whenReady`.
//
// Spawned detached so it survives the launching terminal being closed: on Windows,
// closing a console window sends CTRL_CLOSE_EVENT to every process still attached to
// that console. `detached: true` + `stdio: 'ignore'` puts Electron in its own process
// group with no console handle, so it keeps running after cmd/PowerShell/Git Bash exits.
const { spawn } = require('node:child_process')
const path = require('node:path')

const env = { ...process.env }
delete env.ELECTRON_RUN_AS_NODE
const electron = require('electron')
const child = spawn(electron, [path.join(__dirname, '..')], {
  env,
  stdio: 'ignore',
  detached: true,
  windowsHide: false,
})
child.unref()
console.log('[cocoziopenbot] Desktop app launched — this terminal window can now be closed safely.')
process.exit(0)
