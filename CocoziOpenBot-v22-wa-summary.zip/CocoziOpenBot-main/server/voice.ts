import { randomUUID } from 'node:crypto'
import type { Express, Request, Response } from 'express'
import express from 'express'
import { subscribe } from './events.js'
import type { Orchestrator } from './orchestrator.js'
import type { Store } from './store.js'

/**
 * Voice calls for the mobile app (mobile/). Not WhatsApp: the phone app records you,
 * POSTs the audio here, and gets the agent's answer back as speech.
 *
 *   POST /api/voice/turn?agent=<agentId>   body: raw audio (m4a/ogg/mp3/wav)
 *     -> { heard, reply, audioUrl }        audioUrl is fetched with the same auth as the API
 *   GET  /api/voice/audio/:id              mp3, one-shot-ish (kept 5 min)
 *
 * Needs an OpenAI-compatible speech API (Whisper-style STT + TTS):
 *   VOICE_API_KEY (or OPENAI_API_KEY), VOICE_BASE_URL, STT_MODEL, STT_LANGUAGE, TTS_MODEL, TTS_VOICE
 * Without a key the endpoints answer 503 and the rest of the server is unaffected.
 */

const KEY = () => process.env.VOICE_API_KEY ?? process.env.WA_VOICE_API_KEY ?? process.env.OPENAI_API_KEY ?? ''
const BASE = () => (process.env.VOICE_BASE_URL ?? process.env.WA_VOICE_BASE_URL ?? 'https://api.openai.com/v1').replace(/\/$/, '')
const STT_MODEL = () => process.env.STT_MODEL ?? process.env.WA_STT_MODEL ?? 'whisper-1'
const STT_LANG = () => process.env.STT_LANGUAGE ?? process.env.WA_STT_LANGUAGE ?? 'id'
const TTS_MODEL = () => process.env.TTS_MODEL ?? process.env.WA_TTS_MODEL ?? 'tts-1'
const TTS_VOICE = () => process.env.TTS_VOICE ?? process.env.WA_TTS_VOICE ?? 'alloy'

const MAX_SPOKEN_CHARS = 1500
const REPLY_TIMEOUT_MS = 180_000
const AUDIO_TTL_MS = 5 * 60_000

const audioStore = new Map<string, { data: Buffer; expires: number }>()

function sweep(): void {
  const now = Date.now()
  for (const [id, a] of audioStore) if (a.expires < now) audioStore.delete(id)
}

function extFor(mime: string): string {
  if (mime.includes('mpeg') || mime.includes('mp3')) return 'mp3'
  if (mime.includes('wav')) return 'wav'
  if (mime.includes('webm')) return 'webm'
  if (mime.includes('ogg') || mime.includes('opus')) return 'ogg'
  return 'm4a'
}

export async function transcribe(audio: Buffer, mime: string): Promise<string> {
  const clean = (mime || 'audio/m4a').split(';')[0] ?? 'audio/m4a'
  const form = new FormData()
  form.append('file', new Blob([new Uint8Array(audio)], { type: clean }), `voice.${extFor(clean)}`)
  form.append('model', STT_MODEL())
  if (STT_LANG()) form.append('language', STT_LANG())
  const res = await fetch(`${BASE()}/audio/transcriptions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${KEY()}` },
    body: form,
    signal: AbortSignal.timeout(60_000),
  })
  if (!res.ok) throw new Error(`STT ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`)
  const json = (await res.json()) as { text?: string }
  return String(json.text ?? '').trim()
}

/** Strip markdown so the TTS voice doesn't read out asterisks and code fences. */
export function toSpeakable(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, ' (ada kode, lihat di chat) ')
    .replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/[*_`#>~|]/g, '')
    .replace(/^\s*[-•]\s+/gm, '')
    .replace(/\s+/g, ' ')
    .trim()
}

export async function synthesize(text: string): Promise<Buffer> {
  const res = await fetch(`${BASE()}/audio/speech`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${KEY()}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: TTS_MODEL(), voice: TTS_VOICE(), input: text, response_format: 'mp3' }),
    signal: AbortSignal.timeout(60_000),
  })
  if (!res.ok) throw new Error(`TTS ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`)
  return Buffer.from(await res.arrayBuffer())
}

/** Posts `text` into the agent's DM and resolves with what that agent said once the round finishes. */
function askAgent(orchestrator: Orchestrator, conversationId: string, agentId: string, text: string): Promise<string> {
  return new Promise((resolve) => {
    const said: string[] = []
    let started = false
    const finish = () => {
      clearTimeout(timer)
      unsubscribe()
      resolve(said.join('\n\n').trim())
    }
    const timer = setTimeout(finish, REPLY_TIMEOUT_MS)
    const unsubscribe = subscribe((e) => {
      if (e.type === 'round' && e.conversationId === conversationId) {
        if (e.running) started = true
        else if (started) finish()
      } else if (e.type === 'message:done' && e.message.conversationId === conversationId && e.message.authorId === agentId && e.message.text.trim()) {
        said.push(e.message.text.trim())
      }
    })
    orchestrator.post(conversationId, text)
  })
}

export function registerVoice(app: Express, orchestrator: Orchestrator, store: Store): void {
  app.get('/api/voice/status', (_req, res) => {
    res.json({ enabled: Boolean(KEY()) })
  })

  app.post('/api/voice/turn', express.raw({ type: () => true, limit: '25mb' }), async (req: Request, res: Response) => {
    if (!KEY()) {
      res.status(503).json({ error: 'Suara belum aktif: set VOICE_API_KEY (atau OPENAI_API_KEY) di server.' })
      return
    }
    const agentId = typeof req.query.agent === 'string' ? req.query.agent : ''
    const conversationId = `dm-${agentId}`
    if (!agentId || !store.get(conversationId)) {
      res.status(404).json({ error: `unknown agent "${agentId}"` })
      return
    }
    const audio = req.body as Buffer
    if (!Buffer.isBuffer(audio) || audio.length < 800) {
      res.status(400).json({ error: 'audio kosong / terlalu pendek' })
      return
    }
    try {
      const heard = await transcribe(audio, String(req.headers['content-type'] ?? ''))
      if (!heard) {
        res.json({ heard: '', reply: '', audioUrl: null })
        return
      }
      const reply = await askAgent(
        orchestrator,
        conversationId,
        agentId,
        `[Telepon suara]: ${heard}\n(Kamu sedang di telepon: balasanmu akan DIUCAPKAN. Jawab singkat, natural, bahasa lisan, tanpa markdown/tabel/kode.)`,
      )
      if (!reply) {
        res.json({ heard, reply: '', audioUrl: null })
        return
      }
      const speak = toSpeakable(reply)
      let audioUrl: string | null = null
      if (speak) {
        const mp3 = await synthesize(speak.length > MAX_SPOKEN_CHARS ? `${speak.slice(0, MAX_SPOKEN_CHARS)}… selengkapnya ada di chat.` : speak)
        const id = randomUUID()
        sweep()
        audioStore.set(id, { data: mp3, expires: Date.now() + AUDIO_TTL_MS })
        audioUrl = `/api/voice/audio/${id}`
      }
      res.json({ heard, reply, audioUrl })
    } catch (err) {
      console.error('[voice] turn gagal:', err instanceof Error ? err.message : err)
      res.status(502).json({ error: err instanceof Error ? err.message : 'voice error' })
    }
  })

  app.get('/api/voice/audio/:id', (req, res) => {
    const a = audioStore.get(String(req.params.id))
    if (!a || a.expires < Date.now()) {
      res.status(404).json({ error: 'expired' })
      return
    }
    res.setHeader('Content-Type', 'audio/mpeg')
    res.setHeader('Content-Length', String(a.data.length))
    res.send(a.data)
  })
}
