import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StdioClientTransport, getDefaultEnvironment } from '@modelcontextprotocol/sdk/client/stdio.js'
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js'
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js'
import type { Agent, McpServerDef, Team } from '../../shared/types.js'

/**
 * Minimal MCP client for providers that have no MCP support of their own (the OpenAI-compatible
 * "API" provider: Ollama, OpenRouter, Groq, DeepSeek, Kimi…). It starts the MCP servers an employee
 * has enabled, turns their tools into OpenAI function tools and runs the calls.
 *
 * Connections are kept in a small pool: `npx` servers take seconds to start, so they are reused
 * across turns and closed after a few idle minutes.
 */

const CONNECT_TIMEOUT_MS = 90_000
const CALL_TIMEOUT_MS = 120_000
const IDLE_CLOSE_MS = 10 * 60_000
const MAX_TOOL_NAME = 64

interface McpToolInfo {
  name: string
  description?: string
  inputSchema?: Record<string, unknown>
}

interface PoolEntry {
  client: Client
  tools: McpToolInfo[]
  idle?: NodeJS.Timeout
  users: number
}

const pool = new Map<string, Promise<PoolEntry>>()

function keyFor(name: string, def: McpServerDef): string {
  return `${name}\u0000${JSON.stringify(def)}`
}

function makeTransport(def: McpServerDef) {
  if (def.type === 'stdio') {
    // Only the safe default env (PATH, HOME…) plus what the server definition asks for: MCP servers don't need our API keys.
    return new StdioClientTransport({ command: def.command, args: def.args ?? [], env: { ...getDefaultEnvironment(), ...(def.env ?? {}) } })
  }
  const headers = def.headers ?? {}
  if (def.type === 'sse') {
    return new SSEClientTransport(new URL(def.url), {
      requestInit: { headers },
      eventSourceInit: { fetch: (url, init) => fetch(url, { ...init, headers: { ...(init?.headers as Record<string, string> | undefined), ...headers } }) },
    })
  }
  return new StreamableHTTPClientTransport(new URL(def.url), { requestInit: { headers } })
}

async function connect(name: string, def: McpServerDef): Promise<PoolEntry> {
  const client = new Client({ name: 'cocoziopenbot', version: '0.3.0' })
  await client.connect(makeTransport(def), { timeout: CONNECT_TIMEOUT_MS })
  const tools: McpToolInfo[] = []
  let cursor: string | undefined
  do {
    const page = await client.listTools(cursor ? { cursor } : undefined, { timeout: CONNECT_TIMEOUT_MS })
    for (const t of page.tools) tools.push({ name: t.name, description: t.description, inputSchema: t.inputSchema as Record<string, unknown> })
    cursor = page.nextCursor
  } while (cursor)
  const entry: PoolEntry = { client, tools, users: 0 }
  client.onclose = () => {
    if (pool.get(keyFor(name, def)) !== undefined) pool.delete(keyFor(name, def))
  }
  return entry
}

function acquire(name: string, def: McpServerDef): Promise<PoolEntry> {
  const key = keyFor(name, def)
  let p = pool.get(key)
  if (!p) {
    p = connect(name, def)
    pool.set(key, p)
    p.catch(() => pool.delete(key))
  }
  return p.then((entry) => {
    entry.users++
    if (entry.idle) clearTimeout(entry.idle)
    entry.idle = undefined
    return entry
  })
}

function release(name: string, def: McpServerDef, entry: PoolEntry): void {
  entry.users = Math.max(0, entry.users - 1)
  if (entry.users > 0) return
  entry.idle = setTimeout(() => {
    pool.delete(keyFor(name, def))
    void entry.client.close().catch(() => undefined)
  }, IDLE_CLOSE_MS)
  entry.idle.unref()
}

/** Best effort: stop the MCP child processes when the server exits. */
process.once('exit', () => {
  for (const p of pool.values()) void p.then((e) => e.client.close()).catch(() => undefined)
})

function safeName(s: string): string {
  return s.replace(/[^A-Za-z0-9_-]/g, '_')
}

/** Strip schema keys some OpenAI-compatible backends reject, and make sure the root is an object schema. */
function cleanSchema(schema: Record<string, unknown> | undefined): Record<string, unknown> {
  const out: Record<string, unknown> = { ...(schema ?? {}) }
  delete out.$schema
  if (out.type !== 'object') out.type = 'object'
  if (typeof out.properties !== 'object' || out.properties === null) out.properties = {}
  return out
}

function renderResult(result: unknown): string {
  const r = result as { content?: { type: string; text?: string; mimeType?: string; resource?: { text?: string; uri?: string } }[]; structuredContent?: unknown; isError?: boolean }
  const parts: string[] = []
  for (const c of r.content ?? []) {
    if (c.type === 'text' && c.text !== undefined) parts.push(c.text)
    else if (c.type === 'resource' && c.resource) parts.push(c.resource.text ?? `[resource ${c.resource.uri ?? ''}]`)
    else parts.push(`[${c.type}${c.mimeType ? ` ${c.mimeType}` : ''} content not shown]`)
  }
  if (parts.length === 0 && r.structuredContent !== undefined) parts.push(JSON.stringify(r.structuredContent))
  const text = parts.join('\n').trim() || '(empty result)'
  return r.isError ? `Error: ${text}` : text
}

export interface OpenAiToolDef {
  type: 'function'
  function: { name: string; description: string; parameters: Record<string, unknown> }
}

interface Bound {
  server: string
  tool: string
  client: Client
}

/** The MCP tools one employee has for one turn. Always `close()` it when the turn ends. */
export class McpToolbox {
  readonly defs: OpenAiToolDef[] = []
  /** Servers that failed to start, with the reason, so the employee can say why a tool is missing. */
  readonly failed: { server: string; error: string }[] = []
  readonly servers: string[] = []
  private readonly bound = new Map<string, Bound>()
  private readonly held: { name: string; def: McpServerDef; entry: PoolEntry }[] = []

  static async open(team: Team, agent: Agent): Promise<McpToolbox> {
    const box = new McpToolbox()
    await Promise.all(
      agent.mcpServers.map(async (name) => {
        const def = team.mcpServers[name]
        if (!def) return
        try {
          const entry = await acquire(name, def)
          box.held.push({ name, def, entry })
        } catch (err) {
          box.failed.push({ server: name, error: err instanceof Error ? err.message : String(err) })
        }
      }),
    )
    // Stable order regardless of which server connected first.
    box.held.sort((a, b) => agent.mcpServers.indexOf(a.name) - agent.mcpServers.indexOf(b.name))
    for (const { name, entry } of box.held) {
      box.servers.push(name)
      for (const tool of entry.tools) {
        let fn = `mcp__${safeName(name)}__${safeName(tool.name)}`.slice(0, MAX_TOOL_NAME)
        for (let i = 2; box.bound.has(fn); i++) fn = `${fn.slice(0, MAX_TOOL_NAME - 3)}_${i}`
        box.bound.set(fn, { server: name, tool: tool.name, client: entry.client })
        box.defs.push({ type: 'function', function: { name: fn, description: `[${name}] ${tool.description ?? tool.name}`.slice(0, 1000), parameters: cleanSchema(tool.inputSchema) } })
      }
    }
    return box
  }

  has(fn: string): boolean {
    return this.bound.has(fn)
  }

  describe(fn: string): string {
    const b = this.bound.get(fn)
    return b ? `${b.server} → ${b.tool}` : fn
  }

  async call(fn: string, args: Record<string, unknown>, signal: AbortSignal): Promise<string> {
    const b = this.bound.get(fn)
    if (!b) return `Error: unknown MCP tool ${fn}`
    try {
      const result = await b.client.callTool({ name: b.tool, arguments: args }, undefined, { signal, timeout: CALL_TIMEOUT_MS })
      return renderResult(result)
    } catch (err) {
      return `Error: ${err instanceof Error ? err.message : String(err)}`
    }
  }

  close(): void {
    for (const h of this.held) release(h.name, h.def, h.entry)
    this.held.length = 0
  }
}
