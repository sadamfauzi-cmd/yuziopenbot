' Double-click this file to start CocoziOpenBot with no CMD/console window at all.
' It runs `npm run desktop` hidden, in this file's own folder, then exits immediately —
' the Electron app keeps running on its own after that.
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = scriptDir
shell.Run "cmd /c npm run desktop", 0, False
