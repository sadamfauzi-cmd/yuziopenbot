// Minimal service worker: makes the app installable on a phone (PWA).
// Network first. Only the icon is cached for offline; HTML and JS/CSS are NEVER served from cache, because a stale
// index.html that points at an old hashed bundle (after a rebuild) gives a blank page + MIME-type error.
const CACHE = 'cocoziopenbot-shell-v2'
self.addEventListener('install', () => {
  self.skipWaiting()
})
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))))
  self.clients.claim()
})
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url)
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return
  if (url.pathname !== '/icon.svg') return // let the browser handle everything else normally
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res.ok) caches.open(CACHE).then((c) => c.put(e.request, res.clone())).catch(() => undefined)
        return res
      })
      .catch(() => caches.match(e.request).then((hit) => hit ?? Response.error())),
  )
})
