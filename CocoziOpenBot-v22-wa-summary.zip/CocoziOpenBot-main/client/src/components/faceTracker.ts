import { useSyncExternalStore } from 'react'

/**
 * One shared brain for every bot face on screen.
 * - Only "following" faces (the active chat's bots, or the one you hover) chase the cursor
 *   and look at the text box while you type. Everyone else glances around freely.
 * - Free faces glance faster and further than followers do when the cursor is still.
 * - After a minute of no activity they fall asleep; any movement wakes them up.
 * Faces are updated through CSS variables, so React never re-renders on mouse move.
 */
export type SleepState = 'awake' | 'sleep' | 'wake'

interface Face {
  el: Element
  follow: boolean
  /** Bigger eye travel and head lean, and free glances when the cursor rests (the dashboard hero). */
  lively: boolean
  rect: DOMRect
  x: number
  y: number
  gx: number
  gy: number
  nextGlance: number
  written: string
}

const SLEEP_AFTER_MS = 60_000
const FOLLOW_MS = 5_000
const EYE_X = 2.7
const EYE_Y = 2.3
const BODY = 1.1

const faces = new Set<Face>()
const subs = new Set<() => void>()

let px = NaN
let py = NaN
let lastMove = 0
let lastActive = 0
let rectsAt = 0
let sleep: SleepState = 'awake'
let started = false

const rand = (a: number, b: number) => a + Math.random() * (b - a)

function setSleep(next: SleepState) {
  if (next === sleep) return
  sleep = next
  subs.forEach((fn) => fn())
}

function activity() {
  lastActive = performance.now()
  if (sleep === 'sleep') {
    setSleep('wake')
    setTimeout(() => setSleep('awake'), 900)
  }
}

function tick(now: number) {
  requestAnimationFrame(tick)
  if (document.hidden || faces.size === 0) return
  if (sleep === 'awake' && now - lastActive > SLEEP_AFTER_MS) setSleep('sleep')

  if (now - rectsAt > 400) {
    rectsAt = now
    for (const f of faces) f.rect = f.el.getBoundingClientRect()
  }

  const cursorLive = !Number.isNaN(px) && now - lastMove < FOLLOW_MS
  for (const f of faces) {
    const r = f.rect
    if (r.width === 0) continue
    let tx = 0
    let ty = 0
    if (sleep === 'sleep') {
      ty = 0.7
    } else if (cursorLive && f.follow) {
      const dx = px - (r.left + r.width / 2)
      const dy = py - (r.top + r.height / 2)
      const dist = Math.hypot(dx, dy) || 1
      const k = Math.min(1, dist / 140)
      tx = (dx / dist) * k
      ty = (dy / dist) * k
    } else {
      if (now > f.nextGlance) {
        const free = !f.follow || f.lively
        const still = Math.random() < (free ? 0.18 : 0.35)
        f.gx = still ? 0 : rand(-1, 1) * (free ? 1 : 0.9)
        f.gy = still ? 0 : rand(-0.7, 0.7) * (free ? 1 : 0.7)
        f.nextGlance = now + (free ? rand(700, 2600) : rand(1400, 4200))
      }
      tx = f.gx
      ty = f.gy
    }
    const ease = 0.16
    f.x += (tx - f.x) * ease
    f.y += (ty - f.y) * ease
    const eg = f.lively ? 1.3 : 1
    const bg = f.lively ? 2.6 : 1
    const value = `${(f.x * EYE_X * eg).toFixed(2)} ${(f.y * EYE_Y * eg).toFixed(2)} ${(f.x * BODY * bg).toFixed(2)} ${(f.y * BODY * bg).toFixed(2)}`
    if (value === f.written) continue
    f.written = value
    const s = (f.el as SVGElement).style
    const [lx, ly, bx, by] = value.split(' ')
    s.setProperty('--lx', lx!)
    s.setProperty('--ly', ly!)
    s.setProperty('--bx', bx!)
    s.setProperty('--by', by!)
  }
}

function start() {
  if (started || typeof window === 'undefined') return
  started = true
  lastActive = performance.now()
  window.addEventListener(
    'pointermove',
    (e) => {
      px = e.clientX
      py = e.clientY
      lastMove = performance.now()
      activity()
    },
    { passive: true },
  )
  window.addEventListener('pointerdown', activity, { passive: true })
  window.addEventListener('keydown', (e) => {
    activity()
    const t = e.target
    if (t instanceof HTMLElement && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.isContentEditable)) {
      const r = t.getBoundingClientRect()
      px = r.left + Math.min(r.width, 320) / 2
      py = r.top + r.height / 2
      lastMove = performance.now()
    }
  })
  document.addEventListener('pointerout', (e) => {
    if (!e.relatedTarget) px = NaN
  })
  const refresh = () => {
    rectsAt = 0
  }
  window.addEventListener('scroll', refresh, { capture: true, passive: true })
  window.addEventListener('resize', refresh)
  requestAnimationFrame(tick)
}

export interface FaceHandle {
  stop: () => void
  setFollow: (follow: boolean) => void
}

/** Register an <svg> face. `follow` decides whether it chases the cursor or roams freely. */
export function trackFace(el: Element, follow = false, lively = false): FaceHandle {
  start()
  const face: Face = { el, follow, lively, rect: el.getBoundingClientRect(), x: 0, y: 0, gx: 0, gy: 0, nextGlance: performance.now() + rand(300, 2500), written: '' }
  faces.add(face)
  return {
    stop: () => {
      faces.delete(face)
    },
    setFollow: (v) => {
      face.follow = v
    },
  }
}

/** Where the cursor is (viewport px) and whether it moved recently. */
export function getPointer(): { x: number; y: number; live: boolean } {
  return { x: px, y: py, live: !Number.isNaN(px) && performance.now() - lastMove < FOLLOW_MS }
}

export function useSleepState(): SleepState {
  return useSyncExternalStore(
    (fn) => {
      subs.add(fn)
      return () => subs.delete(fn)
    },
    () => sleep,
    () => 'awake',
  )
}
