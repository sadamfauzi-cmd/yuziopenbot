export function NavToggle({ onClick, open }: { onClick: () => void; open: boolean }) {
  return (
    <button type="button" className="icon-button nav-toggle" onClick={onClick} aria-label={open ? 'Hide sidebar' : 'Show sidebar'} aria-expanded={open}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
        <path d="M4 7h16M4 12h16M4 17h16" />
      </svg>
    </button>
  )
}
