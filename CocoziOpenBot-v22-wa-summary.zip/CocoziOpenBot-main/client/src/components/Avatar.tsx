import { createContext, useContext, useEffect, useId, useRef, useState, type CSSProperties, type ReactElement } from 'react'
import type { AvatarShape } from '../../../shared/types'
import type { Person } from '../people'
import { trackFace, useSleepState, type FaceHandle } from './faceTracker'

interface AvatarProps {
  person: Person
  size?: number
  /** Force an expression (otherwise it follows what the employee is doing). */
  mood?: FaceMood
  /** Force following the cursor on/off (default: on for the active chat's bots and on hover). */
  follow?: boolean
  /** Big expressive mascot: wider eye travel and stronger head lean. */
  lively?: boolean
  /** Little floating hands beside the body. */
  hands?: boolean
  /** Raise a hand and wave (needs `hands`). */
  wave?: boolean
}

const SHAPES: Record<AvatarShape, string> = {
  blob: 'M5 21C4 12 11 5 20 5s16 6 15 15c-1 8-6 15-15 15S6 30 5 21z',
  round: 'M20 4a16 16 0 1 1 0 32 16 16 0 0 1 0-32z',
  triangle: 'M18 5c1.2-1.5 2.8-1.5 4 0l13 24c1 2-.2 4.5-2.5 4.5h-25C5.2 33.5 4 31 5 29z',
  hex: 'M17.5 4.5c1.5-.9 3.5-.9 5 0l9.5 5.5c1.5.9 2.5 2.6 2.5 4.3v11.4c0 1.7-1 3.4-2.5 4.3L22.5 35.5c-1.5.9-3.5.9-5 0L8 30c-1.5-.9-2.5-2.6-2.5-4.3V14.3c0-1.7 1-3.4 2.5-4.3z',
  drop: 'M20 3c6 8 14 14 14 22a14 14 0 0 1-28 0C6 17 14 11 20 3z',
}

export type FaceMood =
  | 'idle' | 'happy' | 'sleepy' | 'surprised' | 'angry' | 'thinking' | 'working' | 'error'
  | 'smug' | 'sad' | 'wink' | 'tiny' | 'side' | 'wide' | 'shy' | 'ring' | 'cluster' | 'yinyang'

/** Ids of the employees that are busy right now (typing in any conversation). */
export const AvatarActivity = createContext<ReadonlySet<string>>(new Set())
/** Ids of the bots in the selected chat: only these follow the cursor, the rest roam freely. */
export const AvatarFollow = createContext<ReadonlySet<string>>(new Set())

const EYE = '#141414'
const AMBIENT: FaceMood[] = ['happy', 'smug', 'wink', 'tiny', 'side', 'wide', 'sad', 'shy', 'ring', 'cluster', 'yinyang', 'surprised', 'sleepy', 'angry']
const rnd = (a: number, b: number) => a + Math.random() * (b - a)

const pair = (render: (i: number) => ReactElement, spread = 5.5) =>
  [-spread, spread].map((dx, i) => (
    <g key={dx} transform={`translate(${dx} 0)`}>
      {render(i)}
    </g>
  ))

function seedOf(id: string): number {
  let h = 7
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0
  return h
}

/**
 * A living bot face. The bots of the selected chat (or the one you hover) follow the cursor;
 * the others roam on their own: glancing around and cycling through expressions.
 */
export function Avatar({ person, size = 36, mood, follow: followProp, lively = false, hands = false, wave = false }: AvatarProps) {
  const uid = useId().replace(/:/g, '')
  const svg = useRef<SVGSVGElement>(null)
  const body = useRef<SVGGElement>(null)
  const tracker = useRef<FaceHandle | null>(null)
  const busy = useContext(AvatarActivity).has(person.id)
  const active = useContext(AvatarFollow).has(person.id)
  const sleep = useSleepState()
  const [hover, setHover] = useState(false)
  const [press, setPress] = useState(false)
  const [amb, setAmb] = useState<FaceMood>('idle')
  const owner = person.kind === 'owner'
  const follow = followProp ?? (active || hover)
  const calm = !!mood || busy || owner

  // free bots: idle for a few seconds, pull a face for a moment, repeat
  useEffect(() => {
    if (follow || calm) {
      setAmb('idle')
      return
    }
    let cur: FaceMood = 'idle'
    let t: ReturnType<typeof setTimeout>
    const step = () => {
      const pull = cur === 'idle' || Math.random() < 0.15
      cur = pull ? AMBIENT[Math.floor(Math.random() * AMBIENT.length)]! : 'idle'
      setAmb(cur)
      t = setTimeout(step, cur === 'idle' ? rnd(1800, 5500) : rnd(1300, 3200))
    }
    t = setTimeout(step, rnd(400, 5000))
    return () => clearTimeout(t)
  }, [follow, calm])

  let eff: FaceMood = mood ?? (busy ? 'thinking' : amb)
  if (!mood && !busy) {
    if (sleep === 'sleep') eff = 'sleepy'
    else if (sleep === 'wake' || press) eff = 'surprised'
    else if (hover) eff = 'happy'
  }

  useEffect(() => {
    if (owner || !svg.current) return
    const h = trackFace(svg.current, follow, lively)
    tracker.current = h
    return h.stop
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [owner])
  useEffect(() => tracker.current?.setFollow(follow), [follow])

  const first = useRef(true)
  useEffect(() => {
    if (first.current) {
      first.current = false
      return
    }
    const el = body.current
    if (!el) return
    el.classList.remove('pop')
    void el.getBoundingClientRect()
    el.classList.add('pop')
  }, [eff])

  if (owner) {
    const initial = person.name.trim().charAt(0).toUpperCase() || '•'
    return (
      <span className="avatar avatar-owner" style={{ width: size, height: size, fontSize: size * 0.42 }} aria-label={person.name}>
        {initial}
      </span>
    )
  }

  const shape = person.agent?.shape ?? 'blob'
  const eyeY = shape === 'triangle' || shape === 'drop' ? 23 : 19.5
  const h = seedOf(person.id)
  const style = { '--blink': `${3.6 + (h % 30) / 10}s`, '--bd': `${-((h >> 3) % 50) / 10}s` } as CSSProperties
  const on = (...m: FaceMood[]) => (m.includes(eff) ? ' on' : '')
  const line = { fill: 'none', stroke: EYE, strokeWidth: 1.8, strokeLinecap: 'round' } as const

  return (
    <svg
      ref={svg}
      className="avatar face"
      width={size}
      height={size}
      viewBox="0 0 40 40"
      aria-label={person.name}
      data-mood={eff}
      data-follow={follow ? '1' : '0'}
      data-wave={wave ? '1' : '0'}
      style={style}
      onPointerEnter={() => setHover(true)}
      onPointerLeave={() => {
        setHover(false)
        setPress(false)
      }}
      onPointerDown={() => setPress(true)}
      onPointerUp={() => setPress(false)}
    >
      <defs>
        <radialGradient id={`${uid}s`} cx="35%" cy="26%" r="85%">
          <stop offset="0" stopColor="#fff" stopOpacity=".45" />
          <stop offset=".5" stopColor="#fff" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity=".3" />
        </radialGradient>
      </defs>
      <g className="face-float">
        <g ref={body} className="face-body">
          <path d={SHAPES[shape]} fill={person.color} />
          <path d={SHAPES[shape]} fill={`url(#${uid}s)`} />
          {hands && (
            <>
              <circle className="face-hand hand-l" cx="2.8" cy="27" r="3.3" fill={person.color} />
              <circle className="face-hand hand-l" cx="2.8" cy="27" r="3.3" fill={`url(#${uid}s)`} />
              <circle className="face-hand hand-r" cx="37.2" cy="27" r="3.3" fill={person.color} />
              <circle className="face-hand hand-r" cx="37.2" cy="27" r="3.3" fill={`url(#${uid}s)`} />
            </>
          )}
          <g transform={`translate(20 ${eyeY})`} fill={EYE}>
            <g className="face-look">
              <g className="face-blink">
                <g className={`face-m${on('idle')}`}>{pair(() => <ellipse rx="2.3" ry="2.9" />)}</g>
                <g className={`face-m${on('happy')}`}>{pair(() => <path d="M-3.2 1.7A3.2 3.4 0 0 1 3.2 1.7Z" />)}</g>
                <g className={`face-m${on('sleepy')}`}>{pair(() => <rect x="-3.2" y="-.75" width="6.4" height="1.5" rx=".75" />)}</g>
                <g className={`face-m${on('surprised')}`}>{pair(() => <rect x="-2.4" y="-4.4" width="4.8" height="8.8" rx="2.4" />)}</g>
                <g className={`face-m${on('angry', 'error')}`}>{pair((i) => <ellipse rx="3.1" ry="1.5" transform={`rotate(${i === 0 ? 22 : -22})`} />)}</g>
                <g className={`face-m${on('smug')}`}>{pair((i) => <ellipse rx="3.7" ry="2.1" transform={`rotate(${i === 0 ? 12 : -12})`} />)}</g>
                <g className={`face-m${on('sad')}`}>{pair(() => <path d="M-3.1 -1.6H3.1A3.1 3.6 0 0 1 -3.1 -1.6Z" />)}</g>
                <g className={`face-m${on('tiny')}`}>{pair(() => <circle r="1.2" />, 4.6)}</g>
                <g className={`face-m${on('wide')}`}>{pair(() => <rect x="-1.2" y="-3.6" width="2.4" height="7.2" rx="1.2" />, 9.5)}</g>
                <g className={`face-m${on('side')}`} transform="translate(3 0)">{pair(() => <rect x="-1.8" y="-4.2" width="3.6" height="8.4" rx="1.8" />)}</g>
                <g className={`face-m${on('shy')}`} transform="translate(-2.5 3)">
                  <ellipse cx="-4.5" rx="2.6" ry="2.4" />
                  <ellipse cx="4.5" cy="1" rx="1.8" ry="1.4" />
                </g>
                <g className={`face-m${on('wink')}`}>
                  <ellipse cx="-5.5" rx="2.3" ry="2.9" />
                  <path d="M2.5 1.2Q5.5 -2.4 8.5 1.2" {...line} />
                </g>
                <g className={`face-m${on('ring')}`}>
                  <circle cy="1" r="4.4" fill="none" stroke={EYE} strokeWidth="1.7" />
                </g>
                <g className={`face-m${on('cluster')}`}>
                  {[
                    [-4.5, -3, 2.3],
                    [0, 0.6, 2.6],
                    [4.4, 4.4, 2.3],
                  ].map(([x, y, r], i) => (
                    <circle key={i} className="hop" cx={x} cy={y} r={r} style={{ animationDelay: `${i * 0.18}s` }} />
                  ))}
                </g>
                <g className={`face-m${on('yinyang')}`}>
                  <g className="spin">
                    <circle cy="1" r="7" fill="#f4f4f4" />
                    <path d="M0 -6A7 7 0 0 1 0 8A3.5 3.5 0 0 1 0 1A3.5 3.5 0 0 0 0 -6Z" fill={EYE} />
                    <circle cy="-2.5" r="1" fill={EYE} />
                    <circle cy="4.5" r="1" fill="#f4f4f4" />
                  </g>
                </g>
                <g className={`face-m${on('thinking')}`}>
                  {[-6, 0, 6].map((x, i) => (
                    <circle key={x} className="hop" cx={x} cy="1" r="2" style={{ animationDelay: `${i * 0.14}s` }} />
                  ))}
                </g>
                <g className={`face-m${on('working')}`}>
                  {[-5.4, 0, 5.4].map((x, i) => (
                    <rect key={x} className="bar" x={x - 1.2} y="-4" width="2.4" height="8" rx="1.2" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </g>
              </g>
            </g>
          </g>
        </g>
      </g>
      {eff === 'error' && <circle className="face-badge" cx="6.5" cy="7" r="3.6" fill="#ff453a" stroke="#141414" strokeWidth="1.2" />}
    </svg>
  )
}

interface AvatarClusterProps {
  people: Person[]
  size?: number
}

/** Overlapping avatars like a group-chat icon: up to three faces, then "+N". */
export function AvatarCluster({ people, size = 40 }: AvatarClusterProps) {
  const shown = people.slice(0, 3)
  const rest = people.length - shown.length
  if (shown.length === 1 && shown[0]) return <Avatar person={shown[0]} size={size} />
  const small = Math.round(size * 0.72)
  const step = Math.round(size * 0.3)
  const width = small + step * (shown.length - 1)
  return (
    <span className="avatar-cluster-wrap">
      <span className="avatar-cluster" style={{ width, height: size }}>
        {shown.map((p, i) => (
          <span key={p.id} className="avatar-cluster-item" style={{ left: i * step, zIndex: shown.length - i }}>
            <Avatar person={p} size={small} />
          </span>
        ))}
      </span>
      {rest > 0 && <span className="avatar-cluster-more">+{rest}</span>}
    </span>
  )
}
