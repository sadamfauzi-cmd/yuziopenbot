import { useI18n } from '../i18n'
import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import type { AccountStatus, Agent, ApprovalRequest, Conversation, Routine, Team, UsageSummary } from '../../../shared/types'
import { personFor, type Person } from '../people'
import { Avatar, type FaceMood } from './Avatar'
import { getPointer, useSleepState } from './faceTracker'
import { DashboardPanels } from './DashboardPanels'
import { DashMember } from './DashMember'
import type { SettingsSection } from './Settings'
import { NavToggle } from './NavToggle'

interface DashboardProps {
  team: Team
  conversations: Conversation[]
  working: Set<string>
  usage: UsageSummary
  account: AccountStatus
  routines: Routine[]
  approvals: ApprovalRequest[]
  onOpenMember: (agentId: string) => void
  onOpenChat: (conversationId: string) => void
  onNewChat: () => void
  onSettings: (section: SettingsSection) => void
  onToggleNav: () => void
  navOpen: boolean
}

const AMBIENT: FaceMood[] = ['happy', 'wink', 'smug', 'tiny', 'side', 'wide', 'shy', 'ring', 'cluster', 'yinyang', 'surprised', 'sad']
const POKES: FaceMood[] = ['surprised', 'happy', 'wink', 'ring', 'smug']
const SAYS = ['Hello!', 'Hi~', 'Need a hand?', 'Hehe', 'That tickles!', "Let's work together!"]
const rnd = (a: number, b: number) => a + Math.random() * (b - a)
const pick = <T,>(list: T[]): T => list[Math.floor(Math.random() * list.length)]!
const clamp = (v: number, lim: number) => Math.max(-lim, Math.min(lim, v))

/** The mascot drifts around its stage, leans toward the cursor while it moves and wanders when it rests. */
function useDrift(stage: React.RefObject<HTMLDivElement | null>, awake: boolean) {
  useEffect(() => {
    const box = stage.current
    if (!box) return
    const move = box.querySelector<HTMLElement>('.hero-move')
    if (!move) return
    let raf = 0
    let x = 0
    let y = 0
    let tx = 0
    let ty = 0
    let nextPick = 0
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick)
      if (document.hidden) return
      if (!awake) {
        tx = 0
        ty = 8
      } else {
        const p = getPointer()
        if (p.live) {
          const r = box.getBoundingClientRect()
          tx = clamp((p.x - (r.left + r.width / 2)) * 0.09, 46)
          ty = clamp((p.y - (r.top + r.height / 2)) * 0.06, 18)
          nextPick = now + 1500
        } else if (now > nextPick) {
          tx = rnd(-85, 85)
          ty = rnd(-24, 8)
          nextPick = now + rnd(2200, 4800)
        }
      }
      const vx = (tx - x) * 0.045
      const vy = (ty - y) * 0.045
      x += vx
      y += vy
      const speed = Math.hypot(vx, vy)
      const s = Math.min(speed * 0.02, 0.06)
      move.style.setProperty('--hx', x.toFixed(2))
      move.style.setProperty('--hy', y.toFixed(2))
      move.style.setProperty('--hr', clamp(vx * 5, 10).toFixed(2))
      move.style.setProperty('--sx', (1 + s).toFixed(3))
      move.style.setProperty('--sy', (1 - s * 0.8).toFixed(3))
      box.style.setProperty('--shadow', (1 - Math.max(0, -y) * 0.004).toFixed(3))
      box.style.setProperty('--shx', x.toFixed(2))
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [stage, awake])
}

export function Dashboard({ team, conversations, working, usage, account, routines, approvals, onOpenMember, onOpenChat, onNewChat, onSettings, onToggleNav, navOpen }: DashboardProps) {
  const { t } = useI18n()
  const stage = useRef<HTMLDivElement>(null)
  const hopEl = useRef<HTMLDivElement>(null)
  const sleep = useSleepState()
  const awake = sleep === 'awake'
  const [mood, setMood] = useState<FaceMood | undefined>('surprised')
  const [wave, setWave] = useState(true)
  const [hover, setHover] = useState(false)
  const [say, setSay] = useState<string | null>(t('Hello!'))
  const reactUntil = useRef(0)
  const reactTimer = useRef<number | undefined>(undefined)
  const clicks = useRef<number[]>([])

  const hero = useMemo<Person>(() => ({ id: 'hero', label: 'Bot', name: 'Bot', color: '#ff6a1a', kind: 'agent', agent: { shape: 'blob' } as Agent }), [])
  const owner = team.owner.name

  useDrift(stage, awake)

  const hop = () => {
    const el = hopEl.current
    if (!el) return
    el.classList.remove('is-hop')
    void el.getBoundingClientRect()
    el.classList.add('is-hop')
  }

  // greeting when you arrive: hop, look surprised, then wave
  useEffect(() => {
    hop()
    const t1 = window.setTimeout(() => setMood('happy'), 550)
    const t2 = window.setTimeout(() => {
      setMood(undefined)
      setWave(false)
      setSay(null)
    }, 3400)
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
    }
  }, [])

  // afterwards it pulls faces on its own every few seconds
  useEffect(() => {
    if (!awake) {
      setMood(undefined)
      setWave(false)
      return
    }
    let t: number
    let stopped = false
    const later = (fn: () => void, ms: number) => {
      t = window.setTimeout(() => !stopped && fn(), ms)
    }
    const calm = () => {
      if (Date.now() > reactUntil.current) {
        setMood(undefined)
        setWave(false)
      }
      later(burst, rnd(3000, 6500))
    }
    const burst = () => {
      if (Date.now() < reactUntil.current) return later(burst, 1200)
      const m = pick(AMBIENT)
      setMood(m)
      setWave(m === 'happy')
      later(calm, rnd(1400, 2800))
    }
    later(burst, 4200)
    return () => {
      stopped = true
      clearTimeout(t)
    }
  }, [awake])

  useEffect(() => () => clearTimeout(reactTimer.current), [])

  const poke = () => {
    const now = Date.now()
    clicks.current = [...clicks.current.filter((t) => now - t < 2200), now]
    const n = clicks.current.length
    const m: FaceMood = n >= 5 ? 'yinyang' : n === 4 ? 'angry' : pick(POKES)
    const ms = n >= 5 ? 2600 : 1500
    hop()
    setMood(m)
    setWave(n === 1)
    setSay(t(n >= 5 ? 'Dizzy…' : n === 4 ? 'Ouch!' : pick(SAYS)))
    reactUntil.current = now + ms
    clearTimeout(reactTimer.current)
    reactTimer.current = window.setTimeout(() => {
      setMood(undefined)
      setWave(false)
      setSay(null)
    }, ms)
  }

  const members = team.agents
  const size = members.length <= 6 ? 76 : members.length <= 12 ? 62 : members.length <= 24 ? 50 : 40

  return (
    <section className="dashboard">
      <div className="dash-nav">
        <NavToggle onClick={onToggleNav} open={navOpen} />
      </div>
      <div className="hero-stage" ref={stage}>
        <div className="hero-shadow" />
        <div className="hero-move">
          {say && <div className="hero-say">{say}</div>}
          <div
            className="hero-hop"
            ref={hopEl}
            role="button"
            tabIndex={0}
            aria-label={t('Say hi to the bot')}
            onPointerEnter={() => setHover(true)}
            onPointerLeave={() => setHover(false)}
            onClick={poke}
            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && poke()}
          >
            <Avatar person={hero} size={220} follow lively hands wave={wave || hover} {...(mood ? { mood } : {})} />
          </div>
        </div>
      </div>

      <h1 className="dash-title">{t('Welcome')}</h1>
      <p className="dash-sub">{team.company ? `${owner} · ${team.company}` : owner}</p>

      <DashboardPanels
        team={team}
        conversations={conversations}
        working={working}
        usage={usage}
        account={account}
        routines={routines}
        approvals={approvals}
        onOpenChat={onOpenChat}
        onNewChat={onNewChat}
        onSettings={onSettings}
      />

      <div className="dash-label">{t('Members')} · {members.length}</div>
      <div className="dash-members" style={{ '--m': `${size}px` } as CSSProperties}>
        {members.map((a, i) => {
          const status = approvals.some((p) => p.agentId === a.id) ? 'wait' : working.has(a.id) ? 'work' : null
          const label = personFor(team, a.id).label
          return (
            <DashMember
              key={a.id}
              person={personFor(team, a.id)}
              size={size}
              status={status}
              tip={`${label}${status === 'work' ? ` · ${t('working')}` : status === 'wait' ? ` · ${t('awaiting approval')}` : ''}`}
              style={{ '--bob': `${5 + ((i * 7) % 5)}s`, '--bd': `${-((i * 0.83) % 6)}s` } as CSSProperties}
              onOpen={() => onOpenMember(a.id)}
            />
          )
        })}
      </div>
    </section>
  )
}
