import { useI18n } from '../i18n'
import { useState } from 'react'
import type { ApprovalRequest, Conversation, Team } from '../../../shared/types'
import { logoUrl } from '../api'
import { conversationAvatars, conversationTitle, formatTime, personFor } from '../people'
import { lastRead } from '../unread'
import { Avatar, AvatarCluster } from './Avatar'

interface SidebarProps {
  team: Team
  conversations: Conversation[]
  activeId: string
  /** Which page is showing: the dashboard or a chat. */
  view: 'dashboard' | 'chat'
  busy: Set<string>
  approvals: ApprovalRequest[]
  /** Bumped by the parent whenever read markers change, so badges refresh. */
  readTick: number
  onSelect: (id: string) => void
  onDashboard: () => void
  onMenu: (conversationId: string, x: number, y: number) => void
  onSettings: () => void
  onNewChat: () => void
  onSearch: () => void
  /** Hide the sidebar (or close the drawer on phones). */
  onClose: () => void
}

export function Sidebar({ team, conversations, activeId, view, busy, approvals, readTick, onSelect, onDashboard, onMenu, onSettings, onNewChat, onSearch, onClose }: SidebarProps) {
  const { t } = useI18n()
  const [q, setQ] = useState('')
  const [showHidden, setShowHidden] = useState(false)
  const [open, setOpen] = useState({ group: true, members: true })
  const owner = personFor(team, 'user')
  void readTick
  const logo = logoUrl(team.settings.logoVersion)
  const appName = team.settings.appName?.trim() || 'Yuzi Distributor - System Employee'
  const rank = (c: Conversation): number => {
    if (c.pinned) return -2
    if (c.id === 'group') return -1
    if (c.kind === 'group') return -0.5
    const agentId = c.memberIds.find((id) => id !== 'user')
    const i = team.agents.findIndex((a) => a.id === agentId)
    return i === -1 ? Number.MAX_SAFE_INTEGER : i
  }
  const ordered = [...conversations].sort((a, b) => rank(a) - rank(b) || (b.createdAt ?? 0) - (a.createdAt ?? 0))
  const filtered = ordered.filter((c) => conversationTitle(team, c).toLowerCase().includes(q.trim().toLowerCase()))
  const visible = filtered.filter((c) => !c.hidden)
  const groups = visible.filter((c) => c.kind === 'group')
  const dms = visible.filter((c) => c.kind !== 'group')
  const hidden = filtered.filter((c) => c.hidden)
  const attention = new Set(approvals.map((a) => a.conversationId))

  const row = (c: Conversation) => {
    const last = c.messages[c.messages.length - 1]
    const people = conversationAvatars(c).map((id) => personFor(team, id))
    const active = view === 'chat' && c.id === activeId
    const preview = last ? previewOf(team, c, last.authorId, last.text) : c.kind === 'group' ? 'Say hi to the team' : 'Start a conversation'
    const agent = c.kind === 'dm' ? people[0]?.agent : undefined
    const since = lastRead(c.id)
    const unread = active ? 0 : c.messages.filter((m) => m.authorId !== 'user' && m.status === 'done' && m.createdAt > since).length
    const needs = attention.has(c.id)
    return (
      <button
        key={c.id}
        type="button"
        className={`conversation${active ? ' is-active' : ''}${unread > 0 ? ' is-unread' : ''}`}
        onClick={() => onSelect(c.id)}
        onContextMenu={(e) => {
          e.preventDefault()
          onMenu(c.id, e.clientX, e.clientY)
        }}
      >
        <span className="conversation-avatar">
          <AvatarCluster people={people} size={c.kind === 'group' ? 40 : 44} />
        </span>
        <span className="conversation-body">
          <span className="conversation-row">
            <span className="conversation-title">
              {c.pinned && <PinIcon />}
              {conversationTitle(team, c)}
            </span>
            {agent?.department && <span className="badge">{agent.department}</span>}
            {agent?.muted && <span className="badge" title={t('Muted in groups')}>{t('muted')}</span>}
            {last && <span className="conversation-time">{formatTime(last.createdAt)}</span>}
          </span>
          <span className="conversation-row">
            <span className="conversation-preview">{preview}</span>
            {needs ? <span className="dot is-attention" title={t('Needs your approval')} /> : busy.has(c.id) ? <span className="dot" aria-label={t('Replying')} /> : unread > 0 ? <span className="unread">{unread > 99 ? '99+' : unread}</span> : null}
          </span>
        </span>
        <span
          className="conversation-more"
          role="button"
          tabIndex={-1}
          aria-label={t('More')}
          onClick={(e) => {
            e.stopPropagation()
            const r = (e.currentTarget as HTMLElement).getBoundingClientRect()
            onMenu(c.id, r.left, r.bottom + 4)
          }}
        >
          <MoreIcon />
        </span>
      </button>
    )
  }

  return (
    <aside className="sidebar">
      <div className="brand-row">
        {logo ? <img src={logo} alt="" className="brand-logo" /> : <span className="brand-logo brand-logo-placeholder">{appName.charAt(0).toUpperCase()}</span>}
        <span className="brand-name">{appName}</span>
        <button type="button" className="icon-button sidebar-close" onClick={onClose} aria-label={t('Hide sidebar')} title={t('Hide sidebar')}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            <path d="M15 6l-6 6 6 6" />
          </svg>
        </button>
      </div>
      <div className="sidebar-top">
        <button type="button" className="icon-button" title={t('Search (Ctrl+K)')} aria-label={t('Search')} onClick={onSearch}>
          <SearchIcon />
        </button>
        <button type="button" className="icon-button" title={t('New group chat')} aria-label={t('New group chat')} onClick={onNewChat}>
          <PlusIcon />
        </button>
      </div>
      <label className="search">
        <SearchIcon />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Filter')} />
      </label>
      <nav className="conversation-list">
        <button type="button" className={`nav-item${view === 'dashboard' ? ' is-active' : ''}`} onClick={onDashboard}>
          <span className="nav-icon">
            <DashboardIcon />
          </span>
          <span>{t('Dashboard')}</span>
        </button>
        <button type="button" className={`nav-section${open.group ? ' is-open' : ''}`} onClick={() => setOpen((o) => ({ ...o, group: !o.group }))} aria-expanded={open.group}>
          <span className="nav-icon">
            <ChatIcon />
          </span>
          <span>{t('Group chat')}</span>
          <span className="nav-count">{groups.length}</span>
          <ChevronIcon />
        </button>
        {open.group && groups.map(row)}
        <button type="button" className={`nav-section${open.members ? ' is-open' : ''}`} onClick={() => setOpen((o) => ({ ...o, members: !o.members }))} aria-expanded={open.members}>
          <span className="nav-icon">
            <UsersIcon />
          </span>
          <span>{t('Members')}</span>
          <span className="nav-count">{dms.length}</span>
          <ChevronIcon />
        </button>
        {open.members && dms.map(row)}
        {hidden.length > 0 && (
          <button type="button" className="hidden-toggle" onClick={() => setShowHidden((v) => !v)}>
            {showHidden ? 'Hide hidden chats' : `Show ${hidden.length} hidden chat${hidden.length === 1 ? '' : 's'}`}
          </button>
        )}
        {showHidden && hidden.map(row)}
      </nav>
      <div className="sidebar-bottom">
        <button type="button" className="sidebar-item" onClick={onSettings}>
          <span className="sidebar-item-icon">
            <GearIcon />
          </span>
          <span>{t('Settings')}</span>
        </button>
        <button type="button" className="sidebar-item" onClick={onSettings}>
          <Avatar person={owner} size={30} />
          <span>{owner.name}</span>
          <span className="muted small">{team.company}</span>
        </button>
      </div>
    </aside>
  )
}

function previewOf(team: Team, c: Conversation, authorId: string, text: string): string {
  const clean = text.replace(/\s+/g, ' ').trim()
  if (clean.length === 0) return `${personFor(team, authorId).name} is typing…`
  if (c.kind === 'dm' || authorId === 'user') return clean
  return `${personFor(team, authorId).name}: ${clean}`
}

function DashboardIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round">
      <rect x="3" y="3" width="6" height="7" rx="1.5" />
      <rect x="11" y="3" width="6" height="4" rx="1.5" />
      <rect x="3" y="12" width="6" height="5" rx="1.5" />
      <rect x="11" y="9" width="6" height="8" rx="1.5" />
    </svg>
  )
}

function ChatIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round">
      <path d="M4 4h12a1.5 1.5 0 0 1 1.5 1.5v7A1.5 1.5 0 0 1 16 14H9l-4 3v-3H4a1.5 1.5 0 0 1-1.5-1.5v-7A1.5 1.5 0 0 1 4 4z" />
    </svg>
  )
}

function UsersIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
      <circle cx="8" cy="7" r="3" />
      <path d="M2.5 16c.6-3 2.7-4.5 5.5-4.5s4.9 1.5 5.5 4.5" />
      <path d="M13 4.2a3 3 0 0 1 0 5.6M14.5 11.8c1.7.5 2.7 1.8 3 4" />
    </svg>
  )
}

function ChevronIcon() {
  return (
    <svg className="nav-chevron" width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 4l6 6-6 6" />
    </svg>
  )
}

function PlusIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
      <path d="M10 4v12M4 10h12" />
    </svg>
  )
}

function PinIcon() {
  return (
    <svg className="pin-icon" width="12" height="12" viewBox="0 0 20 20" fill="currentColor">
      <path d="M12 2l6 6-2 1-3-1-3 3 1 4-1 1-4-4-4 4-1-1 4-4-4-4 1-1 4 1 3-3-1-3z" />
    </svg>
  )
}

function SearchIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
      <circle cx="9" cy="9" r="6" />
      <path d="M14 14l3.5 3.5" />
    </svg>
  )
}

function GearIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
    </svg>
  )
}

function MoreIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
      <circle cx="4" cy="10" r="1.8" />
      <circle cx="10" cy="10" r="1.8" />
      <circle cx="16" cy="10" r="1.8" />
    </svg>
  )
}
