import { useEffect, useRef, useState } from 'react'
import { useI18n } from '../i18n'
import type { Person } from '../people'
import { Avatar, type FaceMood } from './Avatar'
import { useSleepState } from './faceTracker'

const SAYS = ['Ready!', 'Got a task?', 'Hehe', 'That tickles!', 'Keep going!', "Let's go!"]
const POKES: FaceMood[] = ['happy', 'wink', 'smug', 'surprised']
const rnd = (a: number, b: number) => a + Math.random() * (b - a)
const pick = <T,>(list: T[]): T => list[Math.floor(Math.random() * list.length)]!
const reduced = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

interface DashMemberProps {
  person: Person
  size: number
  /** Real status from the app: busy replying, or waiting for the owner's approval. */
  status: 'work' | 'wait' | null
  tip: string
  style: React.CSSProperties
  onOpen: () => void
}

/** One team member on the dashboard: wanders, hops, waves and reacts on its own, and shows its real status. */
export function DashMember({ person, size, status, tip, style, onOpen }: DashMemberProps) {
  const { t } = useI18n()
  const awake = useSleepState() === 'awake'
  const hopEl = useRef<HTMLSpanElement>(null)
  const [off, setOff] = useState({ x: 0, r: 0 })
  const [wave, setWave] = useState(false)
  const [mood, setMood] = useState<FaceMood | undefined>()
  const [say, setSay] = useState<string | null>(null)
  const sayTimer = useRef<number | undefined>(undefined)
  const clicks = useRef<number[]>([])

  const hop = () => {
    const el = hopEl.current
    if (!el) return
    el.classList.remove('is-hop')
    void el.getBoundingClientRect()
    el.classList.add('is-hop')
  }

  const speak = (text: string, ms = 1800) => {
    setSay(text)
    window.clearTimeout(sayTimer.current)
    sayTimer.current = window.setTimeout(() => setSay(null), ms)
  }

  // Idle life: drift sideways, hop now and then, wave once in a while, pull a quick face.
  useEffect(() => {
    if (!awake || status || reduced()) {
      setOff({ x: 0, r: 0 })
      setWave(false)
      return
    }
    let stopped = false
    const ids: number[] = []
    const later = (fn: () => void, ms: number) => {
      ids.push(window.setTimeout(() => !stopped && fn(), ms))
    }
    const wander = () => {
      setOff({ x: rnd(-11, 11), r: rnd(-7, 7) })
      later(wander, rnd(1500, 4000))
    }
    const jump = () => {
      hop()
      later(jump, rnd(3500, 9500))
    }
    const greet = () => {
      setWave(true)
      later(() => {
        setWave(false)
        later(greet, rnd(6000, 15000))
      }, 1500)
    }
    const face = () => {
      setMood(pick(POKES))
      later(() => {
        setMood(undefined)
        later(face, rnd(3500, 8000))
      }, rnd(900, 1700))
    }
    later(wander, rnd(200, 2500))
    later(jump, rnd(1200, 6500))
    later(greet, rnd(2500, 11000))
    later(face, rnd(2000, 7000))
    return () => {
      stopped = true
      ids.forEach(clearTimeout)
      setMood(undefined)
    }
  }, [awake, status])

  // Announce a status change with a hop and a short line.
  const prev = useRef(status)
  useEffect(() => {
    if (prev.current === status) return
    prev.current = status
    if (status === 'work') speak(t('On it…'), 2200)
    else if (status === 'wait') speak(t('Need your OK'), 3200)
    if (status) hop()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status])

  useEffect(() => () => window.clearTimeout(sayTimer.current), [])

  const poke = () => {
    const now = Date.now()
    clicks.current = [...clicks.current.filter((c) => now - c < 2200), now]
    const n = clicks.current.length
    hop()
    setWave(false)
    setMood(n >= 4 ? 'yinyang' : pick(POKES))
    speak(t(n >= 4 ? 'Dizzy…' : pick(SAYS)), n >= 4 ? 2200 : 1400)
    window.setTimeout(() => setMood(undefined), n >= 4 ? 2200 : 1200)
  }

  return (
    <button
      type="button"
      className={`dash-member${status ? ` is-${status}` : ''}`}
      style={style}
      onClick={() => {
        poke()
        window.setTimeout(onOpen, 260)
      }}
      onPointerEnter={() => {
        if (!status) setWave(true)
      }}
      onPointerLeave={() => setWave(false)}
      title={tip}
    >
      {status && <i className={`dash-dot is-${status}`} />}
      <span className="dm-move" style={{ transform: `translateX(${off.x}px) rotate(${off.r}deg)` }}>
        {say && <span className="dm-say">{say}</span>}
        <span className="dm-hop" ref={hopEl}>
          <Avatar person={person} size={size} lively hands wave={wave} {...(mood ? { mood } : status === 'wait' ? { mood: 'surprised' as FaceMood } : {})} />
        </span>
      </span>
      <span className="dash-member-name">{person.name}</span>
    </button>
  )
}
