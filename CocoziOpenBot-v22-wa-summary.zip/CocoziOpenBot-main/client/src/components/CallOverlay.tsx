import { useCallback, useEffect, useRef, useState } from 'react'
import type { Conversation, Team } from '../../../shared/types'
import { sendMessageFull } from '../api'
import { useI18n } from '../i18n'
import { personFor } from '../people'
import { Avatar, type FaceMood } from './Avatar'

/**
 * Voice call with an employee, no API key needed: the browser's own speech recognition
 * (Chrome / Edge / Electron) turns what you say into text, the text goes to the employee as a
 * normal chat message, and the answer is read out with the browser's speech synthesis.
 * Everything also shows up in the normal DM, so nothing is lost after hanging up.
 */

interface RecLike {
  lang: string
  interimResults: boolean
  continuous: boolean
  onresult: ((e: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0?: { transcript: string } }> }) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error?: string }) => void) | null
  start: () => void
  stop: () => void
  abort: () => void
}
type RecCtor = new () => RecLike

function recognitionCtor(): RecCtor | undefined {
  const w = window as unknown as { SpeechRecognition?: RecCtor; webkitSpeechRecognition?: RecCtor }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition
}

type Phase = 'listening' | 'thinking' | 'speaking' | 'muted' | 'error'

function speechLang(team: Team): string {
  const l = team.settings.language
  if (l === 'id') return 'id-ID'
  if (l === 'ar') return 'ar-EG'
  if (l === 'en') return 'en-US'
  const n = navigator.language
  return n.startsWith('id') ? 'id-ID' : n.startsWith('ar') ? 'ar-EG' : n
}

/** Make a chat answer pleasant to hear: no code, links, markdown symbols or emoji. */
export function toSpeech(text: string, max = 900): string {
  let s = text
    .replace(/```[\s\S]*?```/g, ' (kode ada di layar) ')
    .replace(/`([^`]*)`/g, '$1')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/https?:\/\/\S+/g, ' tautan ')
    .replace(/^\s{0,3}#{1,6}\s*/gm, '')
    .replace(/^\s*[-*•]\s+/gm, '')
    .replace(/[*_~>|]/g, '')
    .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, '')
    .replace(/\s+/g, ' ')
    .trim()
  if (s.length > max) {
    const cut = s.slice(0, max)
    const end = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('? '), cut.lastIndexOf('! '))
    s = `${(end > 200 ? cut.slice(0, end + 1) : cut).trim()} … selengkapnya ada di layar.`
  }
  return s
}

/** Split into short sentences: long utterances get cut off by some browsers. */
function chunks(text: string): string[] {
  const parts = text.match(/[^.!?…]+[.!?…]*\s*/g) ?? [text]
  const out: string[] = []
  let cur = ''
  for (const p of parts) {
    if ((cur + p).length > 180 && cur) {
      out.push(cur.trim())
      cur = p
    } else cur += p
  }
  if (cur.trim()) out.push(cur.trim())
  return out
}

interface CallOverlayProps {
  team: Team
  conversation: Conversation
  agentId: string
  typing: Set<string>
  pendingApprovals: number
  onClose: () => void
}

export function CallOverlay({ team, conversation, agentId, typing, pendingApprovals, onClose }: CallOverlayProps) {
  const { t } = useI18n()
  const person = personFor(team, agentId)
  const lang = speechLang(team)
  const Ctor = recognitionCtor()
  const canSpeak = typeof window !== 'undefined' && 'speechSynthesis' in window

  const [phase, setPhase] = useState<Phase>(Ctor ? 'listening' : 'error')
  const [heard, setHeard] = useState('')
  const [said, setSaid] = useState('')
  const [error, setError] = useState<string | null>(Ctor ? null : 'This browser has no speech recognition. Use Chrome or Edge, or type below.')
  const [draft, setDraft] = useState('')
  const [seconds, setSeconds] = useState(0)

  const phaseRef = useRef<Phase>(phase)
  const rec = useRef<RecLike | null>(null)
  const alive = useRef(true)
  const baseline = useRef<Set<string> | null>(null)
  const spoken = useRef<Set<string>>(new Set())
  const settle = useRef<ReturnType<typeof setTimeout> | null>(null)
  const thinkingSince = useRef(0)
  const failures = useRef(0)
  const mutedRef = useRef(false)
  // The callbacks above outlive renders: always read the latest conversation from here.
  const convRef = useRef(conversation)
  convRef.current = conversation

  const go = useCallback((p: Phase) => {
    phaseRef.current = p
    setPhase(p)
  }, [])

  useEffect(() => {
    const id = setInterval(() => setSeconds((s) => s + 1), 1000)
    return () => clearInterval(id)
  }, [])

  const stopRec = useCallback(() => {
    const r = rec.current
    rec.current = null
    if (r) {
      r.onend = null
      r.onerror = null
      r.onresult = null
      try {
        r.abort()
      } catch {
        // already stopped
      }
    }
  }, [])

  const send = useCallback(
    async (text: string) => {
      const clean = text.trim()
      if (!clean) return
      stopRec()
      setHeard(clean)
      baseline.current = new Set(convRef.current.messages.map((m) => m.id))
      thinkingSince.current = Date.now()
      go('thinking')
      try {
        await sendMessageFull(convRef.current.id, { text: clean })
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err))
        baseline.current = null
        go('error')
      }
    },
    [go, stopRec],
  )

  const listen = useCallback(() => {
    if (!alive.current) return
    if (!Ctor) {
      go('error')
      return
    }
    if (mutedRef.current) {
      stopRec()
      go('muted')
      return
    }
    stopRec()
    const r = new Ctor()
    r.lang = lang
    r.interimResults = true
    r.continuous = false
    let finalText = ''
    r.onresult = (e) => {
      let interim = ''
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i]
        const tr = res?.[0]?.transcript ?? ''
        if (res?.isFinal) finalText += `${tr} `
        else interim += tr
      }
      setHeard((finalText + interim).trim())
      failures.current = 0
    }
    r.onerror = (e) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        setError('Microphone blocked. Allow the microphone for this site, then call again.')
        go('error')
        stopRec()
      } else if (e.error === 'network') {
        failures.current += 1
        if (failures.current >= 3) {
          setError('Speech recognition needs an internet connection in this browser.')
          go('error')
          stopRec()
        }
      }
    }
    r.onend = () => {
      if (!alive.current || rec.current !== r) return
      rec.current = null
      if (finalText.trim()) void send(finalText)
      else if (phaseRef.current === 'listening') setTimeout(listen, 250)
    }
    rec.current = r
    setHeard('')
    go('listening')
    try {
      r.start()
    } catch {
      setTimeout(listen, 400)
    }
  }, [Ctor, go, lang, send, stopRec])

  const speak = useCallback(
    (text: string) => {
      const body = toSpeech(text)
      setSaid(text)
      if (!canSpeak || !body) {
        listen()
        return
      }
      stopRec()
      const synth = window.speechSynthesis
      synth.cancel()
      const voices = synth.getVoices()
      const base = lang.split('-')[0] ?? 'id'
      const voice = voices.find((v) => v.lang.toLowerCase() === lang.toLowerCase()) ?? voices.find((v) => v.lang.toLowerCase().startsWith(base))
      const parts = chunks(body)
      go('speaking')
      parts.forEach((part, i) => {
        const u = new SpeechSynthesisUtterance(part)
        u.lang = lang
        if (voice) u.voice = voice
        u.rate = 1.03
        if (i === parts.length - 1) {
          u.onend = () => {
            if (alive.current && phaseRef.current === 'speaking') listen()
          }
          u.onerror = u.onend
        }
        synth.speak(u)
      })
    },
    [canSpeak, go, lang, listen, stopRec],
  )

  // Start the first round of listening, and always hang up cleanly.
  useEffect(() => {
    alive.current = true
    if (Ctor) listen()
    return () => {
      alive.current = false
      if (settle.current) clearTimeout(settle.current)
      stopRec()
      if (canSpeak) window.speechSynthesis.cancel()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // While thinking: wait for the employee's answer to be complete, then read it out.
  useEffect(() => {
    if (phase !== 'thinking' || !baseline.current) return
    const fresh = conversation.messages.filter((m) => !baseline.current?.has(m.id) && m.authorId === agentId && !spoken.current.has(m.id))
    const streaming = fresh.some((m) => m.status === 'streaming') || typing.has(agentId)
    if (settle.current) clearTimeout(settle.current)
    if (fresh.length === 0 || streaming) return
    settle.current = setTimeout(() => {
      fresh.forEach((m) => spoken.current.add(m.id))
      const failed = fresh.every((m) => m.status === 'error')
      baseline.current = null
      speak(failed ? 'Maaf, ada kendala saat memproses itu.' : fresh.filter((m) => m.status === 'done').map((m) => m.text).join(' '))
    }, 1400)
  }, [phase, conversation.messages, typing, agentId, speak])

  // Give up waiting after a few minutes so the call never hangs forever.
  useEffect(() => {
    if (phase !== 'thinking') return
    const id = setInterval(() => {
      if (Date.now() - thinkingSince.current > 4 * 60_000) {
        baseline.current = null
        listen()
      }
    }, 5000)
    return () => clearInterval(id)
  }, [phase, listen])

  const toggleMute = () => {
    if (mutedRef.current) {
      mutedRef.current = false
      listen()
    } else {
      mutedRef.current = true
      stopRec()
      if (phaseRef.current === 'listening') go('muted')
    }
  }

  const skip = () => {
    if (canSpeak) window.speechSynthesis.cancel()
    if (phaseRef.current === 'speaking') listen()
  }

  const submitDraft = () => {
    const text = draft
    setDraft('')
    if (canSpeak) window.speechSynthesis.cancel()
    void send(text)
  }

  const mood: FaceMood = phase === 'thinking' ? 'thinking' : phase === 'speaking' ? 'happy' : phase === 'error' ? 'sad' : phase === 'muted' ? 'sleepy' : 'idle'
  const status =
    phase === 'listening'
      ? t('Listening…')
      : phase === 'thinking'
        ? pendingApprovals > 0
          ? t('Waiting for your approval on screen…')
          : t('Thinking…')
        : phase === 'speaking'
          ? t('Speaking…')
          : phase === 'muted'
            ? t('Mic is off')
            : t('Call problem')
  const mm = String(Math.floor(seconds / 60)).padStart(2, '0')
  const ss = String(seconds % 60).padStart(2, '0')

  return (
    <div className="call-overlay" role="dialog" aria-label={`${t('Call')} ${person.name}`}>
      <div className="call-card">
        <div className="call-time">{mm}:{ss}</div>
        <div className={`call-avatar is-${phase}`}>
          <Avatar person={person} size={132} mood={mood} />
        </div>
        <div className="call-name">{person.label}</div>
        <div className="call-status">{status}</div>
        {error && <div className="call-error">{t(error)}</div>}
        <div className="call-text" dir="auto">
          {phase === 'speaking' || phase === 'thinking' ? (phase === 'speaking' ? toSpeech(said, 400) : heard) : heard || ' '}
        </div>
        <div className="call-type">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && draft.trim() && submitDraft()}
            placeholder={t('Or type here and press Enter')}
          />
        </div>
        <div className="call-actions">
          <button type="button" className={`call-btn${phase === 'muted' ? ' is-on' : ''}`} onClick={toggleMute} disabled={!Ctor} aria-label={t('Mute microphone')} title={t('Mute microphone')}>
            <MicIcon off={phase === 'muted'} />
          </button>
          <button type="button" className="call-btn call-hangup" onClick={onClose} aria-label={t('End call')} title={t('End call')}>
            <PhoneIcon />
          </button>
          <button type="button" className="call-btn" onClick={skip} disabled={phase !== 'speaking'} aria-label={t('Skip')} title={t('Skip')}>
            <SkipIcon />
          </button>
        </div>
        <p className="call-hint">{t('Uses your browser microphone and voice. No API key. The conversation is also saved in the chat.')}</p>
      </div>
    </div>
  )
}

export function PhoneIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 4h3.5l1.7 4.2-2.1 1.3a11 11 0 005.4 5.4l1.3-2.1L19 14.5V18a2 2 0 01-2 2A13 13 0 013 6a2 2 0 012-2z" />
    </svg>
  )
}

function MicIcon({ off }: { off: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="3" width="6" height="11" rx="3" />
      <path d="M5.5 11a6.5 6.5 0 0013 0M12 17.5V21" />
      {off && <path d="M4 4l16 16" />}
    </svg>
  )
}

function SkipIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 5l9 7-9 7zM18 5v14" />
    </svg>
  )
}
