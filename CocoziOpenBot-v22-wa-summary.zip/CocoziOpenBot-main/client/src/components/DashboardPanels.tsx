import { useEffect, useMemo, useState } from 'react'
import type { AccountStatus, ApprovalRequest, Conversation, ProviderStatus, Routine, Team, UsageSummary } from '../../../shared/types'
import { providerStatuses } from '../api'
import { formatCost, formatTokens } from '../format'
import { useI18n } from '../i18n'
import { lastRead } from '../unread'
import type { SettingsSection } from './Settings'

interface PanelsProps {
  team: Team
  conversations: Conversation[]
  working: Set<string>
  usage: UsageSummary
  account: AccountStatus
  routines: Routine[]
  approvals: ApprovalRequest[]
  onOpenChat: (conversationId: string) => void
  onNewChat: () => void
  onSettings: (section: SettingsSection) => void
}

const excerpt = (text: string, max = 96) => {
  const t = text.replace(/[`*_>#]/g, '').replace(/\s+/g, ' ').trim()
  return t.length > max ? `${t.slice(0, max)}…` : t
}

export function DashboardPanels({ team, conversations, working, usage, account, routines, approvals, onOpenChat, onNewChat, onSettings }: PanelsProps) {
  const { t, rel: ago } = useI18n()
  const [providers, setProviders] = useState<ProviderStatus[] | null>(null)
  useEffect(() => {
    let live = true
    providerStatuses()
      .then((s) => live && setProviders(s))
      .catch(() => live && setProviders([]))
    return () => {
      live = false
    }
  }, [])

  const nameOf = (id: string) => team.agents.find((a) => a.id === id)?.name ?? id
  const chatName = (id: string) => conversations.find((c) => c.id === id)?.name ?? id

  // Today's spend, summed from per-message usage (same source as the Usage tab).
  const today = useMemo(() => {
    const since = new Date().setHours(0, 0, 0, 0)
    let cost = 0
    let tokens = 0
    for (const c of conversations) {
      for (const m of c.messages) {
        if (m.usage && m.createdAt >= since) {
          cost += m.usage.costUsd
          tokens += m.usage.inputTokens + m.usage.outputTokens
        }
      }
      for (const s of c.silent ?? []) {
        if (s.at >= since) {
          cost += s.usage.costUsd
          tokens += s.usage.inputTokens + s.usage.outputTokens
        }
      }
    }
    return { cost, tokens }
  }, [conversations, usage])

  const unread = conversations
    .filter((c) => !c.hidden)
    .map((c) => {
      const since = lastRead(c.id)
      const fresh = c.messages.filter((m) => m.authorId !== 'user' && m.status === 'done' && m.createdAt > since)
      return { c, n: fresh.length, last: fresh[fresh.length - 1]?.createdAt ?? 0 }
    })
    .filter((u) => u.n > 0)
    .sort((a, b) => b.last - a.last)
  const unreadTotal = unread.reduce((s, u) => s + u.n, 0)

  const feed = conversations
    .flatMap((c) => c.messages.filter((m) => m.authorId !== 'user' && m.status === 'done').map((m) => ({ m, c })))
    .sort((a, b) => b.m.createdAt - a.m.createdAt)
    .slice(0, 6)

  const upcoming = routines
    .filter((r) => r.enabled)
    .map((r) => ({ r, last: r.runs.reduce<Routine['runs'][number] | undefined>((x, y) => (!x || y.at > x.at ? y : x), undefined) }))
    .sort((a, b) => (a.r.nextRunAt ?? Infinity) - (b.r.nextRunAt ?? Infinity))
  const failing = upcoming.filter((u) => u.last?.status === 'error').length

  const limit = account.windows.five_hour
  const limitPct = limit?.utilization != null ? Math.round(limit.utilization * 100) : null
  const busyAgents = [...working]

  return (
    <div className="dash-panels">
      <div className="dash-actions">
        <button type="button" onClick={onNewChat}>{t('New chat')}</button>
        <button type="button" onClick={() => onSettings('routines')}>{t('New routine')}</button>
        <button type="button" onClick={() => onSettings('usage')}>{t('Usage')}</button>
      </div>

      <dl className="dash-stats">
        <div>
          <dt>{t('Working now')}</dt>
          <dd>{busyAgents.length}<small>{busyAgents.length ? ` · ${busyAgents.slice(0, 2).map(nameOf).join(', ')}${busyAgents.length > 2 ? '…' : ''}` : t(' · all idle')}</small></dd>
        </div>
        <div className={approvals.length ? 'is-hot' : ''}>
          <dt>{t('Awaiting approval')}</dt>
          <dd>{approvals.length}</dd>
        </div>
        <div>
          <dt>{t('Unread')}</dt>
          <dd>{unreadTotal}</dd>
        </div>
        <div>
          <dt>{t('Today')}</dt>
          <dd>{formatCost(today.cost)}<small> · {formatTokens(today.tokens)} {t('tokens')}</small></dd>
        </div>
      </dl>

      <div className="dash-grid">
        {(approvals.length > 0 || unread.length > 0) && (
          <section className="dash-panel is-wide">
            <h2>{t('Needs attention')}</h2>
            <ul>
              {approvals.map((a) => (
                <li key={a.id}>
                  <button type="button" onClick={() => onOpenChat(a.conversationId)}>
                    <i className="dash-dot is-wait" />
                    <span className="dp-main"><b>{nameOf(a.agentId)}</b> {t('asks permission for')} <code>{a.tool}</code> <span className="dp-sub">{excerpt(a.summary, 70)}</span></span>
                    <span className="dp-meta">{ago(a.createdAt)}</span>
                  </button>
                </li>
              ))}
              {unread.slice(0, 4).map(({ c, n, last }) => (
                <li key={c.id}>
                  <button type="button" onClick={() => onOpenChat(c.id)}>
                    <i className="dash-dot is-unread" />
                    <span className="dp-main"><b>{c.name}</b> <span className="dp-sub">{n} {t('new messages')}</span></span>
                    <span className="dp-meta">{ago(last)}</span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="dash-panel">
          <h2>{t('Recent activity')}</h2>
          {feed.length === 0 ? (
            <p className="dp-empty">{t('No activity yet. Say hi to the team.')}</p>
          ) : (
            <ul>
              {feed.map(({ m, c }) => (
                <li key={m.id}>
                  <button type="button" onClick={() => onOpenChat(c.id)}>
                    <span className="dp-main">
                      <b>{nameOf(m.authorId)}</b> <span className="dp-sub">{t('in')} {chatName(c.id)}</span>
                      <span className="dp-text">{excerpt(m.text) || (m.attachments?.length ? `${t('Sent files')}: ${m.attachments.length}` : '…')}</span>
                    </span>
                    <span className="dp-meta">{ago(m.createdAt)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="dash-panel">
          <h2>{t('Routines')}{failing > 0 && <span className="dp-flag">{failing} {t('failed')}</span>}</h2>
          {upcoming.length === 0 ? (
            <p className="dp-empty">{t('No active routines yet.')}</p>
          ) : (
            <ul>
              {upcoming.slice(0, 5).map(({ r, last }) => (
                <li key={r.id}>
                  <button type="button" onClick={() => onSettings('routines')}>
                    <i className={`dash-dot ${last?.status === 'error' ? 'is-err' : last ? 'is-ok' : ''}`} />
                    <span className="dp-main"><b>{r.name}</b> <span className="dp-sub">{nameOf(r.agentId)}{last?.status === 'error' ? ` · ${t('last run failed')}` : ''}</span></span>
                    <span className="dp-meta">{r.nextRunAt ? ago(r.nextRunAt) : t('via webhook')}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="dash-panel is-wide">
          <h2>{t('Providers')}</h2>
          <div className="dash-chips">
            {providers === null && <span className="dp-empty">{t('Checking logins…')}</span>}
            {providers?.map((p) => (
              <button key={p.id} type="button" className={`dash-chip ${p.ok ? 'is-ok' : 'is-err'}`} title={p.detail} onClick={() => onSettings('providers')}>
                <i className="dash-dot" />
                {team.providers[p.id]?.label ?? p.id}
                {!p.ok && <small>{t('not ready')}</small>}
              </button>
            ))}
            {limitPct !== null && (
              <span className="dash-limit" title={limit?.resetsAt ? `${t('Resets')} ${ago(limit.resetsAt)}` : undefined}>
                {t('Claude 5-hour limit')}
                <span className="dash-bar"><span style={{ width: `${Math.min(100, limitPct)}%` }} className={limitPct >= 80 ? 'is-high' : ''} /></span>
                {limitPct}%
              </span>
            )}
          </div>
        </section>
      </div>
    </div>
  )
}
