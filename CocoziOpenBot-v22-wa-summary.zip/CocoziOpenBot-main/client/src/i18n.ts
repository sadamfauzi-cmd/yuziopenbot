import { useSyncExternalStore } from 'react'

/** UI language. Per device (localStorage), separate from the language employees reply in. */
export type Lang = 'en' | 'id'
export type LangPref = 'auto' | Lang

const KEY = 'ogb.uiLang'
const listeners = new Set<() => void>()

function readPref(): LangPref {
  try {
    const v = localStorage.getItem(KEY)
    return v === 'en' || v === 'id' ? v : 'auto'
  } catch {
    return 'auto'
  }
}

let pref: LangPref = readPref()

const resolve = (p: LangPref): Lang => (p === 'auto' ? (navigator.language.toLowerCase().startsWith('id') ? 'id' : 'en') : p)

export function setLangPref(next: LangPref): void {
  pref = next
  try {
    localStorage.setItem(KEY, next)
  } catch {
    // storage may be unavailable
  }
  listeners.forEach((l) => l())
}

/** English text is the key. A missing translation falls back to the English text itself. */
const ID: Record<string, string> = {
  // app
  'Opening the office…': 'Membuka kantor…',
  'Reconnecting to the office…': 'Menyambung ulang ke kantor…',
  // sidebar
  Dashboard: 'Dasbor',
  'Group chat': 'Chat grup',
  Members: 'Anggota',
  Settings: 'Pengaturan',
  Filter: 'Filter',
  Search: 'Cari',
  'Search (Ctrl+K)': 'Cari (Ctrl+K)',
  'Hide sidebar': 'Sembunyikan sidebar',
  'New group chat': 'Chat grup baru',
  More: 'Lainnya',
  muted: 'senyap',
  'Muted in groups': 'Disenyapkan di grup',
  'Needs your approval': 'Butuh persetujuanmu',
  Replying: 'Sedang membalas',
  // voice call
  Call: 'Telepon',
  'Listening…': 'Mendengarkan…',
  'Thinking…': 'Berpikir…',
  'Speaking…': 'Berbicara…',
  'Mic is off': 'Mic mati',
  'Call problem': 'Ada masalah',
  'Waiting for your approval on screen…': 'Menunggu persetujuanmu di layar…',
  'Or type here and press Enter': 'Atau ketik di sini lalu tekan Enter',
  'Mute microphone': 'Matikan mic',
  'End call': 'Akhiri telepon',
  Skip: 'Lewati',
  'Uses your browser microphone and voice. No API key. The conversation is also saved in the chat.': 'Memakai mikrofon dan suara browser. Tanpa API key. Percakapan juga tersimpan di chat.',
  'This browser has no speech recognition. Use Chrome or Edge, or type below.': 'Browser ini tidak punya pengenalan suara. Pakai Chrome atau Edge, atau ketik di bawah.',
  'Microphone blocked. Allow the microphone for this site, then call again.': 'Mikrofon diblokir. Izinkan mikrofon untuk situs ini, lalu telepon lagi.',
  'Speech recognition needs an internet connection in this browser.': 'Pengenalan suara di browser ini butuh koneksi internet.',
  // composer
  'Message the {0} team': 'Kirim pesan ke tim {0}',
  'Message {0}': 'Kirim pesan ke {0}',
  'Attach files': 'Lampirkan file',
  'Attach files (or drop them here)': 'Lampirkan file (atau seret ke sini)',
  'Uploading…': 'Mengunggah…',
  'Cancel reply': 'Batal membalas',
  Remove: 'Hapus',
  Send: 'Kirim',
  Dictate: 'Dikte',
  'Stop dictation': 'Hentikan dikte',
  'Stop the team': 'Hentikan tim',
  'Replying to': 'Membalas',
  // settings
  General: 'Umum',
  Team: 'Tim',
  Providers: 'Provider',
  Marketplace: 'Marketplace',
  Routines: 'Routine',
  Skills: 'Skill',
  Usage: 'Pemakaian',
  'Claude account': 'Akun Claude',
  'Employees reply in': 'Karyawan membalas dalam bahasa',
  'Auto mirrors whatever language you write in.': 'Auto mengikuti bahasa yang kamu pakai.',
  'Auto (match me)': 'Auto (ikuti saya)',
  'Egyptian Arabic': 'Arab Mesir',
  English: 'Inggris',
  Indonesian: 'Indonesia',
  'Interface language': 'Bahasa tampilan',
  'Only changes menus and labels on this device. Employees keep replying in the language above.': 'Hanya mengubah menu dan label di perangkat ini. Karyawan tetap membalas dalam bahasa di atas.',
  'Auto (browser)': 'Auto (browser)',
  // marketplace
  'Ready-made skills': 'Skill siap pakai',
  Needs: 'Butuh',
  'from the list above': 'dari daftar di atas',
  Add: 'Tambah',
  Added: 'Sudah ditambah',
  // dashboard
  'Ready!': 'Siap!',
  'Got a task?': 'Ada tugas?',
  'Keep going!': 'Semangat!',
  'On it…': 'Dikerjakan…',
  'Need your OK': 'Butuh OK-mu',
  Welcome: 'Selamat Datang',
  'Say hi to the bot': 'Sapa bot',
  'Hello!': 'Halo!',
  'Hi~': 'Hai~',
  'Need a hand?': 'Ada yang bisa dibantu?',
  Hehe: 'Hehe',
  'That tickles!': 'Geli tau!',
  "Let's work together!": 'Yuk kerja bareng!',
  'Dizzy…': 'Pusing…',
  'Ouch!': 'Auw!',
  'New chat': 'Chat baru',
  'New routine': 'Routine baru',
  'Working now': 'Bekerja sekarang',
  ' · all idle': ' · semua santai',
  'Awaiting approval': 'Menunggu approval',
  Unread: 'Belum dibaca',
  Today: 'Hari ini',
  tokens: 'token',
  'Needs attention': 'Perlu perhatian',
  'asks permission for': 'minta izin',
  'new messages': 'pesan baru',
  'Recent activity': 'Aktivitas terbaru',
  'No activity yet. Say hi to the team.': 'Belum ada aktivitas. Sapa tim dulu.',
  in: 'di',
  'Sent files': 'Mengirim file',
  failed: 'gagal',
  'No active routines yet.': 'Belum ada routine aktif.',
  'last run failed': 'run terakhir gagal',
  'via webhook': 'via webhook',
  'Checking logins…': 'Mengecek login…',
  'not ready': 'belum siap',
  'Claude 5-hour limit': 'Limit Claude 5 jam',
  'Resets': 'Reset',
  working: 'sedang bekerja',
  'awaiting approval': 'menunggu approval',
}

const UNITS = {
  en: { s: 'second', m: 'minute', h: 'hour', d: 'day' },
  id: { s: 'detik', m: 'menit', h: 'jam', d: 'hari' },
} as const

function relative(ts: number, lang: Lang): string {
  const diff = ts - Date.now()
  const abs = Math.abs(diff)
  const [u, size] = abs < 60_000 ? (['s', 1000] as const) : abs < 3_600_000 ? (['m', 60_000] as const) : abs < 86_400_000 ? (['h', 3_600_000] as const) : (['d', 86_400_000] as const)
  const n = Math.max(1, Math.round(abs / size))
  const unit = UNITS[lang][u]
  if (lang === 'id') return diff > 0 ? `dalam ${n} ${unit}` : abs < 45_000 ? 'baru saja' : `${n} ${unit} lalu`
  const word = `${n} ${unit}${n === 1 ? '' : 's'}`
  return diff > 0 ? `in ${word}` : abs < 45_000 ? 'just now' : `${word} ago`
}

export interface I18n {
  lang: Lang
  pref: LangPref
  /** Translate an English string; `{0}`, `{1}` are replaced by args. */
  t: (text: string, ...args: (string | number)[]) => string
  /** Relative time in the UI language. */
  rel: (ts: number) => string
}

function build(): I18n {
  const lang = resolve(pref)
  const t = (text: string, ...args: (string | number)[]) => {
    const base = lang === 'id' ? (ID[text] ?? text) : text
    return args.length ? base.replace(/\{(\d+)\}/g, (_, i: string) => String(args[Number(i)] ?? '')) : base
  }
  return { lang, pref, t, rel: (ts) => relative(ts, lang) }
}

let snapshot = build()
listeners.add(() => {
  snapshot = build()
})

export function useI18n(): I18n {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb)
      return () => listeners.delete(cb)
    },
    () => snapshot,
  )
}
