import type { McpServerDef, Skill } from '../../shared/types'

export interface MarketplaceItem {
  id: string
  name: string
  category: 'Featured' | 'Developer' | 'Productivity' | 'Data' | 'Web'
  description: string
  icon: string
  def: McpServerDef
  /** Environment variables the user must fill in before it works. */
  secrets?: { key: string; label: string }[]
  /** Command-line args the user may edit (e.g. a folder path). */
  argHint?: string
}

const npx = (pkg: string, args: string[] = []): McpServerDef => ({ type: 'stdio', command: 'npx', args: ['-y', pkg, ...args] })

/** Ready-to-add MCP servers. All run locally through npx; secrets stay in team.json on this machine. */
export const MARKETPLACE: MarketplaceItem[] = [
  { id: 'github', name: 'GitHub', category: 'Featured', icon: '🐙', description: 'Issues, pull requests, repos and code search.', def: npx('@modelcontextprotocol/server-github'), secrets: [{ key: 'GITHUB_PERSONAL_ACCESS_TOKEN', label: 'Personal access token' }] },
  { id: 'playwright', name: 'Playwright', category: 'Featured', icon: '🎭', description: 'Drive a real, visible browser window: open pages, click, fill forms, screenshot. You can watch the employee work.', def: npx('@playwright/mcp@latest') },
  { id: 'filesystem', name: 'Filesystem', category: 'Featured', icon: '📁', description: 'Read and write files in extra folders outside the workspace.', def: npx('@modelcontextprotocol/server-filesystem', ['e:/fortune projects']), argHint: 'Last argument is the folder to expose.' },
  { id: 'fetch', name: 'Fetch', category: 'Web', icon: '🌐', description: 'Fetch any URL and convert it to markdown for the employee to read.', def: { type: 'stdio', command: 'uvx', args: ['mcp-server-fetch'] } },
  { id: 'memory', name: 'Memory', category: 'Productivity', icon: '🧠', description: 'A knowledge graph the employee can remember facts in across chats.', def: npx('@modelcontextprotocol/server-memory') },
  { id: 'sequential', name: 'Sequential Thinking', category: 'Productivity', icon: '🪜', description: 'Structured step-by-step reasoning for hard problems.', def: npx('@modelcontextprotocol/server-sequential-thinking') },
  { id: 'postgres', name: 'Postgres', category: 'Data', icon: '🐘', description: 'Query a Postgres / Supabase database (read-only by default).', def: npx('@modelcontextprotocol/server-postgres', ['postgresql://user:pass@host:5432/db']), argHint: 'Replace the connection string.' },
  { id: 'sqlite', name: 'SQLite', category: 'Data', icon: '🗄️', description: 'Query and inspect a local SQLite file.', def: { type: 'stdio', command: 'uvx', args: ['mcp-server-sqlite', '--db-path', 'e:/fortune projects/app.db'] }, argHint: 'Point --db-path at the database file.' },
  { id: 'supabase', name: 'Supabase', category: 'Data', icon: '⚡', description: 'Manage Supabase projects, tables, SQL and edge functions.', def: npx('@supabase/mcp-server-supabase@latest'), secrets: [{ key: 'SUPABASE_ACCESS_TOKEN', label: 'Access token' }] },
  { id: 'slack', name: 'Slack', category: 'Productivity', icon: '💬', description: 'Read channels and post messages in your Slack workspace.', def: npx('@modelcontextprotocol/server-slack'), secrets: [{ key: 'SLACK_BOT_TOKEN', label: 'Bot token' }, { key: 'SLACK_TEAM_ID', label: 'Team id' }] },
  { id: 'notion', name: 'Notion', category: 'Productivity', icon: '📝', description: 'Search and edit Notion pages and databases.', def: npx('@notionhq/notion-mcp-server'), secrets: [{ key: 'NOTION_TOKEN', label: 'Integration token' }] },
  { id: 'brave', name: 'Brave Search', category: 'Web', icon: '🦁', description: 'Web search through the Brave API (in addition to built-in WebSearch).', def: npx('@modelcontextprotocol/server-brave-search'), secrets: [{ key: 'BRAVE_API_KEY', label: 'API key' }] },
  { id: 'context7', name: 'Context7', category: 'Developer', icon: '📚', description: 'Up-to-date library and framework documentation for coding.', def: npx('@upstash/context7-mcp@latest') },
  { id: 'vercel', name: 'Vercel', category: 'Developer', icon: '▲', description: 'Deployments, projects and logs on Vercel.', def: { type: 'http', url: 'https://mcp.vercel.com' } },
  { id: 'chrome', name: 'Chrome DevTools', category: 'Developer', icon: '🧪', description: 'Inspect pages, console, network and performance in Chrome.', def: npx('chrome-devtools-mcp@latest') },
  { id: 'gmail', name: 'Gmail', category: 'Productivity', icon: '📧', description: 'Read, search, send emails and manage drafts/labels through your Gmail account.', def: npx('@gongrzhe/server-gmail-autoauth-mcp'), secrets: [{ key: 'GMAIL_OAUTH_PATH', label: 'Path to gcp-oauth.keys.json (Google Cloud OAuth client)' }] },
  { id: 'gdrive', name: 'Google Drive', category: 'Productivity', icon: '🗂️', description: 'List, search, read and edit files (incl. Google Sheets) in your Google Drive.', def: npx('@isaacphi/mcp-gdrive'), secrets: [{ key: 'CLIENT_ID', label: 'Google OAuth Client ID' }, { key: 'CLIENT_SECRET', label: 'Google OAuth Client Secret' }, { key: 'GDRIVE_CREDS_DIR', label: 'Folder to store the OAuth token' }] },
  { id: 'whatsapp', name: 'WhatsApp', category: 'Productivity', icon: '💬', description: 'Read chats and send/reply to WhatsApp messages. Unofficial (WhatsApp Web automation) — scan a QR code on first run; carries some ToS risk.', def: npx('@lizzythelizard/whatsapp-mcp') },
]

export interface SkillItem {
  id: string
  icon: string
  /** MCP server ids (keys of team.mcpServers) the skill needs. */
  needs?: string[]
  skill: Skill
}

/** Ready-to-add skills. Adding one saves it to team.json; invoke it with /id in the composer. */
export const SKILL_MARKETPLACE: SkillItem[] = [
  {
    id: 'isi-form',
    icon: '🧾',
    needs: ['playwright'],
    skill: {
      name: 'Isi Google Form dari gambar',
      description: 'Baca angka dari gambar lampiran, minta konfirmasi, lalu isi Google Form lewat browser Playwright yang terlihat.',
      body: `Tugas: baca data dari gambar yang dilampirkan, lalu isikan ke Google Form lewat browser Playwright (tool mcp__playwright__browser_*). Browser tampil di layar bos, jadi kerjakan pelan dan rapi. Ikuti urutan ini:

1. BACA GAMBAR. Buka file lampiran dengan tool Read. Catat setiap nilai beserta labelnya persis seperti tertulis. Jangan menebak: kalau ada angka yang buram atau meragukan, tulis "?" dan sebutkan alasannya.
2. TAMPILKAN TABEL. Balas dengan tabel Label | Nilai hasil bacaan, tandai yang meragukan, lalu TUNGGU konfirmasi bos. Lewati langkah ini hanya kalau bos sudah bilang "langsung isi".
3. BUKA FORM. Pakai browser_navigate ke link form, lalu browser_snapshot untuk melihat semua pertanyaan. Cocokkan tiap pertanyaan dengan data dari gambar. Kalau ada kolom wajib yang tidak ada datanya, tanyakan ke bos, jangan diisi sembarang.
4. LOGIN. Kalau form minta login Google, berhenti dan minta bos login langsung di jendela browser yang terbuka, lalu lanjut setelah bos bilang sudah.
5. ISI. Isi kolom satu per satu (browser_fill_form / browser_type / browser_click). Ketik angka persis seperti di tabel yang sudah dikonfirmasi. Setelah tiap halaman, ambil snapshot untuk memastikan isinya benar.
6. PERIKSA SEBELUM KIRIM. Bandingkan isi form dengan tabel. Kalau ada yang beda, perbaiki dulu. Klik Kirim hanya setelah semua cocok.
7. LAPORKAN. Pastikan halaman konfirmasi ("Jawaban Anda telah direkam") muncul, lalu ringkas apa saja yang terkirim. Kalau tidak yakin form sudah terkirim, tanyakan ke bos dan jangan kirim ulang, supaya tidak ada data ganda.

Aturan: jangan mengarang angka, jangan mengirim form dua kali, dan jangan membuka situs lain selain form yang diminta.`,
    },
  },
  {
    id: 'isi-metering',
    icon: '⏱️',
    needs: ['playwright'],
    skill: {
      name: 'Metering Site Panjang (Google Form)',
      description: 'Isi form METERING SITE PANJANG ruangan demi ruangan lewat browser Playwright. Tiap halaman diperlihatkan ke kamu dulu sebagai approval.',
      body: `Tugas: isi Google Form "METERING SITE PANJANG" lewat browser Playwright (tool mcp__playwright__browser_*, jendelanya tampil di layar bos).
Link form: https://docs.google.com/forms/d/e/1FAIpQLSe3aMcawzpNUKZX-ehbUmpsitzShuR7HzgN1DDZoWmkkICaLQ/viewform
Catatan dari form: untuk metering jam 23:00, form harus dikirim maksimal jam 23:59. Ingatkan bos kalau waktunya mepet.

YANG DIKASIH BOS DI CHAT (tanya hanya kalau ada yang kurang):
- Waktu metering, misalnya "jam 07:00".
- Nama teknisi.
- Urutan ruangan, dari atas ke bawah, sesuai yang bos tulis.
- Angka hasil metering tiap ruangan, dari gambar lampiran atau ditulis langsung. Baca gambar dengan tool Read. Angka yang meragukan ditandai "?" dan jangan ditebak.

PILIHAN DROPDOWN HALAMAN 1 (cocokkan jawaban bos persis ke salah satunya; kalau ragu, tanya):
- WAKTU METERING: 01:00, 03:00, 05:00, 07:00, 09:00, 11:00, 13:00, 15:00, 17:00, 19:00, 21:00, 23:00.
- TEKNISI: Yuda S, Iyan S, Janter S, Pramadhita A, Reyzi A, Alvi H, Abdilla, Rivayanto, Sadam F, Zulkifli D, Dwi Widyanto, Bambang W, Ari K, Satrio P.
Form ini sampai 25 halaman dan halaman setelah halaman 1 bergantung pada pilihan sebelumnya (ruangan, lalu isian per ruangan). Jadi setiap halaman baru: baca dulu isinya, jangan mengarang.

ALUR (patuhi urutannya):
1. KONFIRMASI AWAL. Sebelum membuka form, tulis ringkasan: waktu, teknisi, urutan ruangan, dan tabel angka per ruangan. Tunggu bos bilang lanjut.
2. HALAMAN 1. browser_navigate ke link form, lalu browser_snapshot. Pilih WAKTU METERING dan TEKNISI di dropdown (browser_select_option, atau klik dropdown lalu pilih opsinya), lalu klik Next.
3. TIAP HALAMAN BERIKUTNYA. Ambil snapshot dan daftar semua pertanyaan di halaman itu beserta opsi dropdown-nya. Pilih ruangan sesuai urutan dari bos. Sebelum mengisi, kirim ke bos "kartu approval" di chat: nama halaman/ruangan, tiap kolom, dan nilai yang akan diisi. TUNGGU bos membalas ok. Kalau bos mengoreksi, pakai nilai koreksinya. Setelah ok, isi kolom, ambil snapshot untuk memastikan benar, lalu klik Next.
4. PERTANYAAN AKHIR "pindah ruangan atau selesai". Jangan memilih sendiri. Tanyakan ke bos: pindah ke ruangan berikutnya (sebutkan nama ruangan berikutnya dari urutan bos) atau selesai. Pilih sesuai jawaban bos, lalu ulangi langkah 3 untuk ruangan berikutnya.
5. SEBELUM SUBMIT. Setelah bos memilih "selesai", rangkum semua ruangan dan nilai yang sudah diisi, dan minta approval terakhir. Klik Submit hanya setelah bos menjawab ok. Kartu approval dari aplikasi untuk tombol Submit juga akan muncul, jadi itu bukan masalah.
6. SETELAH SUBMIT. Pastikan halaman konfirmasi ("Your response has been recorded" atau "Jawaban Anda telah direkam") muncul, lalu lapor ke bos. Kalau tidak yakin form terkirim, tanya bos dan jangan submit ulang.

ATURAN: jangan mengarang atau membulatkan angka, jangan lompat halaman, jangan klik Submit tanpa approval, jangan mengisi form dua kali, dan jangan membuka situs lain. Kalau halaman di luar dugaan (kolom wajib tanpa data, halaman error, minta login), berhenti dan tanya bos. Setelah selesai, tulis ringkasan struktur halaman yang kamu temui (urutan halaman, kolom, opsi dropdown) supaya skill ini bisa disempurnakan.`,
    },
  },
]
