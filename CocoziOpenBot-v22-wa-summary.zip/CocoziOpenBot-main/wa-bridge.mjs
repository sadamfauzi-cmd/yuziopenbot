#!/usr/bin/env node
/**
 * wa-bridge.mjs — jembatan antara WhatsApp pribadimu (login via QR, seperti WhatsApp Web)
 * dan satu employee CocoziOpenBot (biasanya si manager).
 *
 * Alurnya:
 *   1. Kamu kirim WA ke nomor yang di-link (nomormu sendiri atau nomor cadangan).
 *   2. Bridge ini meneruskan isi pesan itu sebagai chat baru ke DM manager di CocoziOpenBot.
 *   3. Manager (dan tim yang dia panggil) memproses seperti biasa di CocoziOpenBot.
 *   4. Begitu manager selesai membalas, bridge ini mengirim balasannya balik ke WhatsApp
 *      yang sama.
 *
 * DUA CARA JALANIN INI:
 *
 *   A) Otomatis bareng server CocoziOpenBot (disarankan — cuma 1 proses yang perlu tetap hidup):
 *      Set WA_BRIDGE_ENABLED=1 sebelum `npm start` / `npm run dev` / `npm run desktop`.
 *      Server akan import file ini dan panggil startWaBridge() sendiri setelah dia listen,
 *      pakai URL & token dirinya sendiri secara otomatis. QR muncul di terminal/log server
 *      yang sama (di desktop app, cek jendela "Logs"/console kalau ada, atau jalankan
 *      `npm start` dulu dari terminal biasa sekali saja buat scan awal).
 *
 *   B) Berdiri sendiri, proses terpisah (kalau mau bridge-nya independen dari server):
 *        npm install whatsapp-web.js qrcode-terminal   (sudah ada di package.json ini)
 *        node wa-bridge.mjs
 *      Lalu scan QR yang muncul di terminal pakai WhatsApp di HP:
 *      WhatsApp → Pengaturan → Perangkat Tertaut → Tautkan Perangkat.
 *      Terminal ini harus tetap terbuka selama bridge mau aktif menerima/membalas pesan.
 *
 * Sesi WhatsApp tersimpan di folder .wa-session/, jadi tidak perlu scan ulang tiap start
 * (kecuali logout dari HP / folder dihapus / lama tidak dipakai).
 *
 * whatsapp-web.js & qrcode-terminal ada di "optionalDependencies" package.json, bukan
 * "dependencies" biasa — supaya kalau download Chromium bawaan puppeteer gagal (jaringan
 * kantor/firewall yang blokir storage.googleapis.com), `npm install` PROJECT INI TETAP
 * SUKSES (server, client, dsb tetap kepasang), cuma fitur WhatsApp bridge yang nonaktif
 * sampai kamu benerin jaringannya lalu `npm install whatsapp-web.js qrcode-terminal` ulang.
 * Kalau memang tidak mau download Chromium sama sekali, set env var
 * PUPPETEER_EXECUTABLE_PATH ke lokasi Chrome yang sudah ada di komputermu sebelum install.
 *
 * Konfigurasi via environment variable (opsional, ada default di bawah):
 *   COCOZIOPENBOT_URL      contoh: http://127.0.0.1:4310 (default). Saat dipanggil otomatis
 *                         dari server (cara A), ini diisi otomatis sesuai PORT/HOST server,
 *                         jadi biasanya tidak perlu diset manual.
 *   COCOZIOPENBOT_TOKEN    isi hanya kalau server CocoziOpenBot dijalankan dengan
 *                         COCOZIOPENBOT_TOKEN=... (server-side auth token). Saat cara A,
 *                         otomatis dipakaikan token yang sama dengan server.
 *   MANAGER_AGENT_ID     id employee tujuan di team.json, contoh: "MNG-01" (id tetap milik manager).
 *                         (Lihat field "id" di team.json / team.example.json.)
 *   WA_ALLOWED_NUMBERS   opsional, whitelist nomor (format 62xxxxxxxxxx, tanpa "+"),
 *                         pisahkan koma. Kosongkan untuk terima dari siapa saja yang
 *                         chat ke nomor yang ditautkan.
 *
 *   WA_NUMBER_NAMES      opsional, nama tiap nomor supaya manager tahu SIAPA yang chat (bukan
 *                         selalu dianggap pemilik/bos). Format: nomor=Nama, pisahkan koma.
 *                         Contoh: WA_NUMBER_NAMES='6281234567890=Budi,6289876543210=Sari'
 *                         Tanpa ini, dipakai nama tampilan WhatsApp si pengirim.
 *   WA_NOTIFY_WINDOW_MIN default 240: berapa menit setelah WA terakhir, laporan karyawan
 *                         lain (yang masuk ke DM manager) masih diteruskan ke WA itu. 0 = matikan.
 *
 *   WA_FORWARD_REPORTS   default 0. Manager otomatis merangkum hasil karyawan lalu membalas ke WA.
 *                         Set 1 kalau laporan mentah tiap karyawan juga mau ikut dikirim ke WA.
 *
 *   FITUR SUARA (voice note + penanganan telepon masuk):
 *   WhatsApp TIDAK menyediakan cara resmi bagi bot (akun yang ditautkan via QR) untuk
 *   mengangkat / melakukan panggilan suara. Jadi yang dibuat: kamu kirim VOICE NOTE ->
 *   ditranskrip -> manager menjawab -> balasannya dibacakan balik sebagai voice note.
 *   Telepon yang masuk ke nomor bot otomatis ditolak sopan + diarahkan ke voice note.
 *   Perlu API key untuk STT (suara->teks) dan TTS (teks->suara), format OpenAI-compatible:
 *   WA_VOICE_API_KEY     API key (default: OPENAI_API_KEY). Tanpa ini, voice note dibalas
 *                         "belum dikonfigurasi" dan fitur teks tetap jalan normal.
 *   WA_VOICE_BASE_URL    default https://api.openai.com/v1
 *   WA_STT_MODEL         default whisper-1
 *   WA_STT_LANGUAGE      default id (kode bahasa ISO-639-1; kosongkan utk auto-detect)
 *   WA_TTS_MODEL         default tts-1
 *   WA_TTS_VOICE         default alloy
 *   WA_VOICE_REPLY       voice (default: balas voice note saja) | both (voice + teks) | text
 *   WA_REJECT_CALLS      default 1: telepon masuk ditolak + dibalas pesan. Set 0 utk biarkan.
 *
 *   WA_BRIDGE_ENABLED    dipakai oleh server/index.ts: set "1" biar bridge ini otomatis
 *                         start bareng server. Tidak dipakai saat dijalankan manual (cara B).
 */

import pkg from 'whatsapp-web.js'
const { Client, LocalAuth, MessageMedia } = pkg
import qrcode from 'qrcode-terminal'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { existsSync, unlinkSync, writeFileSync } from 'node:fs'

let started = false
/** Samakan format nomor: hanya angka, dan 08xx diubah jadi 628xx. Jadi "+62 812-3456", "0812..." dan "62812..." dianggap sama. */
function normNumber(raw) {
  const d = String(raw ?? '').replace(/\D/g, '')
  return d.startsWith('0') ? `62${d.slice(1)}` : d
}
/** QR login WhatsApp sebagai teks polos, supaya bisa dibaca lewat `cat` tanpa awalan log pm2. */
const QR_FILE = path.resolve(process.cwd(), 'wa-qr.txt')

/**
 * Menyalakan bridge. Aman dipanggil sekali dari server (cara A) atau otomatis di
 * bawah file ini kalau dijalankan langsung lewat `node wa-bridge.mjs` (cara B).
 * @param {{ baseUrl?: string, token?: string, agentId?: string, allowedNumbers?: string[] }} opts
 */
export async function startWaBridge(opts = {}) {
  if (started) {
    console.log('[wa-bridge] sudah jalan, skip start kedua.')
    return
  }
  started = true

  const BASE = (opts.baseUrl ?? process.env.COCOZIOPENBOT_URL ?? 'http://127.0.0.1:4310').replace(/\/$/, '')
  const TOKEN = opts.token ?? process.env.COCOZIOPENBOT_TOKEN ?? ''
  const AGENT_ID = opts.agentId ?? process.env.MANAGER_AGENT_ID ?? 'MNG-01'
  const CONVERSATION_ID = `dm-${AGENT_ID}`
  const ALLOWED =
    opts.allowedNumbers ??
    (process.env.WA_ALLOWED_NUMBERS ?? '')
      .split(',')
      .map((s) => normNumber(s))
      .filter(Boolean)

  // nomor -> nama, supaya dua nomor (atau lebih) yang boleh chat ke bot dikenali sebagai orang berbeda.
  const NAMES = new Map(
    (opts.numberNames ? Object.entries(opts.numberNames).map(([k, v]) => `${k}=${v}`) : (process.env.WA_NUMBER_NAMES ?? '').split(','))
      .map((pair) => {
        const m = String(pair).match(/^\s*([^=:]+?)\s*[=:]\s*(.+?)\s*$/)
        return m ? [normNumber(m[1]), m[2]] : null
      })
      .filter(Boolean),
  )
  const NOTIFY_WINDOW_MS = Number(process.env.WA_NOTIFY_WINDOW_MIN ?? 240) * 60_000

  function headers(extra = {}) {
    return {
      'Content-Type': 'application/json',
      ...(TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {}),
      ...extra,
    }
  }

  // ---- Suara: STT (voice note -> teks) & TTS (teks -> voice note) ----
  const VOICE_KEY = process.env.WA_VOICE_API_KEY ?? process.env.OPENAI_API_KEY ?? ''
  const VOICE_BASE = (process.env.WA_VOICE_BASE_URL ?? 'https://api.openai.com/v1').replace(/\/$/, '')
  const STT_MODEL = process.env.WA_STT_MODEL ?? 'whisper-1'
  const STT_LANG = process.env.WA_STT_LANGUAGE ?? 'id'
  const TTS_MODEL = process.env.WA_TTS_MODEL ?? 'tts-1'
  const TTS_VOICE = process.env.WA_TTS_VOICE ?? 'alloy'
  const VOICE_REPLY = (process.env.WA_VOICE_REPLY ?? 'voice').toLowerCase()
  const REJECT_CALLS = (process.env.WA_REJECT_CALLS ?? '1') !== '0'
  const MAX_TTS_CHARS = 1500

  async function transcribe(base64, mimetype) {
    const buf = Buffer.from(base64, 'base64')
    const clean = (mimetype || 'audio/ogg').split(';')[0]
    const ext = clean.includes('mpeg') ? 'mp3' : clean.includes('mp4') ? 'm4a' : clean.includes('wav') ? 'wav' : 'ogg'
    const form = new FormData()
    form.append('file', new Blob([buf], { type: clean }), `voice.${ext}`)
    form.append('model', STT_MODEL)
    if (STT_LANG) form.append('language', STT_LANG)
    const res = await fetch(`${VOICE_BASE}/audio/transcriptions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${VOICE_KEY}` },
      body: form,
      signal: AbortSignal.timeout(60_000),
    })
    if (!res.ok) throw new Error(`STT ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`)
    const json = await res.json()
    return String(json.text ?? '').trim()
  }

  // Bersihkan markdown supaya enak dibacakan, bukan dibaca "bintang bintang".
  function toSpeakable(text) {
    return text
      .replace(/```[\s\S]*?```/g, ' (ada kode, lihat di chat) ')
      .replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1')
      .replace(/[*_`#>~|]/g, '')
      .replace(/^\s*[-•]\s+/gm, '')
      .replace(/\s+/g, ' ')
      .trim()
  }

  async function synthesize(text) {
    const res = await fetch(`${VOICE_BASE}/audio/speech`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${VOICE_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: TTS_MODEL, voice: TTS_VOICE, input: text, response_format: 'opus' }),
      signal: AbortSignal.timeout(60_000),
    })
    if (!res.ok) throw new Error(`TTS ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`)
    return Buffer.from(await res.arrayBuffer()).toString('base64')
  }

  // Antrean FIFO: satu entri per pesan WA yang diteruskan, sesuai urutan ronde manager.
  // Entri paling depan = pesan WA yang sedang diproses manager (semua balasan manager di ronde
  // itu dikirim ke chat WA tersebut). Setelah ronde selesai entri dilepas dan chat-nya dicatat
  // sebagai `lastChat`, supaya laporan karyawan lain yang masuk SESUDAH manager membalas
  // (hasil delegasi) tetap diteruskan ke WA yang sama, bukan hilang.
  const pending = []
  let lastChat = null // { chatId, at }

  // Nama pemilik & karyawan dari server, buat label dan catatan identitas pengirim.
  let teamInfo = { owner: '', agents: new Map(), at: 0 }
  async function loadTeamInfo() {
    if (Date.now() - teamInfo.at < 60_000) return teamInfo
    try {
      const res = await fetch(`${BASE}/api/state`, { headers: headers() })
      if (res.ok) {
        const st = await res.json()
        teamInfo = {
          owner: String(st?.team?.owner?.name ?? ''),
          agents: new Map((st?.team?.agents ?? []).map((a) => [a.id, a.name])),
          at: Date.now(),
        }
      }
    } catch {
      // pakai info lama / kosong
    }
    return teamInfo
  }

  async function forwardToCocoziOpenBot(fromLabel, text, chatId, viaVoice = false, number = '') {
    const info = await loadTeamInfo()
    const ownerFirst = info.owner.split(/\s+/)[0]?.toLowerCase() ?? ''
    const isOwner = ownerFirst && fromLabel.toLowerCase().includes(ownerFirst)
    const who = number && number !== fromLabel ? `${fromLabel} (${number})` : fromLabel
    // Manager selalu diberi tahu bahwa DM ini "dengan bos". Kalau yang chat orang lain, tegaskan.
    const identity = !isOwner
      ? `\n(Pengirim pesan ini adalah ${fromLabel}${info.owner ? `, BUKAN ${info.owner}` : ''}. Sapa dan balas ke ${fromLabel} dengan namanya, jangan panggil dia ${info.owner || 'bos'}.)`
      : ''
    pending.push({ chatId, viaVoice })
    try {
      const res = await fetch(`${BASE}/api/conversations/${CONVERSATION_ID}/messages`, {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({
          text: viaVoice
            ? `[WhatsApp VOICE NOTE dari ${who}, hasil transkrip]: ${text}${identity}\n(Balasanmu akan DIBACAKAN sebagai voice note: jawab singkat, natural, bahasa lisan, tanpa markdown/tabel/kode.)`
            : `[WhatsApp dari ${who}]: ${text}${identity}`,
        }),
      })
      if (!res.ok) {
        pending.pop()
        console.error('[wa-bridge] gagal kirim ke CocoziOpenBot:', res.status, await res.text().catch(() => ''))
      }
    } catch (err) {
      pending.pop()
      console.error('[wa-bridge] tidak bisa menghubungi CocoziOpenBot:', err.message)
    }
  }

  async function sendReply(waClient, chatId, reply, viaVoice) {
    try {
      let sentVoice = false
      if (viaVoice && VOICE_REPLY !== 'text' && VOICE_KEY) {
        const speak = toSpeakable(reply)
        if (speak && speak.length <= MAX_TTS_CHARS) {
          try {
            const audio = await synthesize(speak)
            await waClient.sendMessage(chatId, new MessageMedia('audio/ogg; codecs=opus', audio, 'balasan.ogg'), { sendAudioAsVoice: true })
            sentVoice = true
          } catch (err) {
            console.error('[wa-bridge] TTS gagal, kirim teks saja:', err.message)
          }
        }
      }
      if (!sentVoice || VOICE_REPLY === 'both') await waClient.sendMessage(chatId, reply)
      console.log(`[wa-bridge] balasan dikirim ke ${chatId}${sentVoice ? ' (voice note)' : ''}`)
    } catch (err) {
      console.error(`[wa-bridge] gagal kirim balasan ke ${chatId}:`, err.message)
    }
  }

  async function handleEvent(waClient, event) {
    // Ronde manager selesai -> lepas pesan WA yang tadi diproses, ingat chat-nya.
    if (event.type === 'round' && event.conversationId === CONVERSATION_ID) {
      if (event.running === true) {
        if (pending[0]) pending[0].active = true
      } else if (pending[0]?.active) {
        // Hanya ronde yang memang melayani pesan WA yang melepas antrean (ronde rangkuman/web tidak).
        const done = pending.shift()
        lastChat = { chatId: done.chatId, at: Date.now() }
      }
      return
    }
    if (event.type !== 'message:done') return
    const m = event.message
    if (!m || m.conversationId !== CONVERSATION_ID || !m.text?.trim()) return

    // 1) Manager bicara: kirim ke WA yang sedang dilayani (atau WA terakhir kalau ronde sudah lewat).
    if (m.authorId === AGENT_ID) {
      const target = pending[0] ?? (lastChat && Date.now() - lastChat.at < NOTIFY_WINDOW_MS ? lastChat : null)
      if (!target) return
      await sendReply(waClient, target.chatId, m.text.trim(), Boolean(target.viaVoice))
      if (!pending[0] && lastChat) lastChat.at = Date.now()
      return
    }

    // 2) Karyawan lain melapor ke DM manager (hasil delegasi): kabari WA terakhir.
    if (m.authorId === 'user' || m.authorId === 'routine') return
    if (m.status && m.status !== 'done') return
    // Default: mati. Manager sendiri yang merangkum hasil karyawan lalu membalas ke WA.
    // Set WA_FORWARD_REPORTS=1 kalau mau laporan mentah tiap karyawan ikut dikirim juga.
    if (process.env.WA_FORWARD_REPORTS !== '1' || NOTIFY_WINDOW_MS <= 0) return
    const target = pending[0] ?? (lastChat && Date.now() - lastChat.at < NOTIFY_WINDOW_MS ? lastChat : null)
    if (!target) return
    const info = await loadTeamInfo()
    const name = info.agents.get(m.authorId) ?? m.authorId
    await sendReply(waClient, target.chatId, `📋 *${name}* melapor:\n${m.text.trim()}`, false)
    if (lastChat) lastChat.at = Date.now()
  }

  async function listenForReplies(waClient) {
    const url = `${BASE}/api/events${TOKEN ? `?token=${encodeURIComponent(TOKEN)}` : ''}`
    for (;;) {
      try {
        const res = await fetch(url, { headers: headers() })
        if (!res.ok || !res.body) throw new Error(`gagal connect ke /api/events: ${res.status}`)
        const reader = res.body.getReader()
        const decoder = new TextDecoder()
        let buf = ''
        for (;;) {
          const { value, done } = await reader.read()
          if (done) break
          buf += decoder.decode(value, { stream: true })
          let idx
          while ((idx = buf.indexOf('\n\n')) !== -1) {
            const chunk = buf.slice(0, idx)
            buf = buf.slice(idx + 2)
            const line = chunk.split('\n').find((l) => l.startsWith('data: '))
            if (!line) continue
            let event
            try {
              event = JSON.parse(line.slice(6))
            } catch {
              continue
            }
            await handleEvent(waClient, event)
          }
        }
      } catch (err) {
        console.error('[wa-bridge] koneksi event ke CocoziOpenBot terputus, coba lagi 3 detik lagi:', err.message)
        await new Promise((r) => setTimeout(r, 3000))
      }
    }
  }

  // Di VPS / Docker (sering jalan sebagai root) Chromium wajib --no-sandbox, kalau tidak gagal start.
  // PUPPETEER_EXECUTABLE_PATH (opsional) = pakai Chrome/Chromium yang sudah terpasang.
  const wa = new Client({
    authStrategy: new LocalAuth({ dataPath: '.wa-session' }),
    puppeteer: {
      headless: true,
      ...(process.env.PUPPETEER_EXECUTABLE_PATH ? { executablePath: process.env.PUPPETEER_EXECUTABLE_PATH } : {}),
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
    },
  })

  wa.on('qr', (qr) => {
    // Lewat pm2 setiap baris log diberi awalan + timestamp sehingga QR di `pm2 logs` rusak/terpotong.
    // Jadi QR juga ditulis ke file teks polos: di server jalankan `cat wa-qr.txt` (QR berganti tiap ~20 detik).
    qrcode.generate(qr, { small: true }, (art) => {
      try {
        writeFileSync(QR_FILE, art)
      } catch {
        // folder tidak bisa ditulis: QR tetap ada di log kalau terminal interaktif
      }
      if (process.stdout.isTTY) {
        console.log('[wa-bridge] scan QR ini pakai WhatsApp di HP kamu (Pengaturan → Perangkat Tertaut):')
        console.log(art)
      } else {
        console.log(`[wa-bridge] QR baru siap. Lihat di terminal server: cat ${QR_FILE}  (atau: watch -n 2 cat ${QR_FILE})`)
      }
    })
  })

  wa.on('ready', () => {
    try {
      if (existsSync(QR_FILE)) unlinkSync(QR_FILE)
    } catch {
      // abaikan
    }
    console.log(`[wa-bridge] WhatsApp tersambung. Pesan masuk akan diteruskan ke employee "${AGENT_ID}" di CocoziOpenBot (${BASE}).`)
    listenForReplies(wa)
  })

  wa.on('auth_failure', (msg) => {
    console.error('[wa-bridge] gagal login WhatsApp:', msg)
  })

  wa.on('disconnected', (reason) => {
    console.error('[wa-bridge] WhatsApp terputus:', reason, '— hapus folder .wa-session/ lalu jalankan ulang kalau perlu scan QR baru.')
  })

  // Telepon masuk: WhatsApp tidak mengizinkan bot mengangkat/bicara di panggilan, jadi
  // tolak dengan sopan dan arahkan ke voice note. (Event bernama 'incoming_call' di
  // whatsapp-web.js baru, 'call' di versi lama — dua-duanya didengar, dedupe pakai id.)
  const seenCalls = new Set()
  async function onCall(call) {
    if (!REJECT_CALLS || !call || call.fromMe || seenCalls.has(call.id)) return
    seenCalls.add(call.id)
    if (seenCalls.size > 200) seenCalls.clear()
    const number = String(call.from ?? '').split('@')[0]
    if (ALLOWED.length > 0 && !ALLOWED.includes(normNumber(number))) return
    console.log(`[wa-bridge] telepon masuk dari ${number}${call.isVideo ? ' (video)' : ''} — ditolak`)
    try {
      await call.reject()
    } catch (err) {
      console.warn('[wa-bridge] gagal menolak telepon:', err.message)
    }
    try {
      await wa.sendMessage(
        call.from,
        VOICE_KEY
          ? 'Maaf, aku nggak bisa angkat telepon WhatsApp. Kirim *voice note* aja ya — nanti aku dengarkan lalu balas dengan voice note juga 🎙️'
          : 'Maaf, aku nggak bisa angkat telepon WhatsApp. Kirim pesan teks aja ya, nanti langsung kujawab.',
      )
    } catch (err) {
      console.warn('[wa-bridge] gagal kirim pesan setelah tolak telepon:', err.message)
    }
  }
  wa.on('incoming_call', onCall)
  wa.on('call', onCall)

  wa.on('message', async (msg) => {
    if (msg.fromMe) return
    // Cek grup dari JID langsung (bukan msg.getChat()) — whatsapp-web.js versi terbaru
    // punya bug dimana getChat()/getChatById() bisa crash dengan error "r: r" setelah
    // update WhatsApp Web (github.com/wwebjs/whatsapp-web.js/issues/201838). Grup selalu
    // berakhiran "@g.us", jadi kita bisa skip tanpa menyentuh fungsi yang bermasalah itu.
    if (msg.from.endsWith('@g.us')) return // hanya chat pribadi, biar grup WA nggak ke-spam balasan manager
    // Status/Story kontak (status@broadcast), daftar siaran dan channel juga lewat event ini: bukan chat untuk bot.
    // Hanya chat pribadi (@c.us / @lid) yang diteruskan.
    if (msg.isStatus || !/@(c\.us|lid)$/.test(msg.from)) return

    let number = msg.from.split('@')[0]
    let label = number
    try {
      const contact = await msg.getContact()
      number = contact.number ?? number
      label = contact.pushname || contact.name || number
    } catch (err) {
      // getContact() kadang kena bug yang sama; tetap lanjut pakai nomor mentah dari JID
      // supaya pesan tetap diteruskan walau nama kontaknya nggak kebaca.
      console.warn('[wa-bridge] gagal ambil nama kontak (lanjut pakai nomor mentah):', err.message)
    }

    if (ALLOWED.length > 0 && !ALLOWED.includes(normNumber(number))) {
      console.log(`[wa-bridge] pesan dari ${number} diabaikan (tidak ada di WA_ALLOWED_NUMBERS)`)
      return
    }
    // Nama dari WA_NUMBER_NAMES menang atas nama tampilan WhatsApp.
    label = NAMES.get(normNumber(number)) ?? label
    if (msg.type === 'ptt' || msg.type === 'audio') {
      if (!VOICE_KEY) {
        await wa.sendMessage(msg.from, 'Voice note belum aktif (API key suara belum diset). Kirim teks dulu ya.').catch(() => {})
        return
      }
      try {
        const media = await msg.downloadMedia()
        if (!media?.data) throw new Error('media kosong')
        const heard = await transcribe(media.data, media.mimetype)
        if (!heard) {
          await wa.sendMessage(msg.from, 'Maaf, aku nggak nangkep isi voice note-nya. Coba rekam ulang atau kirim teks ya.').catch(() => {})
          return
        }
        console.log(`[wa-bridge] voice note dari ${label}: ${heard}`)
        await forwardToCocoziOpenBot(label, heard, msg.from, true, number)
      } catch (err) {
        console.error('[wa-bridge] gagal proses voice note:', err.message)
        await wa.sendMessage(msg.from, 'Maaf, voice note-nya gagal diproses. Coba kirim teks dulu ya.').catch(() => {})
      }
      return
    }
    if (!msg.body) return
    console.log(`[wa-bridge] pesan masuk dari ${label}: ${msg.body}`)
    await forwardToCocoziOpenBot(label, msg.body, msg.from, false, number)
  })

  await wa.initialize()
}

// Cara B: dijalankan langsung lewat `node wa-bridge.mjs` (bukan di-import server).
const isMain = process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])
if (isMain) {
  startWaBridge().catch((err) => {
    console.error('[wa-bridge] gagal start:', err)
    process.exit(1)
  })
}
