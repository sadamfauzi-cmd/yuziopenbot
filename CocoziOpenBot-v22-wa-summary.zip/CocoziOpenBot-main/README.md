# CocoziOpenBot — the open-source Grok Bot alternative

**Looking for a Grok Bot alternative?** CocoziOpenBot gives you the same thing people loved in xAI/Cursor's Grok Bot, a *company of AI employees debating in a group chat*, but open source, running on your own machine, on the subscriptions you already pay for: **Claude** (Claude Code login), **ChatGPT** (Codex CLI login), **Google Gemini** (Gemini CLI login, the same account Antigravity uses), or **any OpenAI-compatible API** (Kimi, OpenRouter, DeepSeek, Groq, xAI Grok, Ollama…).

No Cursor Pro. No SuperGrok. No trial that ends. No "Upgrade to Pro" wall. MIT licensed.

![CocoziOpenBot demo: a strategy question is routed to the manager, backend and sales; a build request goes to one developer who ships a hero page with preview cards; an approval card stops a shell command](docs/demo.gif)

```
You:    We got our first enterprise lead: a 200-person fintech wants SSO and a 99.9% SLA
        before signing a $40k/year deal. Do we say yes?
KHALED: Yes, with conditions: 99.5% with credits, SSO in 60 days. @ADAM can you scope SSO by Wednesday?
ADAM:   > Bash list workspace   > Write backend/sso-scope.md
        Written. About 13 working days with a hosted SSO service; hand-built SAML is where the holes are.
KARIM:  I'll ask the client which identity provider they use and whether 99.5% + a step-up clause works.

You:    Build me a dark landing-page hero for "Lumen Notes" as a single HTML file, then screenshot it.
OMAR:   > Write frontend/lumen-notes-hero.html   > Bash screenshot desktop + mobile
        Done: lumen-notes-hero.html  [preview cards appear in the chat]
```

![Group chat with smart routing: one question, the three relevant employees, one file written](docs/screenshots/group-chat.png)

## Grok Bot vs CocoziOpenBot

| | Grok Bot (xAI / Cursor) | CocoziOpenBot |
|---|---|---|
| Price | Cursor Pro or SuperGrok subscription; free trial ends | Free. Uses the Claude / ChatGPT / Gemini plan you already have, or any API key |
| Models | Grok only (Cursor's cloud picks) | Claude Opus/Sonnet/Haiku, GPT/Codex, Gemini, Kimi, DeepSeek, Grok via xAI API, local Ollama… per employee |
| Where it runs | Cursor's cloud "computer" | Your machine. Nothing leaves it except calls to the provider you chose |
| Employees talk to each other | ✅ | ✅ Mentions, rounds, muting, "mentions only" mode |
| Real tools | ✅ | ✅ Read/edit files, run commands, web search, subagents, MCP servers |
| Plugins / MCP | Marketplace | Marketplace of MCP servers (GitHub, Playwright, Postgres, Supabase, Slack, Notion, Context7, Vercel…) + custom |
| Usage & limits | Plan usage only | Tokens and cost per message, per employee, per conversation, per model; Claude limit windows |
| Approvals & auto-review | ✅ | ✅ Allow once / Always allow / Deny cards, rules by tool and input |
| Routines (schedule + webhook triggers) | ✅ | ✅ cron presets + `POST /api/hooks/<id>` |
| Attachments & result previews | ✅ | ✅ files in, HTML/image cards out |
| Long-term memory per bot | ✅ | ✅ editable notes per employee |
| Skills (`/`) | ✅ + teach by demo | ✅ saved skills; teach-by-demo not yet |
| Search, threads, unread, hide | ✅ | ✅ Ctrl+K search, reply-to, unread, hide, mark unread |
| Phone | Native apps | PWA over your own server |
| Edit employees | Name, label, description | Everything: provider, model, effort, personality, tools, permissions, working folder, MCP, mute, duplicate |
| Group chats | ✅ | ✅ Any subset of the team, pin, rename, export to Markdown |
| Arabic / RTL | Partial | Native RTL, replies in Egyptian Arabic when you write Arabic; Bahasa Indonesia reply language and UI (Settings → General) |
| Source | Closed | MIT, TypeScript, ~5k lines you can read in an afternoon |

## What you get

- **A team, not a chatbot.** Five employees ship in the box, all speaking Indonesian: Budi (Manager), Sari (Admin), Dimas (Logistik), Raka (Teknologi) and Andi (Metering, with a visible Playwright browser). Each has a personality, a color, an avatar shape and a department badge. Add, duplicate, mute or delete anyone in two clicks.
- **They talk to each other, without the noise.** A fast dispatcher reads each message and picks the one to three employees whose job it is; a "build me X" goes to exactly one builder who builds first and talks second. Mention someone (`@OMAR`) and only they answer; `@everyone` for a real all-hands. Employees pull colleagues in with mentions, rounds are capped so nobody loops, and everyone has a lane they stay in.
- **They do real work.** Employees use Claude Code / Codex / Gemini tools in your workspace: read repos, grep, edit files, run commands, search the web. Tool activity streams live under the message. Permissions and working folder are per employee.
- **Bring your own subscription.** Claude Code, Codex CLI and Gemini CLI use their own logins. Every employee picks a provider and model, so your manager can be Opus, your dev can be Codex, and your intern can be a free local Ollama model.
- **MCP marketplace.** One click each, enabled per employee, or point an employee at your whole `~/.claude` setup.
- **Usage and limits.** Tokens and API-equivalent cost everywhere; your Claude subscription's limit windows with reset times.
- **Approvals in the chat.** Set an employee to "ask before Bash/Write/Edit" (or before everything) and each risky tool call shows a card: Allow once, Always allow, Deny. Auto-review rules ("require approval for Write when the path contains production") decide automatically.
- **Routines.** Schedule a job for one employee (cron presets: every morning, weekdays at 9…) or fire it from a webhook (Slack, GitHub, Zapier, any cron service): `POST /api/hooks/<id>`. Results land in the chat with run history.
- **Files both ways, with previews.** Drop images, PDFs, spreadsheets or code into the composer; employees read them with their tools. Anything an employee creates or wants to show you arrives as an attachment card: images and SVGs inline, HTML pages rendered in a sandbox, PDFs, video and audio players, Markdown rendered, CSV/JSON/code as text, Office files as cards. Expand, Open with the OS app, or download.
- **Long-term memory.** Each employee keeps notes across conversations (your preferences, project facts, their commitments), rewritten by a cheap model after they speak. Editable and clearable in their profile.
- **Skills.** Save a way of doing a task and invoke it with `/name` in the composer. Claude employees can also use your `~/.claude/skills`.
- **Grok Bot conveniences.** Reply to a message, @everyone, unread badges, "needs attention" dot, hide chats, mark unread, Ctrl+K search across all messages, voice dictation, desktop notifications, export/import employees as JSON, pins, export to Markdown.
- **Desktop, browser, or phone.** Electron window, a browser tab, or install it as a PWA on your phone when the server runs with `HOST=0.0.0.0 COCOZIOPENBOT_TOKEN=…` (on a VPS, or your PC over Tailscale).

| Build request, then preview cards | Approval card | Routines |
|---|---|---|
| ![Build with previews](docs/screenshots/build-preview.png) | ![Approval](docs/screenshots/approval.png) | ![Routines](docs/screenshots/routines.png) |

| Providers | Usage | Marketplace |
|---|---|---|
| ![Providers](docs/screenshots/providers.png) | ![Usage](docs/screenshots/usage.png) | ![Marketplace](docs/screenshots/marketplace.png) |

## Install

Requirements: Node 20+ and at least one of these signed in on your machine:

| Provider | How it signs in | Install |
|---|---|---|
| Claude (Anthropic) | `claude` CLI, your Claude Pro/Max login | `npm i -g @anthropic-ai/claude-code` then `claude` |
| Codex (OpenAI) | `codex login`, your ChatGPT/Codex subscription | `npm i -g @openai/codex` then `codex login` |
| Gemini (Google) | `gemini` once, your Google account (same as Antigravity) | `npm i -g @google/gemini-cli` then `gemini` |
| Any API | An API key you paste in Settings → Providers | Nothing to install |

```bash
git clone https://github.com/Z4YT0N/CocoziOpenBot
cd CocoziOpenBot
npm install
npm run build
npm run desktop        # desktop window (Electron)
# or:  npm start       # then open http://127.0.0.1:4310
```

First start copies `team.example.json` to `team.json`. Open Settings → General to set your name, company and workspace folder, then say hi to the team.

> Windows note: if `node_modules/electron/dist` has no `electron.exe` after install, unzip the cached `electron-v*-win32-x64.zip` from `%LOCALAPPDATA%\electron\Cache\<hash>\` into that folder and write `electron.exe` into `node_modules/electron/path.txt`. The `npm run desktop` launcher also strips `ELECTRON_RUN_AS_NODE`, which VS Code terminals export.

## How providers work

| | Claude | Codex | Gemini | API |
|---|---|---|---|---|
| Runs through | Claude Agent SDK (Claude Code) | `codex exec --json` | `gemini --output-format json` | `POST /chat/completions` |
| Billing | Subscription login, or API key if you add one | ChatGPT subscription, or `OPENAI_API_KEY` | Google account, or `GEMINI_API_KEY` | Your key |
| Memory | Resumable session per employee per chat | Resumable thread per employee per chat | Recent transcript each turn | Recent transcript each turn |
| Tools | Read/Edit/Bash/Glob/Grep/WebSearch/WebFetch/subagents + MCP | Codex's own tools; sandbox follows the employee's tools | Gemini's own tools; approval mode follows the employee's tools | Built-in local tools: read/list/search/edit/write files, run commands, fetch URLs + MCP servers (needs a model with tool calling) |
| Effort | ✅ | ✅ (`model_reasoning_effort`) | ignored | ignored |

Prompts go to the CLIs over stdin, never as arguments, so Arabic and other non-ASCII text survive Windows shells. API keys live in `team.json` on your disk (git-ignored) and are never returned to the browser.

## FAQ

**Is there a free alternative to Grok Bot?**
Yes, this one. CocoziOpenBot is MIT licensed and runs locally. The only cost is whatever AI plan you already have (Claude, ChatGPT, Gemini) or the API you point it at. A free local model through Ollama works too.

**Can I use Grok Bot with Claude, ChatGPT or Gemini?**
Grok Bot itself can't; its models are picked by Cursor's cloud. CocoziOpenBot was built for exactly that: each employee runs on Claude Code, Codex CLI, Gemini CLI or an API of your choice.

**Does it work with my Claude subscription without an API key?**
Yes. It drives Claude Code through the official Agent SDK, which uses your existing `claude` login. Any `ANTHROPIC_API_KEY` in your environment is ignored unless you add a key on purpose.

**Can I still use Grok itself?**
Yes, add xAI as an API provider (`https://api.x.ai/v1`) and give an employee `grok-4` or `grok-code-fast-1`.

**Is this affiliated with xAI, Cursor or Oracle's OpenGrok?**
No. "Grok Bot" is xAI/Cursor's product; Oracle's OpenGrok is an unrelated code-search engine. CocoziOpenBot is an independent open-source project.

**Does it speak Arabic?**
Yes. Replies mirror your language (Egyptian Arabic when you write Arabic, technical terms stay in English), the UI is RTL-aware, and you can force Arabic or English in Settings.

## بديل Grok Bot مفتوح المصدر

![الفريق بيتناقش بالعربي المصري](docs/screenshots/group-chat-arabic.png)

CocoziOpenBot هو بديل مجاني ومفتوح المصدر لـ Grok Bot (بتاع xAI وCursor): شركة كاملة من الموظفين الذكاء الاصطناعي في جروب شات واحد، كل موظف له شخصية ودور وأدوات حقيقية، وبيتناقشوا مع بعض ومعاك. بيشتغل على اشتراك Claude أو ChatGPT (Codex) أو Gemini اللي عندك أصلًا، أو أي API زي Kimi أو OpenRouter أو Ollama محلي. بيرد بالعربي المصري لما تكتب عربي، والواجهة بتدعم RTL. مفيش Cursor Pro ولا SuperGrok ولا trial بينتهي.

## Settings

- **General:** company, your name, workspace, group reply mode (smart routing / everyone / mentions only), reply language (auto / Egyptian Arabic / English), notifications, round caps, auto-review rules.
- **Routines** and **Skills:** see above.
- **Team:** every employee; click to edit name, role, label, color, shape, provider, model, effort, personality, tools, permissions, working folder, MCP servers, auto-approve, mute.
- **Providers:** status of each CLI login, API keys, and any number of OpenAI-compatible providers with presets (Kimi, xAI, OpenRouter, DeepSeek, Groq, OpenAI, Mistral, Ollama).
- **Marketplace:** one-click MCP servers or a custom stdio/HTTP/SSE server.
- **Usage:** totals, by employee, by conversation, by model.
- **Claude account:** login type, Claude Code version, limit windows, refresh.

Right-click any chat for Pin, Rename/Edit chat, Edit profile, Mute, Duplicate, Export as Markdown, Clear, Delete.

## `team.json`

Everything the UI edits lives here. Safe to edit by hand; restart afterwards.

| field | meaning |
|---|---|
| `agents[].provider` | Key into `providers` (`claude`, `codex`, `gemini`, or one you added). |
| `agents[].model`, `effort` | Model id for that provider (`default` = the CLI's own default) and `low` … `max`. |
| `agents[].tools`, `permissionMode`, `cwd`, `autoApproveTools` | What the employee may do and where. |
| `agents[].mcpServers`, `inheritClaudeSettings` | `mcpServers`: team MCP servers to enable. Works for Claude and API employees (CocoziOpenBot starts the server and exposes its tools to the model; Codex/Gemini employees don't use it yet). `inheritClaudeSettings`: Claude only, loads your `~/.claude` setup. |
| `agents[].muted` | Only speaks in groups when mentioned. |
| `providers` | `{ kind, label, apiKey?, baseUrl?, models? }`. Built-ins `claude`, `codex`, `gemini` always exist. |
| `agents[].scope` | One line of what they own; drives smart routing and stay-in-lane behavior. |
| `agents[].approvals` | `auto`, `ask-dangerous`, `ask-all`. |
| `skills` | `{ id: { name, description, body } }`, invoked with `/id`. |
| `settings` | `groupMode` (`smart`/`everyone`/`mentions-only`), `language`, `notifications`, `autoReview[]`, `maxMessagesPerRound`, `maxTurnsPerAgentPerRound`, `maxTurnsPerReply`. |

Conversations are JSON files under `data/conversations/`; routines in `data/routines.json`; memory in `data/memory/<employee>.md`; uploads in `data/uploads/`.

## Run a second, separate office (demos, tests)

```bash
PORT=4399 COCOZIOPENBOT_TEAM=demo-team.json COCOZIOPENBOT_DATA=demo-data npm start
```

Different team file, different data folder, same install. The screenshots above were taken in one.

## Use it from your phone

```bash
HOST=0.0.0.0 COCOZIOPENBOT_TOKEN=some-long-secret npm start
```

Open `http://<your-pc-or-vps>:4310/?token=some-long-secret` on the phone once (the token is then remembered as a cookie), then "Add to Home Screen". Everything, including approvals and notifications, works there. On a VPS the server keeps running while your laptop is closed; put it behind Tailscale or a reverse proxy with HTTPS.

## Layout

```
server/            Express + SSE, orchestrator, usage + account tracking, team/provider editing API
server/providers/  claude.ts (Agent SDK), codex.ts, gemini.ts, openai.ts (+ local tools), cli.ts
client/            Vite + React UI (chat, profile panel, settings, marketplace, providers)
shared/            Types and catalogs shared by both
desktop/           Electron shell + launcher
docs/              Landing page (GitHub Pages) and screenshots
team.example.json  The starter company
```

`npm run dev` for hot reload (server :4310, client :5180). `npm test` for the unit tests.

## Contributing

Issues and PRs welcome. Good first contributions: more marketplace MCP entries, more API presets, a light theme, WhatsApp/Telegram bridges, packaged installers.

## License

MIT. Built by [Mahmoud Amr](https://github.com/Z4YT0N) at FortuneCode, with Claude.


## Telepon suara, voice note WhatsApp & tampilan HP

- **Telepon suara dari HP** (bukan lewat WhatsApp): aplikasi Expo di `mobile/` + endpoint `POST /api/voice/turn` di `server/voice.ts`. Perlu `VOICE_API_KEY` (atau `OPENAI_API_KEY`). Lihat `mobile/README.md`.
- **WhatsApp bridge** (`wa-bridge.mjs`): sekarang menerima voice note (ditranskrip) dan membalas dengan voice note; telepon WA yang masuk ditolak sopan. WhatsApp tidak mengizinkan bot mengangkat panggilan lewat scan QR. Untuk itu harus pakai WhatsApp Business Calling API (belum dibuat).
- **Tampilan responsif**: sidebar bisa disembunyikan (tombol ☰), jadi laci geser di HP. Gaya ada di `client/src/responsive.css`.
- **pm2**: `ecosystem.config.cjs` sudah ada; isi `COCOZIOPENBOT_TOKEN` / `VOICE_API_KEY`, lalu `npm run build && pm2 start ecosystem.config.cjs`. Setelah ubah env: `pm2 restart cocoziopenbot --update-env`.
