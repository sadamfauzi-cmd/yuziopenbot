# CocoziOpenBot Call (aplikasi HP)

Telepon suara ke employee CocoziOpenBot dari HP — bukan lewat WhatsApp.

## 1. Server
```
HOST=0.0.0.0
COCOZIOPENBOT_TOKEN=isi-token-panjang
VOICE_API_KEY=sk-...        # atau OPENAI_API_KEY (Whisper + TTS)
npm run build && npm start
```
Opsional: `VOICE_BASE_URL`, `STT_MODEL` (whisper-1), `STT_LANGUAGE` (id), `TTS_MODEL` (tts-1), `TTS_VOICE` (alloy).
Cek aktif: `GET /api/voice/status` -> `{"enabled":true}`.

Supaya HP bisa menjangkau server di luar rumah, pakai Tailscale atau Cloudflare Tunnel (HTTPS).

## 2. Aplikasi
```
npx create-expo-app@latest cocozi-call --template blank-typescript
cd cocozi-call
npx expo install expo-audio @react-native-async-storage/async-storage expo-status-bar
# ganti App.tsx dengan mobile/App.tsx
```
Di `app.json` tambahkan plugin mikrofon:
```
"plugins": [["expo-audio", { "microphonePermission": "Dipakai untuk menelepon employee." }]]
```
Jalankan: `npx expo start`, buka dengan Expo Go (HP & laptop satu Wi-Fi, server pakai http://IP-LAPTOP:4310).
Untuk APK/IPA sungguhan, pakai URL HTTPS (tunnel) karena http polos diblokir di build rilis.

## Jadi APK (pakai di luar rumah)
1. Salin `mobile/app.json` dan `mobile/eas.json` ke proyek Expo-mu (ganti `android.package` dengan nama unikmu).
2. `npx eas-cli login` lalu `npx eas-cli build -p android --profile preview`.
3. Unduh APK dari link hasil build, instal, isi URL server (HTTPS via Cloudflare Tunnel), token, dan ID employee.
