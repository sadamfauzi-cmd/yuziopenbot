import AsyncStorage from '@react-native-async-storage/async-storage'
import { AudioModule, RecordingPresets, createAudioPlayer, setAudioModeAsync, useAudioRecorder } from 'expo-audio'
import { StatusBar } from 'expo-status-bar'
import { useCallback, useEffect, useRef, useState } from 'react'
import { Alert, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native'

/**
 * CocoziOpenBot Call — telepon suara ke employee-mu dari HP (bukan lewat WhatsApp).
 * Alur tiap giliran: kamu bicara -> berhenti (deteksi hening) -> upload ke server ->
 * server: STT -> employee menjawab -> TTS -> diputar di HP -> otomatis dengerin lagi.
 */

type Phase = 'idle' | 'listening' | 'thinking' | 'speaking'
type Line = { who: 'you' | 'bot'; text: string }

const SPEECH_DB = -42 // di atas ini dianggap suara
const SILENCE_MS = 1300 // hening segini setelah bicara = giliran selesai
const MAX_TURN_MS = 45_000
const MIN_SPEECH_MS = 400
const IDLE_HANGUP_MS = 90_000 // tidak ada yang bicara selama ini -> tutup telepon

export default function App() {
  const [server, setServer] = useState('http://192.168.1.10:4310')
  const [token, setToken] = useState('')
  const [agent, setAgent] = useState('budi')
  const [phase, setPhase] = useState<Phase>('idle')
  const [lines, setLines] = useState<Line[]>([])
  const [error, setError] = useState('')
  const recorder = useAudioRecorder({ ...RecordingPresets.HIGH_QUALITY, isMeteringEnabled: true })
  const live = useRef(false) // true selama telepon tersambung
  const sendNow = useRef(false) // tombol "kirim sekarang"

  useEffect(() => {
    void AsyncStorage.multiGet(['server', 'token', 'agent']).then((kv) => {
      for (const [k, v] of kv) {
        if (!v) continue
        if (k === 'server') setServer(v)
        if (k === 'token') setToken(v)
        if (k === 'agent') setAgent(v)
      }
    })
  }, [])

  const base = server.trim().replace(/\/$/, '')
  const headers = useCallback((extra: Record<string, string> = {}) => ({ ...(token ? { Authorization: `Bearer ${token.trim()}` } : {}), ...extra }), [token])

  /** Rekam satu giliran bicara. Mengembalikan uri file, atau null kalau tidak ada yang bicara. */
  const listen = useCallback(async (): Promise<string | null | 'hangup'> => {
    await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true })
    await recorder.prepareToRecordAsync()
    recorder.record()
    const startedAt = Date.now()
    let speechStart = 0
    let lastVoice = 0
    sendNow.current = false
    for (;;) {
      await new Promise((r) => setTimeout(r, 120))
      if (!live.current) {
        await recorder.stop().catch(() => {})
        return 'hangup'
      }
      const now = Date.now()
      const db = recorder.getStatus().metering ?? -160
      if (db > SPEECH_DB) {
        if (!speechStart) speechStart = now
        lastVoice = now
      }
      const spoke = speechStart > 0 && lastVoice - speechStart >= MIN_SPEECH_MS
      const done = spoke && (now - lastVoice > SILENCE_MS || now - startedAt > MAX_TURN_MS || sendNow.current)
      if (done) break
      if (!speechStart && now - startedAt > IDLE_HANGUP_MS) {
        await recorder.stop().catch(() => {})
        return 'hangup'
      }
    }
    await recorder.stop()
    return recorder.uri
  }, [recorder])

  const play = useCallback(
    (url: string) =>
      new Promise<void>((resolve) => {
        const player = createAudioPlayer({ uri: `${base}${url}`, headers: headers() })
        const sub = player.addListener('playbackStatusUpdate', (s: { didJustFinish?: boolean }) => {
          if (s.didJustFinish) {
            sub.remove()
            player.remove()
            resolve()
          }
        })
        player.play()
      }),
    [base, headers],
  )

  const call = useCallback(async () => {
    setError('')
    const perm = await AudioModule.requestRecordingPermissionsAsync()
    if (!perm.granted) {
      Alert.alert('Izin mikrofon dibutuhkan', 'Aktifkan izin mikrofon untuk aplikasi ini di pengaturan HP.')
      return
    }
    await AsyncStorage.multiSet([['server', server], ['token', token], ['agent', agent]])
    live.current = true
    setLines([])
    try {
      while (live.current) {
        setPhase('listening')
        const uri = await listen()
        if (uri === 'hangup' || !uri) break
        setPhase('thinking')
        const blob = await (await fetch(uri)).blob()
        const res = await fetch(`${base}/api/voice/turn?agent=${encodeURIComponent(agent.trim())}`, {
          method: 'POST',
          headers: headers({ 'Content-Type': 'audio/m4a' }),
          body: blob,
        })
        const json = (await res.json()) as { heard?: string; reply?: string; audioUrl?: string | null; error?: string }
        if (!res.ok) throw new Error(json.error ?? `HTTP ${res.status}`)
        if (json.heard) setLines((l) => [...l, { who: 'you', text: json.heard! }])
        if (json.reply) setLines((l) => [...l, { who: 'bot', text: json.reply! }])
        if (json.audioUrl && live.current) {
          setPhase('speaking')
          await play(json.audioUrl)
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      live.current = false
      setPhase('idle')
    }
  }, [agent, base, headers, listen, play, server, token])

  const hangup = () => {
    live.current = false
  }

  const label = { idle: 'Siap', listening: 'Mendengarkan…', thinking: 'Berpikir…', speaking: 'Berbicara…' }[phase]

  return (
    <SafeAreaView style={s.root}>
      <StatusBar style="light" />
      <Text style={s.title}>CocoziOpenBot Call</Text>
      {phase === 'idle' && (
        <View style={s.form}>
          <TextInput style={s.input} value={server} onChangeText={setServer} autoCapitalize="none" placeholder="URL server, mis. http://192.168.1.10:4310" placeholderTextColor="#666" />
          <TextInput style={s.input} value={token} onChangeText={setToken} autoCapitalize="none" secureTextEntry placeholder="Access token (COCOZIOPENBOT_TOKEN)" placeholderTextColor="#666" />
          <TextInput style={s.input} value={agent} onChangeText={setAgent} autoCapitalize="none" placeholder="ID employee (mis. budi)" placeholderTextColor="#666" />
        </View>
      )}
      <ScrollView style={s.log} contentContainerStyle={{ gap: 8, padding: 12 }}>
        {lines.map((l, i) => (
          <View key={i} style={[s.bubble, l.who === 'you' ? s.you : s.bot]}>
            <Text style={s.bubbleText}>{l.text}</Text>
          </View>
        ))}
        {error ? <Text style={s.err}>{error}</Text> : null}
      </ScrollView>
      <Text style={s.status}>{label}</Text>
      <View style={s.row}>
        {phase === 'idle' ? (
          <Pressable style={[s.btn, s.green]} onPress={() => void call()}>
            <Text style={s.btnText}>Telepon</Text>
          </Pressable>
        ) : (
          <>
            {phase === 'listening' && (
              <Pressable style={[s.btn, s.gray]} onPress={() => { sendNow.current = true }}>
                <Text style={s.btnText}>Kirim</Text>
              </Pressable>
            )}
            <Pressable style={[s.btn, s.red]} onPress={hangup}>
              <Text style={s.btnText}>Tutup</Text>
            </Pressable>
          </>
        )}
      </View>
    </SafeAreaView>
  )
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0e0e10', paddingTop: 40 },
  title: { color: '#fff', fontSize: 20, fontWeight: '700', textAlign: 'center', marginBottom: 8 },
  form: { paddingHorizontal: 16, gap: 8 },
  input: { backgroundColor: '#1c1c20', color: '#fff', padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#2a2a30' },
  log: { flex: 1 },
  bubble: { maxWidth: '85%', padding: 10, borderRadius: 12 },
  you: { alignSelf: 'flex-end', backgroundColor: '#2d5bff' },
  bot: { alignSelf: 'flex-start', backgroundColor: '#25252b' },
  bubbleText: { color: '#fff', fontSize: 15 },
  err: { color: '#ff6b6b' },
  status: { color: '#aaa', textAlign: 'center', marginVertical: 8 },
  row: { flexDirection: 'row', justifyContent: 'center', gap: 16, paddingBottom: 32 },
  btn: { paddingVertical: 16, paddingHorizontal: 36, borderRadius: 40 },
  btnText: { color: '#fff', fontSize: 17, fontWeight: '700' },
  green: { backgroundColor: '#1fa855' },
  red: { backgroundColor: '#e5484d' },
  gray: { backgroundColor: '#444' },
})
