import { useState } from 'react'
import { backupUrl, restoreBackup } from '../api'

/** Export all settings to one file and restore them after an update or on a new computer. */
export function Backup() {
  const [secrets, setSecrets] = useState(true)
  const [chats, setChats] = useState(true)
  const [keepWorkspace, setKeepWorkspace] = useState(true)
  const [status, setStatus] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  return (
    <div className="card">
      <div className="row">
        <div className="row-text">
          <div className="row-title">Backup pengaturan</div>
          <div className="row-hint">
            Simpan semua pengaturan (karyawan, provider, MCP server, skill, routine) ke satu file. Setelah update program, tinggal restore, tidak perlu setting dari awal. Riwayat chat dan ingatan karyawan bisa ikut (opsional).
          </div>
        </div>
      </div>
      <div className="row">
        <div className="row-text">
          <div className="row-title">Export</div>
          <div className="row-hint">
            <label>
              <input type="checkbox" checked={secrets} onChange={(e) => setSecrets(e.target.checked)} /> Sertakan API key & rahasia MCP (file berisi kunci, jangan dibagikan)
            </label>
            <br />
            <label>
              <input type="checkbox" checked={chats} onChange={(e) => setChats(e.target.checked)} /> Sertakan riwayat chat & ingatan karyawan (file bisa besar; file lampiran tidak ikut)
            </label>
          </div>
        </div>
        <div className="row-control">
          <a className="btn btn-primary" href={backupUrl(secrets, chats)} download>
            Download backup
          </a>
        </div>
      </div>
      <div className="row">
        <div className="row-text">
          <div className="row-title">Restore</div>
          <div className="row-hint">
            <label>
              <input type="checkbox" checked={keepWorkspace} onChange={(e) => setKeepWorkspace(e.target.checked)} /> Pakai folder workspace komputer ini (disarankan kalau pindah komputer)
            </label>
            <br />
            Ini menggantikan pengaturan yang sekarang, dan riwayat chat juga kalau ada di file backup. Key yang kosong di file backup tidak menghapus key yang sudah ada.
          </div>
          {status && <div className="row-hint">{status}</div>}
          {error && <div className="row-hint" style={{ color: 'var(--danger)' }}>{error}</div>}
        </div>
        <div className="row-control">
          <label className="btn">
            Pilih file backup…
            <input
              type="file"
              accept="application/json,.json"
              hidden
              onChange={async (e) => {
                const f = e.target.files?.[0]
                e.target.value = ''
                if (!f) return
                setStatus(null)
                setError(null)
                if (!window.confirm('Ganti semua pengaturan sekarang dengan isi file backup ini?')) return
                try {
                  const r = await restoreBackup(JSON.parse(await f.text()), keepWorkspace)
                  setStatus(`Berhasil: ${r.employees} karyawan dan ${r.routines} routine dipulihkan${r.chats > 0 ? `, ${r.chats} percakapan` : ''}.`)
                } catch (err) {
                  setError(err instanceof Error ? err.message : String(err))
                }
              }}
            />
          </label>
        </div>
      </div>
    </div>
  )
}
