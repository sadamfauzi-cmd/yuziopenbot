// Konfigurasi pm2 buat CocoziOpenBot + wa-bridge, jalan sebagai satu proses di background.
//
// Pakai (setelah `npm install` && `npm run build`):
//   npm install -g pm2
//   pm2 start ecosystem.config.cjs
//   pm2 save
//   pm2 startup          <-- ikuti instruksi yang muncul (lihat penjelasan di chat)
//
// Ganti angka/isi di "env" di bawah sesuai kebutuhanmu (mis. PORT lain, HOST=0.0.0.0
// buat akses dari HP + COCOZIOPENBOT_TOKEN, MANAGER_AGENT_ID employee lain, dst).
// Setelah edit file ini, jalankan `pm2 restart cocoziopenbot` biar env baru kepakai.
module.exports = {
  apps: [
    {
      name: 'cocoziopenbot',
      script: 'dist/server/index.js',
      cwd: __dirname,
      env: {
        NODE_ENV: 'production',
        PORT: '4310',
        HOST: '127.0.0.1',
        // Wajib kalau diakses lewat tunnel (Cloudflare) / HP: isi token panjang acak (min 32 karakter).
        // COCOZIOPENBOT_TOKEN: 'isi-token-acak-panjang',
        // Telepon suara dari HP + voice note WhatsApp (Whisper STT + TTS, API OpenAI-compatible):
        // VOICE_API_KEY: 'sk-...',
        WA_BRIDGE_ENABLED: '1',
        MANAGER_AGENT_ID: 'MNG-01', // id tetap milik manager (tidak ikut berubah kalau nama manager diganti)
        // WA_ALLOWED_NUMBERS: '6281234567890,6289876543210',
      },
      autorestart: true, // restart otomatis kalau proses crash
      max_restarts: 20,
      restart_delay: 3000,
      watch: false, // jangan restart tiap ada perubahan file di production
      out_file: './logs/cocoziopenbot-out.log',
      error_file: './logs/cocoziopenbot-error.log',
      time: true,
    },
  ],
}
