import { useI18n } from './i18n'
import { useEffect, useMemo, useReducer, useRef, useState } from 'react'
import type { Conversation, ServerEvent } from '../../shared/types'
import { clearConversation, deleteConversation, duplicateAgent, exportUrl, fetchState, logoUrl, sendMessageFull, stopRound, updateAgent, updateConversation } from './api'
import { ChatView } from './components/ChatView'
import { Composer, type ReplyTarget } from './components/Composer'
import { Menu, type MenuItem } from './components/Menu'
import { NewChat } from './components/NewChat'
import { Profile } from './components/Profile'
import { Search } from './components/Search'
import { Settings, type SettingsSection } from './components/Settings'
import { Sidebar } from './components/Sidebar'
import { conversationAvatars, personFor } from './people'
import { initialState, reducer } from './state'
import { markRead, markUnread } from './unread'
import { AvatarActivity, AvatarFollow } from './components/Avatar'
import { Dashboard } from './components/Dashboard'

const MOBILE_Q = '(max-width: 820px)'
const NAV_KEY = 'cocozi.nav'

interface MenuState {
  x: number
  y: number
  conversationId: string
}

export function App() {
  const [state, dispatch] = useReducer(reducer, initialState)
  const { t, lang } = useI18n()
  useEffect(() => {
    document.documentElement.lang = lang
  }, [lang])
  const [activeId, setActiveId] = useState('group')
  /** The app opens on the dashboard; picking any chat switches to the chat view. */
  const [view, setView] = useState<'dashboard' | 'chat'>('dashboard')
  const openChat = (id: string) => {
    setActiveId(id)
    setView('chat')
    if (window.matchMedia(MOBILE_Q).matches) setNavOpen(false)
  }
  // Sidebar: pinned open/closed on desktop (remembered), slide-over drawer on phones.
  const [mobile, setMobile] = useState(() => window.matchMedia(MOBILE_Q).matches)
  const [navOpen, setNavOpen] = useState(() => {
    if (window.matchMedia(MOBILE_Q).matches) return false
    try {
      return localStorage.getItem(NAV_KEY) !== '0'
    } catch {
      return true
    }
  })
  useEffect(() => {
    const mq = window.matchMedia(MOBILE_Q)
    const onChange = () => {
      setMobile(mq.matches)
      if (mq.matches) setNavOpen(false)
    }
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [])
  const toggleNav = () =>
    setNavOpen((v) => {
      if (!mobile) {
        try {
          localStorage.setItem(NAV_KEY, v ? '0' : '1')
        } catch {
          // storage unavailable: just don't remember
        }
      }
      return !v
    })
  const closeNavIfMobile = () => {
    if (mobile) setNavOpen(false)
  }
  const [error, setError] = useState<string | null>(null)
  const [settings, setSettings] = useState<SettingsSection | null>(null)
  /** undefined = closed, null = new employee, string = editing that employee */
  const [profile, setProfile] = useState<string | null | undefined>(undefined)
  const [menu, setMenu] = useState<MenuState | null>(null)
  /** undefined = closed, null = new chat, Conversation = editing */
  const [chatEditor, setChatEditor] = useState<Conversation | null | undefined>(undefined)
  const [search, setSearch] = useState(false)
  const [replyTo, setReplyTo] = useState<ReplyTarget | null>(null)
  const [jumpTo, setJumpTo] = useState<string | null>(null)
  const [readTick, setReadTick] = useState(0)
  const latest = useRef({ activeId, state, view })
  latest.current = { activeId, state, view }

  // Browser tab title + favicon follow the custom app name / logo set in Settings → General → Branding.
  useEffect(() => {
    const appName = state.team?.settings.appName?.trim() || 'Yuzi Distributor - System Employee'
    document.title = appName
    const logo = logoUrl(state.team?.settings.logoVersion)
    if (logo) {
      let link = document.querySelector<HTMLLinkElement>('link[rel="icon"]')
      if (!link) {
        link = document.createElement('link')
        link.rel = 'icon'
        document.head.appendChild(link)
      }
      link.href = logo
    }
  }, [state.team?.settings.appName, state.team?.settings.logoVersion])

  useEffect(() => {
    let alive = true
    const load = () =>
      fetchState()
        .then((s) => {
          if (alive) dispatch({ type: 'state', state: s })
        })
        .catch((err: unknown) => setError(err instanceof Error ? err.message : String(err)))
    void load()
    const es = new EventSource('/api/events')
    es.onopen = () => {
      dispatch({ type: 'connected', connected: true })
      // Anything that happened while we were disconnected is on the server; resync.
      void load()
    }
    es.onerror = () => dispatch({ type: 'connected', connected: false })
    es.onmessage = (e) => {
      try {
        const event = JSON.parse(e.data) as ServerEvent
        dispatch({ type: 'event', event })
        maybeNotify(event)
      } catch {
        // ignore malformed frames
      }
    }
    return () => {
      alive = false
      es.close()
    }
  }, [])

  const maybeNotify = (event: ServerEvent) => {
    const { state: s, activeId: current, view: shown } = latest.current
    if (!s.team?.settings.notifications || typeof Notification === 'undefined') return
    let title = ''
    let body = ''
    let conversationId = ''
    if (event.type === 'message:done' && event.message.authorId !== 'user' && event.message.status === 'done') {
      const away = document.hidden || !document.hasFocus() || shown === 'dashboard' || event.message.conversationId !== current
      if (!away) return
      title = s.team ? personFor(s.team, event.message.authorId).label : 'Reply'
      body = event.message.text.slice(0, 160)
      conversationId = event.message.conversationId
    } else if (event.type === 'approval:request') {
      title = `${s.team ? personFor(s.team, event.request.agentId).name : 'An employee'} needs your approval`
      body = `${event.request.tool}: ${event.request.summary}`.slice(0, 160)
      conversationId = event.request.conversationId
    } else return
    const show = () => {
      const n = new Notification(title, { body, silent: true })
      n.onclick = () => {
        window.focus()
        openChat(conversationId)
      }
    }
    if (Notification.permission === 'granted') show()
    else if (Notification.permission === 'default') void Notification.requestPermission().then((p) => p === 'granted' && show())
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setSearch((v) => !v)
        return
      }
      if (e.key !== 'Escape') return
      if (menu) setMenu(null)
      else if (search) setSearch(false)
      else if (chatEditor !== undefined) setChatEditor(undefined)
      else if (settings) setSettings(null)
      else if (profile !== undefined) setProfile(undefined)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [menu, search, chatEditor, settings, profile])

  const conversation = state.conversations.find((c) => c.id === activeId) ?? state.conversations.find((c) => c.id === 'group') ?? state.conversations[0]

  // Reading a conversation marks it read (also as new replies arrive while it is open).
  const lastAt = conversation?.messages[conversation.messages.length - 1]?.createdAt ?? 0
  useEffect(() => {
    if (!conversation || view !== 'chat') return
    markRead(conversation.id)
    setReadTick((t) => t + 1)
  }, [conversation?.id, lastAt, view])

  // Everyone who is typing anywhere: their faces switch to the "thinking" expression.
  const working = useMemo(() => {
    const all = new Set<string>()
    for (const ids of state.typing.values()) for (const id of ids) all.add(id)
    return all
  }, [state.typing])

  // Only the bots of the selected chat follow the cursor; everyone else roams freely.
  const followKey = conversation && view === 'chat' ? conversationAvatars(conversation).join('|') : ''
  const followers = useMemo(() => new Set(followKey ? followKey.split('|') : []), [followKey])

  useEffect(() => setReplyTo(null), [activeId])

  if (!state.team || !conversation) {
    return (
      <div className="boot">
        {error ? <p className="boot-error">Could not reach the CocoziOpenBot server: {error}</p> : <p>{t('Opening the office…')}</p>}
      </div>
    )
  }

  const team = state.team
  const busy = state.busy.has(conversation.id)
  const fail = (err: unknown) => setError(err instanceof Error ? err.message : String(err))

  const menuItems = (conversationId: string): MenuItem[] => {
    const c = state.conversations.find((x) => x.id === conversationId)
    if (!c) return []
    const agentId = c.kind === 'dm' ? c.memberIds.find((id) => id !== 'user') : undefined
    const agent = agentId ? team.agents.find((a) => a.id === agentId) : undefined
    const items: MenuItem[] = []
    items.push({ label: c.pinned ? 'Unpin' : 'Pin', onClick: () => void updateConversation(c.id, { pinned: !c.pinned }).catch(fail) })
    items.push({
      label: 'Mark as unread',
      onClick: () => {
        markUnread(c.id)
        if (latest.current.activeId === c.id) setActiveId('group')
        setReadTick((t) => t + 1)
      },
    })
    if (c.id !== 'group') items.push({ label: c.hidden ? 'Unhide' : 'Hide from sidebar', onClick: () => void updateConversation(c.id, { hidden: !c.hidden }).catch(fail) })
    if (c.kind === 'group') items.push({ label: c.id === 'group' ? 'Rename' : 'Edit chat', onClick: () => setChatEditor(c) })
    if (agent) {
      items.push({ label: 'Edit profile', divider: true, onClick: () => setProfile(agent.id) })
      items.push({ label: agent.muted ? 'Unmute in groups' : 'Mute in groups', onClick: () => void updateAgent(agent.id, { muted: !agent.muted }).catch(fail) })
      items.push({ label: 'Duplicate employee', onClick: () => void duplicateAgent(agent.id).then(({ agent: copy }) => setProfile(copy.id)).catch(fail) })
    }
    items.push({ label: 'Export as Markdown', divider: true, onClick: () => window.open(exportUrl(c.id), '_blank') })
    items.push({ label: 'Clear conversation', onClick: () => void clearConversation(c.id).catch(fail) })
    if (c.kind === 'group' && c.id !== 'group') {
      items.push({
        label: 'Delete chat',
        danger: true,
        divider: true,
        onClick: () => {
          void deleteConversation(c.id)
            .then(() => {
              if (latest.current.activeId === c.id) setActiveId('group')
            })
            .catch(fail)
        },
      })
    }
    if (agent) items.push({ label: 'Delete employee', danger: true, divider: true, onClick: () => setProfile(agent.id) })
    return items
  }

  return (
    <AvatarActivity.Provider value={working}>
    <AvatarFollow.Provider value={followers}>
    <div className={`app${navOpen ? '' : ' nav-collapsed'}${mobile ? ' is-mobile' : ''}`}>
      <Sidebar
        team={team}
        conversations={state.conversations}
        activeId={conversation.id}
        busy={state.busy}
        approvals={state.approvals}
        readTick={readTick}
        view={view}
        onSelect={openChat}
        onDashboard={() => {
          setView('dashboard')
          closeNavIfMobile()
        }}
        onMenu={(id, x, y) => setMenu({ conversationId: id, x, y })}
        onSettings={() => setSettings('general')}
        onNewChat={() => setChatEditor(null)}
        onSearch={() => setSearch(true)}
        onClose={toggleNav}
      />
      {mobile && navOpen && <div className="nav-backdrop" onClick={toggleNav} aria-hidden="true" />}
      <main className="main">
        {view === 'dashboard' ? (
          <Dashboard
            team={team}
            conversations={state.conversations}
            working={working}
            usage={state.usage}
            account={state.account}
            routines={state.routines}
            approvals={state.approvals}
            onToggleNav={toggleNav}
            navOpen={navOpen}
            onOpenChat={openChat}
            onNewChat={() => setChatEditor(null)}
            onSettings={setSettings}
            onOpenMember={(agentId) => {
              const dm = state.conversations.find((c) => c.kind === 'dm' && c.memberIds.includes(agentId))
              if (dm) openChat(dm.id)
              else setProfile(agentId)
            }}
          />
        ) : (
          <>
        <ChatView
          team={team}
          conversation={conversation}
          typing={state.typing.get(conversation.id) ?? new Set()}
          usage={state.usage}
          approvals={state.approvals}
          jumpTo={jumpTo}
          onEditAgent={(id) => setProfile(id)}
          onReply={setReplyTo}
          profileOpen={profile !== undefined}
          onToggleNav={toggleNav}
          navOpen={navOpen}
        />
        <Composer
          team={team}
          conversation={conversation}
          busy={busy}
          replyTo={replyTo}
          onClearReply={() => setReplyTo(null)}
          onSend={async (body) => {
            await sendMessageFull(conversation.id, body)
          }}
          onStop={() => void stopRound(conversation.id)}
        />
          </>
        )}
        {!state.connected && <div className="offline">{t('Reconnecting to the office…')}</div>}
        {error && (
          <div className="toast" role="alert">
            <span>{error}</span>
            <button type="button" onClick={() => setError(null)} aria-label="Dismiss">
              ×
            </button>
          </div>
        )}
      </main>
      {profile !== undefined && (
        <Profile
          team={team}
          agentId={profile}
          usage={profile ? state.usage.byAgent[profile] : undefined}
          onClose={() => setProfile(undefined)}
          onSaved={(id) => {
            setProfile(id)
            if (profile === null) openChat(`dm-${id}`)
          }}
        />
      )}
      {settings && (
        <Settings
          team={team}
          routines={state.routines}
          conversations={state.conversations}
          usage={state.usage}
          account={state.account}
          section={settings}
          onSection={setSettings}
          onClose={() => setSettings(null)}
          onEditAgent={(id) => {
            setSettings(null)
            setProfile(id)
          }}
        />
      )}
      {chatEditor !== undefined && (
        <NewChat
          team={team}
          {...(chatEditor ? { conversation: chatEditor } : {})}
          onDone={(id) => {
            setChatEditor(undefined)
            if (id) openChat(id)
          }}
        />
      )}
      {search && (
        <Search
          team={team}
          conversations={state.conversations}
          onClose={() => setSearch(false)}
          onPick={(conversationId, messageId) => {
            setSearch(false)
            openChat(conversationId)
            setJumpTo(messageId ? `${messageId}` : null)
            if (messageId) setTimeout(() => setJumpTo(messageId), 50)
          }}
        />
      )}
      {menu && <Menu x={menu.x} y={menu.y} items={menuItems(menu.conversationId)} onClose={() => setMenu(null)} />}
    </div>
    </AvatarFollow.Provider>
    </AvatarActivity.Provider>
  )
}
