#!/usr/bin/env node
/**
 * wa-bridge.mjs — jembatan antara WhatsApp pribadimu (login via QR, seperti WhatsApp Web)
 * dan satu employee CocoziOpenBot (biasanya si manager).
 *
 * Alurnya:
 *   1. Kamu kirim WA ke nomor yang di-link (nomormu sendiri atau nomor cadangan).
 *   2. Bridge ini meneruskan isi pesan itu sebagai chat baru ke DM manager di CocoziOpenBot.
 *   3. Manager (dan tim yang dia panggil) memproses seperti biasa di CocoziOpenBot.
 *   4. Begitu manager selesai membalas, bridge ini mengirim balasannya balik ke WhatsApp
 *      yang sama.
 *
 * DUA CARA JALANIN INI:
 *
 *   A) Otomatis bareng server CocoziOpenBot (disarankan — cuma 1 proses yang perlu tetap hidup):
 *      Set WA_BRIDGE_ENABLED=1 sebelum `npm start` / `npm run dev` / `npm run desktop`.
 *      Server akan import file ini dan panggil startWaBridge() sendiri setelah dia listen,
 *      pakai URL & token dirinya sendiri secara otomatis. QR muncul di terminal/log server
 *      yang sama (di desktop app, cek jendela "Logs"/console kalau ada, atau jalankan
 *      `npm start` dulu dari terminal biasa sekali saja buat scan awal).
 *
 *   B) Berdiri sendiri, proses terpisah (kalau mau bridge-nya independen dari server):
 *        npm install whatsapp-web.js qrcode-terminal   (sudah ada di package.json ini)
 *        node wa-bridge.mjs
 *      Lalu scan QR yang muncul di terminal pakai WhatsApp di HP:
 *      WhatsApp → Pengaturan → Perangkat Tertaut → Tautkan Perangkat.
 *      Terminal ini harus tetap terbuka selama bridge mau aktif menerima/membalas pesan.
 *
 * Sesi WhatsApp tersimpan di folder .wa-session/, jadi tidak perlu scan ulang tiap start
 * (kecuali logout dari HP / folder dihapus / lama tidak dipakai).
 *
 * whatsapp-web.js & qrcode-terminal ada di "optionalDependencies" package.json, bukan
 * "dependencies" biasa — supaya kalau download Chromium bawaan puppeteer gagal (jaringan
 * kantor/firewall yang blokir storage.googleapis.com), `npm install` PROJECT INI TETAP
 * SUKSES (server, client, dsb tetap kepasang), cuma fitur WhatsApp bridge yang nonaktif
 * sampai kamu benerin jaringannya lalu `npm install whatsapp-web.js qrcode-terminal` ulang.
 * Kalau memang tidak mau download Chromium sama sekali, set env var
 * PUPPETEER_EXECUTABLE_PATH ke lokasi Chrome yang sudah ada di komputermu sebelum install.
 *
 * Konfigurasi via environment variable (opsional, ada default di bawah):
 *   COCOZIOPENBOT_URL      contoh: http://127.0.0.1:4310 (default). Saat dipanggil otomatis
 *                         dari server (cara A), ini diisi otomatis sesuai PORT/HOST server,
 *                         jadi biasanya tidak perlu diset manual.
 *   COCOZIOPENBOT_TOKEN    isi hanya kalau server CocoziOpenBot dijalankan dengan
 *                         COCOZIOPENBOT_TOKEN=... (server-side auth token). Saat cara A,
 *                         otomatis dipakaikan token yang sama dengan server.
 *   MANAGER_AGENT_ID     id employee tujuan di team.json, contoh: "MNG-01" (id tetap milik manager).
 *                         (Lihat field "id" di team.json / team.example.json.)
 *   WA_ALLOWED_NUMBERS   opsional, whitelist nomor (format 62xxxxxxxxxx, tanpa "+"),
 *                         pisahkan koma. Kosongkan untuk terima dari siapa saja yang
 *                         chat ke nomor yang ditautkan.
 *
 *   WA_NUMBER_NAMES      opsional, nama tiap nomor supaya manager tahu SIAPA yang chat (bukan
 *                         selalu dianggap pemilik/bos). Format: nomor=Nama, pisahkan koma.
 *                         Contoh: WA_NUMBER_NAMES='6281234567890=Budi,6289876543210=Sari'
 *                         Tanpa ini, dipakai nama tampilan WhatsApp si pengirim.
 *   (WA_NOTIFY_WINDOW_MIN sudah TIDAK dipakai lagi: tidak ada batas waktu. Setiap balasan membawa
 *    penanda chat WA asalnya, jadi selalu sampai ke WA yang benar kapan pun selesainya.)
 *
 *   WA_FORWARD_REPORTS   default 0. Manager otomatis merangkum hasil karyawan lalu membalas ke WA.
 *                         Set 1 kalau laporan mentah tiap karyawan juga mau ikut dikirim ke WA.
 *   WA_SSE_IDLE_SEC      default 45: kalau koneksi event ke server diam selama ini (server ping tiap
 *                         15 dtk), anggap putus lalu sambung ulang otomatis.
 *
 *   FITUR SUARA (voice note + penanganan telepon masuk):
 *   WhatsApp TIDAK menyediakan cara resmi bagi bot (akun yang ditautkan via QR) untuk
 *   mengangkat / melakukan panggilan suara. Jadi yang dibuat: kamu kirim VOICE NOTE ->
 *   ditranskrip -> manager menjawab -> balasannya dibacakan balik sebagai voice note.
 *   Telepon yang masuk ke nomor bot otomatis ditolak sopan + diarahkan ke voice note.
 *   Perlu API key untuk STT (suara->teks) dan TTS (teks->suara), format OpenAI-compatible:
 *   WA_VOICE_API_KEY     API key (default: OPENAI_API_KEY). Tanpa ini, voice note dibalas
 *                         "belum dikonfigurasi" dan fitur teks tetap jalan normal.
 *   WA_VOICE_BASE_URL    default https://api.openai.com/v1
 *   WA_STT_MODEL         default whisper-1
 *   WA_STT_LANGUAGE      default id (kode bahasa ISO-639-1; kosongkan utk auto-detect)
 *   WA_TTS_MODEL         default tts-1
 *   WA_TTS_VOICE         default alloy
 *   WA_VOICE_REPLY       voice (default: balas voice note saja) | both (voice + teks) | text
 *   WA_REJECT_CALLS      default 1: telepon masuk ditolak + dibalas pesan. Set 0 utk biarkan.
 *
 *   WA_BRIDGE_ENABLED    dipakai oleh server/index.ts: set "1" biar bridge ini otomatis
 *                         start bareng server. Tidak dipakai saat dijalankan manual (cara B).
 */

import pkg from 'whatsapp-web.js'
const { Client, LocalAuth, MessageMedia } = pkg
import qrcode from 'qrcode-terminal'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { existsSync, readFileSync, rmSync, unlinkSync, writeFileSync } from 'node:fs'
import { execSync } from 'node:child_process'

let started = false
/** Samakan format nomor: hanya angka, dan 08xx diubah jadi 628xx. Jadi "+62 812-3456", "0812..." dan "62812..." dianggap sama. */
function normNumber(raw) {
  const d = String(raw ?? '').replace(/\D/g, '')
  return d.startsWith('0') ? `62${d.slice(1)}` : d
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
/** Batasi waktu tunggu sebuah promise (Puppeteer kadang menggantung tanpa error). */
function withTimeout(promise, ms, label = 'operasi') {
  let t
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, rej) => {
      t = setTimeout(() => rej(new Error(`${label} timeout ${Math.round(ms / 1000)}s`)), ms)
    }),
  ]).finally(() => clearTimeout(t))
}
/** QR login WhatsApp sebagai teks polos, supaya bisa dibaca lewat `cat` tanpa awalan log pm2. */
const QR_FILE = path.resolve(process.cwd(), 'wa-qr.txt')
/** Status bridge yang bertahan walau restart: antrean kirim, id yang sudah terkirim, id pesan masuk yang sudah diteruskan. */
const STATE_FILE = path.resolve(process.cwd(), '.wa-bridge-state.json')
const SESSION_DIR = path.resolve(process.cwd(), '.wa-session')

/**
 * Menyalakan bridge. Aman dipanggil sekali dari server (cara A) atau otomatis di
 * bawah file ini kalau dijalankan langsung lewat `node wa-bridge.mjs` (cara B).
 * @param {{ baseUrl?: string, token?: string, agentId?: string, allowedNumbers?: string[] }} opts
 */
export async function startWaBridge(opts = {}) {
  if (started) {
    console.log('[wa-bridge] sudah jalan, skip start kedua.')
    return
  }
  started = true

  const BASE = (opts.baseUrl ?? process.env.COCOZIOPENBOT_URL ?? 'http://127.0.0.1:4310').replace(/\/$/, '')
  const TOKEN = opts.token ?? process.env.COCOZIOPENBOT_TOKEN ?? ''
  const AGENT_ID = opts.agentId ?? process.env.MANAGER_AGENT_ID ?? 'MNG-01'
  const CONVERSATION_ID = `dm-${AGENT_ID}`
  const ALLOWED =
    opts.allowedNumbers ??
    (process.env.WA_ALLOWED_NUMBERS ?? '')
      .split(',')
      .map((s) => normNumber(s))
      .filter(Boolean)

  // nomor -> nama, supaya dua nomor (atau lebih) yang boleh chat ke bot dikenali sebagai orang berbeda.
  const NAMES = new Map(
    (opts.numberNames ? Object.entries(opts.numberNames).map(([k, v]) => `${k}=${v}`) : (process.env.WA_NUMBER_NAMES ?? '').split(','))
      .map((pair) => {
        const m = String(pair).match(/^\s*([^=:]+?)\s*[=:]\s*(.+?)\s*$/)
        return m ? [normNumber(m[1]), m[2]] : null
      })
      .filter(Boolean),
  )
  const SSE_IDLE_MS = Number(process.env.WA_SSE_IDLE_SEC ?? 45) * 1000

  function headers(extra = {}) {
    return {
      'Content-Type': 'application/json',
      ...(TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {}),
      ...extra,
    }
  }

  // Jangan sampai error Puppeteer yang tak tertangkap mematikan seluruh server (bridge jalan satu proses dgn server).
  process.on('unhandledRejection', (reason) => {
    console.error('[wa-bridge] unhandledRejection (diabaikan, proses tetap jalan):', reason instanceof Error ? reason.message : reason)
  })

  // ---- Suara: STT (voice note -> teks) & TTS (teks -> voice note) ----
  const VOICE_KEY = process.env.WA_VOICE_API_KEY ?? process.env.OPENAI_API_KEY ?? ''
  const VOICE_BASE = (process.env.WA_VOICE_BASE_URL ?? 'https://api.openai.com/v1').replace(/\/$/, '')
  const STT_MODEL = process.env.WA_STT_MODEL ?? 'whisper-1'
  const STT_LANG = process.env.WA_STT_LANGUAGE ?? 'id'
  const TTS_MODEL = process.env.WA_TTS_MODEL ?? 'tts-1'
  const TTS_VOICE = process.env.WA_TTS_VOICE ?? 'alloy'
  const VOICE_REPLY = (process.env.WA_VOICE_REPLY ?? 'voice').toLowerCase()
  const REJECT_CALLS = (process.env.WA_REJECT_CALLS ?? '1') !== '0'
  const MAX_TTS_CHARS = 1500

  async function transcribe(base64, mimetype) {
    const buf = Buffer.from(base64, 'base64')
    const clean = (mimetype || 'audio/ogg').split(';')[0]
    const ext = clean.includes('mpeg') ? 'mp3' : clean.includes('mp4') ? 'm4a' : clean.includes('wav') ? 'wav' : 'ogg'
    const form = new FormData()
    form.append('file', new Blob([buf], { type: clean }), `voice.${ext}`)
    form.append('model', STT_MODEL)
    if (STT_LANG) form.append('language', STT_LANG)
    const res = await fetch(`${VOICE_BASE}/audio/transcriptions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${VOICE_KEY}` },
      body: form,
      signal: AbortSignal.timeout(60_000),
    })
    if (!res.ok) throw new Error(`STT ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`)
    const json = await res.json()
    return String(json.text ?? '').trim()
  }

  // Bersihkan markdown supaya enak dibacakan, bukan dibaca "bintang bintang".
  function toSpeakable(text) {
    return text
      .replace(/```[\s\S]*?```/g, ' (ada kode, lihat di chat) ')
      .replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1')
      .replace(/[*_`#>~|]/g, '')
      .replace(/^\s*[-•]\s+/gm, '')
      .replace(/\s+/g, ' ')
      .trim()
  }

  async function synthesize(text) {
    const res = await fetch(`${VOICE_BASE}/audio/speech`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${VOICE_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: TTS_MODEL, voice: TTS_VOICE, input: text, response_format: 'opus' }),
      signal: AbortSignal.timeout(60_000),
    })
    if (!res.ok) throw new Error(`TTS ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`)
    return Buffer.from(await res.arrayBuffer()).toString('base64')
  }

  // ---- Status yang bertahan antar-restart ----
  // outbox   : balasan yang BELUM terkirim ke WA (dicoba terus sampai berhasil, tidak ada batas waktu).
  // delivered: id pesan manager yang sudah terkirim (cegah dobel kirim saat SSE nyambung ulang).
  // inbound  : id pesan WA masuk yang sudah diteruskan (cegah dobel saat WA mengirim ulang event).
  // since    : batas bawah catch-up (balasan lama sebelum ini tidak dikirim ulang).
  let saved = {}
  try {
    saved = JSON.parse(readFileSync(STATE_FILE, 'utf8'))
  } catch {
    // belum ada / rusak: mulai baru
  }
  const outbox = Array.isArray(saved.outbox) ? saved.outbox : []
  const delivered = new Set(Array.isArray(saved.delivered) ? saved.delivered : [])
  const inbound = new Set(Array.isArray(saved.inbound) ? saved.inbound : [])
  let since = Number(saved.since) || Date.now()
  function saveState() {
    try {
      writeFileSync(STATE_FILE, JSON.stringify({ since, delivered: [...delivered].slice(-400), inbound: [...inbound].slice(-400), outbox }))
    } catch {
      // folder tidak bisa ditulis: tetap jalan, hanya tidak tahan restart
    }
  }

  saveState() // catat batas catch-up sejak start pertama

  // Nama pemilik & karyawan dari server, buat label dan catatan identitas pengirim.
  let teamInfo = { owner: '', agents: new Map(), at: 0 }
  async function loadTeamInfo() {
    if (Date.now() - teamInfo.at < 60_000) return teamInfo
    try {
      const res = await fetch(`${BASE}/api/state`, { headers: headers(), signal: AbortSignal.timeout(15_000) })
      if (res.ok) {
        const st = await res.json()
        teamInfo = {
          owner: String(st?.team?.owner?.name ?? ''),
          agents: new Map((st?.team?.agents ?? []).map((a) => [a.id, a.name])),
          at: Date.now(),
        }
      }
    } catch {
      // pakai info lama / kosong
    }
    return teamInfo
  }

  // ---- Pesan masuk dari WA -> CocoziOpenBot ----
  /** Teruskan ke manager. Membawa `via` supaya SEMUA balasan turunannya tahu harus kembali ke chat WA ini. */
  async function forwardToCocoziOpenBot(fromLabel, text, chatId, viaVoice = false, number = '') {
    const info = await loadTeamInfo()
    const ownerFirst = info.owner.split(/\s+/)[0]?.toLowerCase() ?? ''
    const isOwner = ownerFirst && fromLabel.toLowerCase().includes(ownerFirst)
    const who = number && number !== fromLabel ? `${fromLabel} (${number})` : fromLabel
    // Manager selalu diberi tahu bahwa DM ini "dengan bos". Kalau yang chat orang lain, tegaskan.
    const identity = !isOwner
      ? `\n(Pengirim pesan ini adalah ${fromLabel}${info.owner ? `, BUKAN ${info.owner}` : ''}. Sapa dan balas ke ${fromLabel} dengan namanya, jangan panggil dia ${info.owner || 'bos'}.)`
      : ''
    const payload = JSON.stringify({
      text: viaVoice
        ? `[WhatsApp VOICE NOTE dari ${who}, hasil transkrip]: ${text}${identity}\n(Balasanmu akan DIBACAKAN sebagai voice note: jawab singkat, natural, bahasa lisan, tanpa markdown/tabel/kode.)`
        : `[WhatsApp dari ${who}]: ${text}${identity}`,
      via: { channel: 'wa', chatId, ...(viaVoice ? { voice: true } : {}) },
    })
    // Server sedang restart / sibuk? Coba lagi beberapa kali, jangan buang pesannya.
    for (let attempt = 1; attempt <= 8; attempt++) {
      try {
        const res = await fetch(`${BASE}/api/conversations/${CONVERSATION_ID}/messages`, {
          method: 'POST',
          headers: headers(),
          body: payload,
          signal: AbortSignal.timeout(20_000),
        })
        if (res.ok) return true
        const body = await res.text().catch(() => '')
        console.error(`[wa-bridge] server menolak pesan (percobaan ${attempt}): ${res.status} ${body.slice(0, 200)}`)
        if (res.status >= 400 && res.status < 500 && res.status !== 408 && res.status !== 429) break // salah permintaan: percuma diulang
      } catch (err) {
        console.error(`[wa-bridge] tidak bisa menghubungi CocoziOpenBot (percobaan ${attempt}):`, err.message)
      }
      await sleep(Math.min(30_000, 2000 * attempt))
    }
    enqueueReply(`err-${Date.now()}`, chatId, 'Maaf, pesanmu belum bisa diproses karena server sedang bermasalah. Coba kirim lagi sebentar lagi ya.', false, Date.now())
    return false
  }

  // ---- Balasan CocoziOpenBot -> WA (antrean tahan banting) ----
  let wa = null
  let waReady = false

  async function sendReply(job) {
    let sentVoice = false
    if (job.voice && VOICE_REPLY !== 'text' && VOICE_KEY) {
      const speak = toSpeakable(job.text)
      if (speak && speak.length <= MAX_TTS_CHARS) {
        try {
          const audio = await synthesize(speak)
          await withTimeout(wa.sendMessage(job.chatId, new MessageMedia('audio/ogg; codecs=opus', audio, 'balasan.ogg'), { sendAudioAsVoice: true }), 90_000, 'kirim voice')
          sentVoice = true
        } catch (err) {
          console.error('[wa-bridge] voice note gagal, kirim teks saja:', err.message)
        }
      }
    }
    if (!sentVoice || VOICE_REPLY === 'both') await withTimeout(wa.sendMessage(job.chatId, job.text), 90_000, 'kirim teks')
    console.log(`[wa-bridge] balasan terkirim ke ${job.chatId}${sentVoice ? ' (voice note)' : ''}`)
  }

  let pumping = false
  let sendFailStreak = 0
  async function pump() {
    if (pumping) return
    pumping = true
    try {
      while (outbox.length > 0 && waReady) {
        const job = outbox[0]
        try {
          await sendReply(job)
          outbox.shift()
          delivered.add(job.key)
          since = Math.max(since, (job.at ?? Date.now()) - 10 * 60_000)
          sendFailStreak = 0
          saveState()
        } catch (err) {
          job.tries = (job.tries ?? 0) + 1
          sendFailStreak++
          console.error(`[wa-bridge] gagal kirim ke ${job.chatId} (percobaan ${job.tries}):`, err.message)
          if (job.tries >= 40) {
            // Hampir pasti masalah di chat itu sendiri (nomor tidak valid, dll): lepas supaya antrean lain jalan.
            console.error('[wa-bridge] menyerah untuk balasan ini setelah 40 percobaan.')
            outbox.shift()
            delivered.add(job.key)
          }
          saveState()
          if (sendFailStreak >= 6) {
            sendFailStreak = 0
            void restartClient('pengiriman gagal berturut-turut')
          }
          await sleep(Math.min(30_000, 2000 * job.tries))
        }
      }
    } finally {
      pumping = false
    }
  }

  function enqueueReply(key, chatId, text, voice, at) {
    if (delivered.has(key) || outbox.some((o) => o.key === key)) return
    outbox.push({ key, chatId, text, voice: Boolean(voice), at: at ?? Date.now(), tries: 0 })
    saveState()
    void pump()
  }

  /** Satu pesan dari server. Hanya yang membawa penanda WA (`via`) yang dikirim — chat dari web tidak bocor ke WA. */
  async function handleServerMessage(m) {
    if (!m || m.conversationId !== CONVERSATION_ID || !m.text?.trim()) return
    if (m.via?.channel !== 'wa' || !m.via.chatId) return
    if (m.status === 'streaming') return
    if (m.authorId === AGENT_ID) {
      enqueueReply(m.id, m.via.chatId, m.text.trim(), m.via.voice === true, m.createdAt)
      return
    }
    // Laporan mentah karyawan lain (opsional). Default mati: manager yang merangkum.
    if (m.authorId === 'user' || m.authorId === 'routine') return
    if (process.env.WA_FORWARD_REPORTS !== '1') return
    const info = await loadTeamInfo()
    const name = info.agents.get(m.authorId) ?? m.authorId
    enqueueReply(m.id, m.via.chatId, `📋 *${name}* melapor:\n${m.text.trim()}`, false, m.createdAt)
  }

  async function handleEvent(event) {
    if (event.type === 'message:done') await handleServerMessage(event.message)
  }

  /** Jaring pengaman: ambil balasan yang terlewat (SSE putus / server restart) langsung dari riwayat percakapan. */
  let catching = false
  async function catchUp() {
    if (catching) return
    catching = true
    try {
      const res = await fetch(`${BASE}/api/state`, { headers: headers(), signal: AbortSignal.timeout(30_000) })
      if (!res.ok) return
      const st = await res.json()
      const conv = (st?.conversations ?? []).find((c) => c.id === CONVERSATION_ID)
      for (const m of conv?.messages ?? []) {
        if (m.createdAt < since || delivered.has(m.id)) continue
        await handleServerMessage(m)
      }
    } catch (err) {
      console.warn('[wa-bridge] catch-up gagal:', err.message)
    } finally {
      catching = false
    }
  }

  async function listenForReplies() {
    const url = `${BASE}/api/events${TOKEN ? `?token=${encodeURIComponent(TOKEN)}` : ''}`
    for (;;) {
      const ac = new AbortController()
      let idle
      const bump = () => {
        clearTimeout(idle)
        idle = setTimeout(() => ac.abort(), SSE_IDLE_MS)
      }
      try {
        bump()
        const res = await fetch(url, { headers: headers(), signal: ac.signal })
        if (!res.ok || !res.body) throw new Error(`gagal connect ke /api/events: ${res.status}`)
        console.log('[wa-bridge] terhubung ke event stream CocoziOpenBot.')
        void catchUp() // ambil apa pun yang terlewat selama terputus
        const reader = res.body.getReader()
        const decoder = new TextDecoder()
        let buf = ''
        for (;;) {
          const { value, done } = await reader.read()
          if (done) break
          bump() // ping server tiap 15 dtk juga menghidupkan timer ini
          buf += decoder.decode(value, { stream: true })
          let idx
          while ((idx = buf.indexOf('\n\n')) !== -1) {
            const chunk = buf.slice(0, idx)
            buf = buf.slice(idx + 2)
            const line = chunk.split('\n').find((l) => l.startsWith('data: '))
            if (!line) continue
            let event
            try {
              event = JSON.parse(line.slice(6))
            } catch {
              continue
            }
            try {
              await handleEvent(event)
            } catch (err) {
              console.error('[wa-bridge] error saat memproses event:', err.message)
            }
          }
        }
        console.warn('[wa-bridge] event stream ditutup server, sambung ulang...')
      } catch (err) {
        const why = ac.signal.aborted ? `tidak ada data > ${SSE_IDLE_MS / 1000}s (koneksi mati diam-diam)` : err.message
        console.error(`[wa-bridge] koneksi event terputus (${why}), coba lagi 2 detik lagi.`)
      } finally {
        clearTimeout(idle)
      }
      await sleep(2000)
    }
  }

  // ---- Klien WhatsApp: dibuat ulang otomatis kalau putus / macet ----
  let restarting = false
  let failStreak = 0
  let qrActive = false
  let startedAt = Date.now()
  const seenMsgs = new Set()
  const seenCalls = new Set()
  let inboxChain = Promise.resolve()

  /** Chromium yang mati mendadak meninggalkan file kunci + proses yatim; keduanya bikin start berikutnya gagal. */
  function cleanStaleBrowser() {
    for (const f of ['SingletonLock', 'SingletonCookie', 'SingletonSocket']) {
      try {
        rmSync(path.join(SESSION_DIR, 'session', f), { force: true })
      } catch {
        // abaikan
      }
    }
  }
  function killOrphanChromium() {
    if (process.platform === 'win32') return
    try {
      execSync("pkill -f '[.]wa-session' || true", { stdio: 'ignore' })
    } catch {
      // abaikan
    }
  }

  function buildClient() {
    const client = new Client({
      authStrategy: new LocalAuth({ dataPath: '.wa-session' }),
      puppeteer: {
        headless: true,
        ...(process.env.PUPPETEER_EXECUTABLE_PATH ? { executablePath: process.env.PUPPETEER_EXECUTABLE_PATH } : {}),
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
      },
    })
    const alive = () => client === wa // abaikan event dari klien lama yang sudah dibuang

    client.on('qr', (qr) => {
      if (!alive()) return
      qrActive = true
      // Lewat pm2 setiap baris log diberi awalan + timestamp sehingga QR di `pm2 logs` rusak/terpotong.
      // Jadi QR juga ditulis ke file teks polos: di server jalankan `cat wa-qr.txt` (QR berganti tiap ~20 detik).
      qrcode.generate(qr, { small: true }, (art) => {
        try {
          writeFileSync(QR_FILE, art)
        } catch {
          // folder tidak bisa ditulis: QR tetap ada di log kalau terminal interaktif
        }
        if (process.stdout.isTTY) {
          console.log('[wa-bridge] scan QR ini pakai WhatsApp di HP kamu (Pengaturan → Perangkat Tertaut):')
          console.log(art)
        } else {
          console.log(`[wa-bridge] QR baru siap. Lihat di terminal server: cat ${QR_FILE}  (atau: watch -n 2 cat ${QR_FILE})`)
        }
      })
    })

    client.on('ready', () => {
      if (!alive()) return
      qrActive = false
      waReady = true
      failStreak = 0
      try {
        if (existsSync(QR_FILE)) unlinkSync(QR_FILE)
      } catch {
        // abaikan
      }
      console.log(`[wa-bridge] WhatsApp tersambung. Pesan masuk diteruskan ke employee "${AGENT_ID}" di CocoziOpenBot (${BASE}).`)
      void catchUp()
      void pump() // kirim balasan yang tertahan selama WA terputus
    })

    client.on('auth_failure', (msg) => {
      if (!alive()) return
      console.error('[wa-bridge] gagal login WhatsApp:', msg)
      void restartClient('auth_failure')
    })

    client.on('disconnected', (reason) => {
      if (!alive()) return
      console.error('[wa-bridge] WhatsApp terputus:', reason)
      void restartClient(`disconnected: ${reason}`)
    })

    client.on('change_state', (state) => {
      if (alive()) console.log('[wa-bridge] status WhatsApp:', state)
    })

    // Telepon masuk: WhatsApp tidak mengizinkan bot mengangkat/bicara di panggilan, jadi
    // tolak dengan sopan dan arahkan ke voice note. (Event 'incoming_call' di whatsapp-web.js
    // baru, 'call' di versi lama — dua-duanya didengar, dedupe pakai id.)
    const onCall = async (call) => {
      if (!alive() || !REJECT_CALLS || !call || call.fromMe || seenCalls.has(call.id)) return
      seenCalls.add(call.id)
      if (seenCalls.size > 200) seenCalls.clear()
      const number = String(call.from ?? '').split('@')[0]
      if (ALLOWED.length > 0 && !ALLOWED.includes(normNumber(number))) return
      console.log(`[wa-bridge] telepon masuk dari ${number}${call.isVideo ? ' (video)' : ''} — ditolak`)
      try {
        await call.reject()
      } catch (err) {
        console.warn('[wa-bridge] gagal menolak telepon:', err.message)
      }
      try {
        await client.sendMessage(
          call.from,
          VOICE_KEY
            ? 'Maaf, aku nggak bisa angkat telepon WhatsApp. Kirim *voice note* aja ya — nanti aku dengarkan lalu balas dengan voice note juga 🎙️'
            : 'Maaf, aku nggak bisa angkat telepon WhatsApp. Kirim pesan teks aja ya, nanti langsung kujawab.',
        )
      } catch (err) {
        console.warn('[wa-bridge] gagal kirim pesan setelah tolak telepon:', err.message)
      }
    }
    client.on('incoming_call', onCall)
    client.on('call', onCall)

    // 'message' kadang tidak terpicu (bug whatsapp-web.js setelah idle/update WA Web); 'message_create'
    // dipasang sebagai cadangan. Pesan yang sama dideduplikasi lewat id, jadi aman dobel dengar.
    const intake = (msg) => {
      if (!alive()) return
      inboxChain = inboxChain.then(() => handleIncoming(client, msg)).catch((err) => console.error('[wa-bridge] error pesan masuk:', err?.message ?? err))
    }
    client.on('message', intake)
    client.on('message_create', (msg) => {
      if (!msg.fromMe) intake(msg)
    })
    return client
  }

  async function handleIncoming(client, msg) {
    if (msg.fromMe) return
    const msgId = msg.id?._serialized
    if (msgId) {
      if (seenMsgs.has(msgId) || inbound.has(msgId)) return
      seenMsgs.add(msgId)
      if (seenMsgs.size > 500) seenMsgs.delete(seenMsgs.values().next().value)
    }
    // Cek grup dari JID langsung (bukan msg.getChat()) — whatsapp-web.js versi terbaru
    // punya bug dimana getChat()/getChatById() bisa crash dengan error "r: r" setelah
    // update WhatsApp Web (github.com/wwebjs/whatsapp-web.js/issues/201838). Grup selalu
    // berakhiran "@g.us", jadi kita bisa skip tanpa menyentuh fungsi yang bermasalah itu.
    if (msg.from.endsWith('@g.us')) return // hanya chat pribadi, biar grup WA nggak ke-spam balasan manager
    // Status/Story kontak (status@broadcast), daftar siaran dan channel juga lewat event ini: bukan chat untuk bot.
    // Hanya chat pribadi (@c.us / @lid) yang diteruskan.
    if (msg.isStatus || !/@(c\.us|lid)$/.test(msg.from)) return

    let number = msg.from.split('@')[0]
    let label = number
    try {
      const contact = await withTimeout(msg.getContact(), 10_000, 'getContact')
      number = contact.number ?? number
      label = contact.pushname || contact.name || number
    } catch (err) {
      // getContact() kadang kena bug yang sama; tetap lanjut pakai nomor mentah dari JID
      // supaya pesan tetap diteruskan walau nama kontaknya nggak kebaca.
      console.warn('[wa-bridge] gagal ambil nama kontak (lanjut pakai nomor mentah):', err.message)
    }

    if (ALLOWED.length > 0 && !ALLOWED.includes(normNumber(number))) {
      console.log(`[wa-bridge] pesan dari ${number} diabaikan (tidak ada di WA_ALLOWED_NUMBERS)`)
      return
    }
    // Nama dari WA_NUMBER_NAMES menang atas nama tampilan WhatsApp.
    label = NAMES.get(normNumber(number)) ?? label

    let forwarded = false
    if (msg.type === 'ptt' || msg.type === 'audio') {
      if (!VOICE_KEY) {
        await client.sendMessage(msg.from, 'Voice note belum aktif (API key suara belum diset). Kirim teks dulu ya.').catch(() => {})
        return
      }
      try {
        const media = await withTimeout(msg.downloadMedia(), 60_000, 'download voice note')
        if (!media?.data) throw new Error('media kosong')
        const heard = await transcribe(media.data, media.mimetype)
        if (!heard) {
          await client.sendMessage(msg.from, 'Maaf, aku nggak nangkep isi voice note-nya. Coba rekam ulang atau kirim teks ya.').catch(() => {})
          return
        }
        console.log(`[wa-bridge] voice note dari ${label}: ${heard}`)
        forwarded = await forwardToCocoziOpenBot(label, heard, msg.from, true, number)
      } catch (err) {
        console.error('[wa-bridge] gagal proses voice note:', err.message)
        await client.sendMessage(msg.from, 'Maaf, voice note-nya gagal diproses. Coba kirim teks dulu ya.').catch(() => {})
      }
    } else {
      if (!msg.body) return
      console.log(`[wa-bridge] pesan masuk dari ${label}: ${msg.body}`)
      forwarded = await forwardToCocoziOpenBot(label, msg.body, msg.from, false, number)
    }
    if (forwarded && msgId) {
      inbound.add(msgId)
      saveState()
    }
  }

  async function startClient() {
    for (let attempt = 1; ; attempt++) {
      try {
        cleanStaleBrowser()
        startedAt = Date.now()
        qrActive = false
        wa = buildClient()
        await wa.initialize()
        return
      } catch (err) {
        console.error(`[wa-bridge] initialize gagal (percobaan ${attempt}):`, err.message)
        try {
          await withTimeout(wa?.destroy(), 20_000, 'destroy')
        } catch {
          // abaikan
        }
        killOrphanChromium()
        await sleep(Math.min(60_000, 5000 * attempt))
      }
    }
  }

  async function restartClient(reason) {
    if (restarting) return
    restarting = true
    waReady = false
    failStreak++
    console.error(`[wa-bridge] memulai ulang klien WhatsApp (${reason}).`)
    try {
      await withTimeout(wa?.destroy(), 20_000, 'destroy')
    } catch {
      // browser sudah mati / macet: lanjut
    }
    killOrphanChromium()
    await sleep(Math.min(60_000, 3000 * 2 ** Math.min(failStreak, 5)))
    restarting = false
    void startClient()
  }

  // Watchdog: koneksi WA bisa mati diam-diam (event 'disconnected' tidak selalu datang).
  let badChecks = 0
  setInterval(async () => {
    if (restarting) return
    if (!waReady) {
      // Tidak ready & tidak menunggu scan QR terlalu lama = macet saat start.
      if (!qrActive && Date.now() - startedAt > 4 * 60_000) void restartClient('macet saat start')
      return
    }
    let state = 'ERROR'
    try {
      state = await withTimeout(wa.getState(), 20_000, 'getState')
    } catch (err) {
      console.warn('[wa-bridge] cek status WA gagal:', err.message)
    }
    if (state === 'CONNECTED') {
      badChecks = 0
      return
    }
    badChecks++
    console.warn(`[wa-bridge] status WA = ${state} (cek ke-${badChecks})`)
    if (badChecks >= 2) {
      badChecks = 0
      void restartClient(`status WA ${state}`)
    }
  }, 60_000).unref?.()

  // Jaring pengaman berkala (selain catch-up tiap SSE nyambung): kirim balasan yang terlewat + dorong antrean.
  setInterval(() => {
    void catchUp()
    void pump()
  }, 90_000).unref?.()

  // Matikan Chromium dengan rapi saat proses dihentikan, supaya start berikutnya tidak kena file kunci.
  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.once(sig, async () => {
      try {
        await withTimeout(wa?.destroy(), 8_000, 'destroy')
      } catch {
        // abaikan
      }
      process.exit(0)
    })
  }

  killOrphanChromium()
  void listenForReplies() // langsung nyala, tidak menunggu WA ready: balasan menumpuk di antrean sampai WA siap
  await startClient()
}

// Cara B: dijalankan langsung lewat `node wa-bridge.mjs` (bukan di-import server).
const isMain = process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])
if (isMain) {
  startWaBridge().catch((err) => {
    console.error('[wa-bridge] gagal start:', err)
    process.exit(1)
  })
}
