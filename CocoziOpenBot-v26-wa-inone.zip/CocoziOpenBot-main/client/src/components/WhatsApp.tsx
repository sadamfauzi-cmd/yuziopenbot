import { useEffect, useState } from 'react'
import { waStatus, type WaStatus } from '../api'

/** Link WhatsApp from the browser: shows the QR code straight from the running server (no terminal needed). */
export function WhatsApp() {
  const [st, setSt] = useState<WaStatus | null>(null)
  const [err, setErr] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    const tick = async () => {
      try {
        const s = await waStatus()
        if (alive) {
          setSt(s)
          setErr(null)
        }
      } catch (e) {
        if (alive) setErr(e instanceof Error ? e.message : String(e))
      }
    }
    void tick()
    const id = window.setInterval(tick, 3000)
    return () => {
      alive = false
      window.clearInterval(id)
    }
  }, [])

  const state = st?.state ?? 'off'
  return (
    <div className="card">
      <div className="row-title">WhatsApp</div>
      <p className="row-hint">
        Hubungkan WhatsApp ke manager. Di HP: WhatsApp → Pengaturan → Perangkat Tertaut → Tautkan Perangkat, lalu scan QR di bawah. Sesi tersimpan di folder <code>.wa-session</code>, jadi cukup scan sekali.
      </p>
      {err && <p className="row-hint">Tidak bisa membaca status: {err}</p>}
      {state === 'ready' && <p>✅ WhatsApp tersambung.</p>}
      {state === 'starting' && <p>⏳ Menyalakan WhatsApp… (pertama kali bisa 30–60 detik, QR muncul setelah itu)</p>}
      {state === 'qr' && (
        <div>
          <p>Scan QR ini (berganti otomatis tiap ±20 detik):</p>
          {st?.qrSvg ? (
            <div style={{ width: 260, height: 260, background: '#fff', borderRadius: 12, padding: 8 }} dangerouslySetInnerHTML={{ __html: st.qrSvg }} />
          ) : (
            <pre style={{ fontSize: 8, lineHeight: 1, background: '#fff', color: '#000', padding: 8, display: 'inline-block' }}>{st?.qrText}</pre>
          )}
        </div>
      )}
      {state === 'disconnected' && <p>⚠️ {st?.error ?? 'WhatsApp terputus.'} Hapus folder <code>.wa-session</code> lalu restart program untuk scan ulang.</p>}
      {state === 'error' && <p>❌ {st?.error ?? 'WhatsApp bridge gagal start.'}</p>}
      {state === 'off' && <p>WhatsApp bridge belum jalan. Pastikan <code>whatsapp-web.js</code> terpasang (<code>npm install</code>) dan <code>WA_BRIDGE_ENABLED</code> tidak diset ke 0.</p>}
    </div>
  )
}
